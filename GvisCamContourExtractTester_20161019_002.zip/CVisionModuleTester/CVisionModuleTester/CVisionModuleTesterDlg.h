
// CVisionModuleTesterDlg.h : ��� ����
//

#pragma once

////////////////////////////////////////////////////////////////////////////
// Include CVision Class
#include "Vision.h"
////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////
#include "cv.h"
#include "highgui.h"
//#include "opencv2/objdetect/objdetect.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "afxwin.h"
//#include <iostream>
//#include <stdio.h>
//#include "afxwin.h"
using namespace std;
using namespace cv;

//#include "opencv2/gpu/gpu.hpp"
//////////////////////////////////////////////////////////////////////////////////////////



// CCVisionModuleTesterDlg ��ȭ ����
class CCVisionModuleTesterDlg : public CDialogEx
{
// �����Դϴ�.
public:
	CCVisionModuleTesterDlg(CWnd* pParent = NULL);	// ǥ�� �������Դϴ�.

	////////////////////////////////////////////////////////////////////////////
	// CVision Class
	CVision m_cVision;
	////////////////////////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////////////////////////
	// CVision Class
	int m_iSizeX;
	int m_iSizeY;

	Mat m_mSource;
	Mat m_mTarget;

	unsigned char *m_pSource;
	unsigned char *m_pTarget;
	////////////////////////////////////////////////////////////////////////////

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_CVISIONMODULETESTER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �����Դϴ�.


// �����Դϴ�.
protected:
	HICON m_hIcon;

	// ������ �޽��� �� �Լ�
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonInit();
	afx_msg void OnBnClickedButtonFree();
	afx_msg void OnBnClickedButtonLoad();
	afx_msg void OnBnClickedButtonSave();
	afx_msg void OnBnClickedButtonProc();
	CListBox m_ctrlMessage;
	afx_msg void OnBnClickedButtonInitSetImage();
	afx_msg void OnBnClickedButtonInitSetRoi();
};
