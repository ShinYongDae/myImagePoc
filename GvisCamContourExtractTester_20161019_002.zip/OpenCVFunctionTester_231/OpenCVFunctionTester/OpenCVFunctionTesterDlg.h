
// OpenCVFunctionTesterDlg.h : ��� ����
//

#pragma once


//////////////////////////////////////////////////////////////////////////////////////////
#include "cv.h"
#include "highgui.h"
#include "opencv2/objdetect/objdetect.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
//#include "opencv2/gpu/gpu.hpp"
#include "afxwin.h"
//#include <iostream>
//#include <stdio.h>
//#include "afxwin.h"
using namespace std;
using namespace cv;
//using namespace cv::gpu;


//////////////////////////////////////////////////////////////////////////////////////////



// COpenCVFunctionTesterDlg ��ȭ ����
class COpenCVFunctionTesterDlg : public CDialogEx
{
// �����Դϴ�.
public:
	COpenCVFunctionTesterDlg(CWnd* pParent = NULL);	// ǥ�� �������Դϴ�.

	Mat m_mSource;
	Mat m_mTarget;
	Mat m_mModel;

	Mat m_mResult;
	Mat m_mResult2;

	Mat m_gmSource;
	Mat m_gmModel;
	Mat m_gmResult;

	unsigned char *m_pSource;
	unsigned char *m_pModel;
	unsigned char *m_pTarget;

	int m_iSizeX;
	int m_iSizeY;

	int m_iSizeModelX;
	int m_iSizeModelY;


// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_OPENCVFUNCTIONTESTER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �����Դϴ�.


// �����Դϴ�.
protected:
	HICON m_hIcon;

	// ������ �޽��� �� �Լ�
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonInit();
	afx_msg void OnBnClickedButtonFree();
	afx_msg void OnBnClickedButtonLoad();
	afx_msg void OnBnClickedButtonSave();
	afx_msg void OnBnClickedButtonProc();
	afx_msg void OnBnClickedButtonLoadModel();
	CListBox m_ctrlMessage;
	afx_msg void OnBnClickedButtonProcGpu();
	afx_msg void OnBnClickedButtonLoadMat();
	afx_msg void OnBnClickedButtonSaveMat();
	afx_msg void OnBnClickedButtonThresholdAdaptive();
};
