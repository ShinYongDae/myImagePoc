
// OpenCVFunctionTesterDlg.cpp : ���� ����
//

#include "stdafx.h"
#include "OpenCVFunctionTester.h"
#include "OpenCVFunctionTesterDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ���� ���α׷� ������ ���Ǵ� CAboutDlg ��ȭ �����Դϴ�.

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

// �����Դϴ�.
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// COpenCVFunctionTesterDlg ��ȭ ����




COpenCVFunctionTesterDlg::COpenCVFunctionTesterDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(COpenCVFunctionTesterDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void COpenCVFunctionTesterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_ctrlMessage);
}

BEGIN_MESSAGE_MAP(COpenCVFunctionTesterDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_INIT, &COpenCVFunctionTesterDlg::OnBnClickedButtonInit)
	ON_BN_CLICKED(IDC_BUTTON_FREE, &COpenCVFunctionTesterDlg::OnBnClickedButtonFree)
	ON_BN_CLICKED(IDC_BUTTON_LOAD, &COpenCVFunctionTesterDlg::OnBnClickedButtonLoad)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, &COpenCVFunctionTesterDlg::OnBnClickedButtonSave)
	ON_BN_CLICKED(IDC_BUTTON_PROC, &COpenCVFunctionTesterDlg::OnBnClickedButtonProc)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_MODEL, &COpenCVFunctionTesterDlg::OnBnClickedButtonLoadModel)
	ON_BN_CLICKED(IDC_BUTTON_PROC_GPU, &COpenCVFunctionTesterDlg::OnBnClickedButtonProcGpu)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_MAT, &COpenCVFunctionTesterDlg::OnBnClickedButtonLoadMat)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_MAT, &COpenCVFunctionTesterDlg::OnBnClickedButtonSaveMat)
	ON_BN_CLICKED(IDC_BUTTON_THRESHOLD_ADAPTIVE, &COpenCVFunctionTesterDlg::OnBnClickedButtonThresholdAdaptive)
END_MESSAGE_MAP()


// COpenCVFunctionTesterDlg �޽��� ó����

BOOL COpenCVFunctionTesterDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// �ý��� �޴��� "����..." �޴� �׸��� �߰��մϴ�.

	// IDM_ABOUTBOX�� �ý��� ���� ������ �־�� �մϴ�.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	//  �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.

	// TODO: ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	return TRUE;  // ��Ŀ���� ��Ʈ�ѿ� �������� ������ TRUE�� ��ȯ�մϴ�.
}

void COpenCVFunctionTesterDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// ��ȭ ���ڿ� �ּ�ȭ ���߸� �߰��� ��� �������� �׸�����
//  �Ʒ� �ڵ尡 �ʿ��մϴ�. ����/�� ���� ����ϴ� MFC ���� ���α׷��� ��쿡��
//  �����ӿ�ũ���� �� �۾��� �ڵ����� �����մϴ�.

void COpenCVFunctionTesterDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Ŭ���̾�Ʈ �簢������ �������� ����� ����ϴ�.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// ����ڰ� �ּ�ȭ�� â�� ���� ���ȿ� Ŀ���� ǥ�õǵ��� �ý��ۿ���
//  �� �Լ��� ȣ���մϴ�.
HCURSOR COpenCVFunctionTesterDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


bool convertcvmatauto(Mat input24, Mat output8)
{
	int sizex = output8.cols;
	int sizey = output8.rows;

	if( output8.cols > input24.cols )
	{
		sizex = input24.cols;
	}
	if( output8.rows > input24.rows )
	{
		sizey = input24.rows;
	}

	for(int y=0;y<sizey;y++)
		for(int x=0;x<sizex;x++)
			output8.data[x + y*output8.cols] = input24.data[(x)*3 + (*input24.step.p) * (y)];
		
	return true;
}


bool convertcvmatresize(Mat input24, Mat output8 , float scale)
{
	int sizex = output8.cols;
	int sizey = output8.rows;

	if( output8.cols > input24.cols )
	{
		sizex = input24.cols;
	}
	if( output8.rows > input24.rows )
	{
		sizey = input24.rows;
	}

	for(int y=0;y<sizey;y++)
		for(int x=0;x<sizex;x++)
			output8.data[x + y*output8.cols] = input24.data[(x*int(scale))*3 + (*input24.step.p) * (y*int(scale))];
		
	return true;
}

void COpenCVFunctionTesterDlg::OnBnClickedButtonInit()
{
	//int num = gpu::getDevice();
    //gpu::resetDevice(); 
	//cv::gpu::setDevice(0);
	//cv::gpu::resetDevice();

	////////////////////////////////////////////////////////////////////////////////
	m_iSizeX = 8783;//8797;
	m_iSizeY = 5783;//5758;
	m_iSizeModelX = 8176;//m_iSizeX-1000;
	m_iSizeModelY = 4734;//m_iSizeY-1000;
	

	m_pSource = new unsigned char [ m_iSizeX * m_iSizeY ];	
	m_pTarget = new unsigned char [ m_iSizeX * m_iSizeY ];	

	m_mSource = Mat(m_iSizeY,m_iSizeX,CV_8UC1,(void*)m_pSource);//OpenCV	
	m_mTarget = Mat(m_iSizeY,m_iSizeX,CV_8UC1,(void*)m_pTarget);//OpenCV

	m_pModel = new unsigned char [ m_iSizeModelX * m_iSizeModelY ];
	m_mModel = Mat(m_iSizeModelY,m_iSizeModelX,CV_8UC1,(void*)m_pModel);//OpenCV

	/// Create the result matrix
	int result_cols = m_mSource.cols - m_mModel.cols + 1;
	int result_rows = m_mSource.rows - m_mModel.rows + 1;
	m_mResult.create( result_cols, result_rows, CV_32FC1 );
	m_mResult2.create( result_cols, result_rows, CV_32FC1 );


	m_gmSource = Mat( m_iSizeY,m_iSizeX , CV_8UC1);//OpenCV
	m_gmModel = Mat(m_iSizeModelY,m_iSizeModelX,CV_8UC1);//OpenCV
	m_gmResult.create( result_cols, result_rows, CV_32FC1 );//OpenCV

	//Display #1
	imshow("Source Image", m_mSource);//�����̹���

	////////////////////////////////////////////////////////////////////////////////

	CString str;
	str.Format( TEXT( "Initialized... ") );
	m_ctrlMessage.InsertString( 0 , str);
	UpdateData(false);
}


void COpenCVFunctionTesterDlg::OnBnClickedButtonFree()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
}

bool imageload ( Mat target  )
{
	CString m_csPath;
	CFileDialog* pOpenDlg = new CFileDialog(TRUE, TEXT("*.*"), NULL,
     		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
			TEXT("��� ���� (*.*)|*.*|"));
		
	

	if ( pOpenDlg->DoModal() == IDOK ) 
	{
		m_csPath = pOpenDlg->GetPathName();	
		
		std::string ss  = (CT2A(m_csPath));//string ��ȯ
		Mat tempmat24 = imread(ss);//���� �̹��� �ε�		
		
		
		convertcvmatauto(tempmat24,target);//�÷� �̹��� ������� ��ȯ //
		//convertcvmatresize( tempmat24,targetresize , 10);//�÷� �̹��� ������� ��ȯ //
		//cv::resize(tempmat24, target, target.size());
		
		//Display #1
		//imshow("Source Image", target);
	}	

	return true;
}

void COpenCVFunctionTesterDlg::OnBnClickedButtonLoad()
{
	imageload ( m_mSource );

	m_mSource.copyTo( m_mTarget );
}


void COpenCVFunctionTesterDlg::OnBnClickedButtonSave()
{
	CString m_csPath;
	CFileDialog* pOpenDlg = new CFileDialog(FALSE, TEXT("*.*"), NULL,
     		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
			TEXT("��� ���� (*.*)|*.*|"));
		
	

	if ( pOpenDlg->DoModal() == IDOK ) 
	{
		m_csPath = pOpenDlg->GetPathName();	
		
		std::string ss  = (CT2A(m_csPath));//string ��ȯ
		imwrite(ss, m_mTarget);//���� 		
		
	}	
}


#define MIL_ID int

BOOL TempleteMatch( MIL_ID src, MIL_ID mod,  float * score, float * posx, float *posy)
{
	// Mat Result 
	Mat result;
	Mat result2;
	Mat source; 
	Mat model;

	/*
	//������ �޾ƿ���
	int sorcesizex = MbufInquire( src, M_SIZE_X,M_NULL);
	int sorcesizey = MbufInquire( src, M_SIZE_Y,M_NULL);

	int modelsizex = MbufInquire( mod, M_SIZE_X,M_NULL);
	int modelsizey = MbufInquire( mod, M_SIZE_Y,M_NULL);

	//Mat �ӽ� ���� ����
	source = Mat(sorcesizey,sorcesizex,CV_8UC1);
	model = Mat(modelsizey,modelsizex,CV_8UC1);

	//���� ������ ��������
	MbufGet(src, source.data);
	MbufGet(mod, model.data);
	*/
	/// Create the result matrix
	int result_cols = source.cols - model.cols + 1;
	int result_rows = source.rows - model.rows + 1;
	result.create( result_cols, result_rows, CV_32FC1 );
	result2.create( result_cols, result_rows, CV_32FC1 );

	int match_method =1;
	/// Do the Matching and Normalize
	matchTemplate( source, model, result, match_method );
	normalize( result, result2, 0, 1, NORM_MINMAX, -1, Mat() );

	/// Localizing the best match with minMaxLoc
	double minVal; double maxVal; Point minLoc; Point maxLoc;
	Point matchLoc;
	minMaxLoc( result2, &minVal, &maxVal, &minLoc, &maxLoc, Mat() );
	/// For SQDIFF and SQDIFF_NORMED, the best matches are lower values. For all the other methods, the higher the better
	if( match_method == CV_TM_SQDIFF || match_method == CV_TM_SQDIFF_NORMED )
	{ matchLoc = minLoc; }
	else
	{ matchLoc = maxLoc; }

	//����� ����
	*score = result.at<float>(  matchLoc.y,matchLoc.x );//minVal;//�ǹ� �ٸ�
	*posx = matchLoc.x;
	*posy = matchLoc.y;

	//����
	result2.release();
	result.release();
	source.release();
	model.release();

	return true;
}
void COpenCVFunctionTesterDlg::OnBnClickedButtonProc()
{
	CString str;
	str.Format( TEXT( ">> Templete Matching Processing............ ") );
	m_ctrlMessage.InsertString( 0 , str);	
	UpdateWindow();

		int match_method =1;
	/// Do the Matching and Normalize
	matchTemplate( m_mSource, m_mModel, m_mResult, match_method );
	normalize( m_mResult, m_mResult2, 0, 1, NORM_MINMAX, -1, Mat() );

	/// Localizing the best match with minMaxLoc
	double minVal; double maxVal; Point minLoc; Point maxLoc;
	Point matchLoc;
	minMaxLoc( m_mResult2, &minVal, &maxVal, &minLoc, &maxLoc, Mat() );
	/// For SQDIFF and SQDIFF_NORMED, the best matches are lower values. For all the other methods, the higher the better
	if( match_method == CV_TM_SQDIFF || match_method == CV_TM_SQDIFF_NORMED )
	{ matchLoc = minLoc; }
	else
	{ matchLoc = maxLoc; }

	float temp = (float)m_mResult.at<float>(  matchLoc.y,matchLoc.x );

	/// Show me what you got
	rectangle( m_mTarget, matchLoc, Point( matchLoc.x + m_mModel.cols , matchLoc.y + m_mModel.rows ), Scalar::all(0), 2, 8, 0 );
	rectangle( m_mResult, matchLoc, Point( matchLoc.x + m_mModel.cols , matchLoc.y + m_mModel.rows ), Scalar::all(0), 2, 8, 0 );
	//imshow( "Target", m_mTarget );
	//imshow( "Result", m_mResult );

	//Display #1
	//imshow("Result Image", m_mTarget);
	str.Format( TEXT( ">> Templete Matching Processed!") );
	m_ctrlMessage.InsertString( 0 , str);
	UpdateWindow();
}


void COpenCVFunctionTesterDlg::OnBnClickedButtonLoadModel()
{
	CString m_csPath;
	CFileDialog* pOpenDlg = new CFileDialog(TRUE, TEXT("*.*"), NULL,
     		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
			TEXT("��� ���� (*.*)|*.*|"));
		
	

	if ( pOpenDlg->DoModal() == IDOK ) 
	{
		m_csPath = pOpenDlg->GetPathName();	
		
		std::string ss  = (CT2A(m_csPath));//string ��ȯ
		Mat tempmat24 = imread(ss);//���� �̹��� �ε�		
		
		
		convertcvmatauto(tempmat24,m_mModel);//�÷� �̹��� ������� ��ȯ //
		//convertcvmatresize( tempmat24,targetresize , scale);//�÷� �̹��� ������� ��ȯ //
		//cv::resize(tempmat24, target, target.size());
		
		//Display #1
		//imshow("Model Image", m_mModel);
	}	
}

void COpenCVFunctionTesterDlg::OnBnClickedButtonProcGpu()
{
	CString str;
	str.Format( TEXT( ">> Templete Matching Processing On GPU............ ") );
	m_ctrlMessage.InsertString( 0 , str);	
	UpdateWindow();
	
	//cv::gpu::setDevice(0);

	int match_method =1;
	//Mat m_gmSource,m_gmModel;
	//m_gmSource.upload( m_mSource );
	//m_gmModel.upload( m_mModel );
	
	
	/// Do the Matching and Normalize
	cv::matchTemplate( m_gmSource, m_gmModel, m_gmResult, match_method );
	cv::normalize( m_gmResult, m_gmResult, 0, 1, NORM_MINMAX, -1  );

	//m_gmResult.download( m_mResult2 );

	/// Localizing the best match with minMaxLoc
	double minVal; double maxVal; Point minLoc; Point maxLoc;
	Point matchLoc;
	minMaxLoc( m_mResult2, &minVal, &maxVal, &minLoc, &maxLoc, Mat() );
	/// For SQDIFF and SQDIFF_NORMED, the best matches are lower values. For all the other methods, the higher the better
	if( match_method == CV_TM_SQDIFF || match_method == CV_TM_SQDIFF_NORMED )
	{ matchLoc = minLoc; }
	else
	{ matchLoc = maxLoc; }

	float temp = (float)m_mResult.at<float>(  matchLoc.y,matchLoc.x );

	/// Show me what you got
	rectangle( m_mTarget, matchLoc, Point( matchLoc.x + m_mModel.cols , matchLoc.y + m_mModel.rows ), Scalar::all(0), 2, 8, 0 );
	rectangle( m_mResult, matchLoc, Point( matchLoc.x + m_mModel.cols , matchLoc.y + m_mModel.rows ), Scalar::all(0), 2, 8, 0 );
	//imshow( "Target", m_mTarget );
	//imshow( "Result", m_mResult );

	//Display #1
	//imshow("Result Image", m_mTarget);
	str.Format( TEXT( ">> Templete Matching Processed!") );
	m_ctrlMessage.InsertString( 0 , str);
	UpdateWindow();
}

Mat m_matSource;
Mat m_matTarget;
void COpenCVFunctionTesterDlg::OnBnClickedButtonLoadMat()
{
	CString m_csPath;
	CFileDialog* pOpenDlg = new CFileDialog(TRUE, TEXT("*.*"), NULL,
     		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
			TEXT("��� ���� (*.*)|*.*|"));
		
	

	if ( pOpenDlg->DoModal() == IDOK ) 
	{
		m_csPath = pOpenDlg->GetPathName();	
		
		std::string ss  = (CT2A(m_csPath));//string ��ȯ
		Mat tempmat24 = imread(ss);//���� �̹��� �ε�	

		m_matSource = Mat(tempmat24.rows,tempmat24.cols,CV_8UC1);
		m_matTarget = Mat(tempmat24.rows,tempmat24.cols,CV_8UC1);
		convertcvmatauto(tempmat24,m_matSource);//�÷� �̹��� ������� ��ȯ //
		
		//Display #1
		imshow("Source Image", m_matSource);
	}	
}


void COpenCVFunctionTesterDlg::OnBnClickedButtonSaveMat()
{
	CString m_csPath;
	CFileDialog* pOpenDlg = new CFileDialog(FALSE, TEXT("*.*"), NULL,
     		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
			TEXT("��� ���� (*.*)|*.*|"));
		
	

	if ( pOpenDlg->DoModal() == IDOK ) 
	{
		m_csPath = pOpenDlg->GetPathName();	
		
		std::string ss  = (CT2A(m_csPath));//string ��ȯ
		imwrite(ss, m_matTarget);//���� 		
		
	}	
}


void COpenCVFunctionTesterDlg::OnBnClickedButtonThresholdAdaptive()
{

	cv::adaptiveThreshold( m_matSource, m_matTarget, 255, CV_ADAPTIVE_THRESH_GAUSSIAN_C,CV_THRESH_BINARY, 255, 0);
	
	//Display #1
	imshow("Target Image", m_matTarget);
}

//#define USE_ADAPTIVETHRESHOLD

void AdaptiveThreshold( MIL_ID src, MIL_ID tgt)
{
	Mat source, target; 
#ifdef USE_ADAPTIVETHRESHOLD
	//������ �޾ƿ���
	int sorcesizex = MbufInquire( src, M_SIZE_X,M_NULL);
	int sorcesizey = MbufInquire( src, M_SIZE_Y,M_NULL);
	
	//Mat �ӽ� ���� ����
	source = Mat(sorcesizey,sorcesizex,CV_8UC1);	
	target = Mat(sorcesizey,sorcesizex,CV_8UC1);	

	//���� ������ ��������
	MbufGet(src, source.data);	
#endif

	cv::adaptiveThreshold( source, target, 255, CV_ADAPTIVE_THRESH_GAUSSIAN_C,CV_THRESH_BINARY, 255, 0);

#ifdef USE_ADAPTIVETHRESHOLD
	MbufPut( tgt, target.data );
#endif
	source.release();
	target.release();
}
