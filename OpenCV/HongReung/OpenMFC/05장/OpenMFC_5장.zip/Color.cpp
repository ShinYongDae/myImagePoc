/*
 * Color.cpp : �÷� ���� ó�� Ŭ����
 * Modified by Lee, Moon-Ho (conv2@korea.com)
 * Last Modified : 2006/11/13
 */

#include "stdafx.h"
#include "openmfc.h"
#include "Color.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CColor::CColor()
{

}

CColor::~CColor()
{

}

// RGB �÷� ���� �и�
void CColor::SplitRGB( IplImage *color_image, IplImage **red, IplImage **green, IplImage **blue )
{
	// STEP 1 : �޸� �Ҵ�
	*red = cvCreateImage( cvGetSize(color_image), IPL_DEPTH_8U, 1 );
	*green = cvCreateImage( cvGetSize(color_image), IPL_DEPTH_8U, 1 );
	*blue = cvCreateImage( cvGetSize(color_image), IPL_DEPTH_8U, 1 );

	// STEP 2 : cvCvtPixToPlne() �Լ� ȣ��
	cvCvtPixToPlane( color_image, *blue, *green, *red, NULL );

	return;
}

