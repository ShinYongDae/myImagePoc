#if !defined(AFX_FILTERDLG_H__EF94FB6B_4E82_49E4_8A14_4C7BEFC61612__INCLUDED_)
#define AFX_FILTERDLG_H__EF94FB6B_4E82_49E4_8A14_4C7BEFC61612__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FilterDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFilterDlg dialog
#include "ExStatic.h"
class CExStatic;

class CFilterDlg : public CDialog
{
// Construction
public:
	CFilterDlg(CWnd* pParent = NULL);   // standard constructor

	CvvImage d_org_cvvImage; // �� ����
	CvvImage d_cvvImage; // ���͸� ��� ���� ����

	int picture_height; // Picture ��Ʈ���� ���� ���� 
	int picture_width; // Picture ��Ʈ���� �ʺ� ����(4�� ���)

	float soften_mask[9]; // For Soften filtering
	float ef_mask[9]; // For Enhance focus filtering
	float ed_mask[9]; // For Enhance detail filtering
	float bl_mask[9]; // For Blur light filtering
	float bb_mask[9]; // For Blur blending filtering

// Dialog Data
	//{{AFX_DATA(CFilterDlg)
	enum { IDD = IDD_SFILTER_DIALOG };
	CStatic	m_preview_image;
	CComboBox	m_combo_filter;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilterDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFilterDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnPreviewButton();
	afx_msg void OnInitialButton();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILTERDLG_H__EF94FB6B_4E82_49E4_8A14_4C7BEFC61612__INCLUDED_)
