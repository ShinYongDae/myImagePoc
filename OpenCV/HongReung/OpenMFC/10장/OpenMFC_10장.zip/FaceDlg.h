#if !defined(AFX_FACEDLG_H__52D75BBA_B5A8_43AE_BAEC_806D20262C24__INCLUDED_)
#define AFX_FACEDLG_H__52D75BBA_B5A8_43AE_BAEC_806D20262C24__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FaceDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFaceDlg dialog

#include "VideoWnd.h"

class CFaceDlg : public CDialog
{
// Construction
public:
	void FDInsertLog( CString msg );
	CFaceDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFaceDlg)
	enum { IDD = IDD_FACE_DETECT_DIALOG };
	CButton	m_resume_btn;
	CButton	m_result_view_btn;
	CButton	m_capture_btn;
	CButton	m_pause_btn;
	CEdit	m_pEdit;
	//}}AFX_DATA

	// �� ���� ��� ������ �ִ� ���͸� 
	CString m_szExtractPath;
	
	// CBCH�� �н���Ų XML ������ �ִ� ���͸�
	// Casade of boosted classifiers working with haar-like features
	CString m_szCBCHXMLPath;

	// CBCH�� �н���Ų XML ������ �ִ� ���͸��� ������ true
	// �ƴϸ� false
	bool m_xmlFlag;

private:
	CVideoWnd m_videoWnd;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFaceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFaceDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPauseButton();
	afx_msg void OnResumeButton();
	afx_msg void OnCaptureButton();
	afx_msg void OnResultButton();
	afx_msg void OnLogInsert(WPARAM wp, LPARAM lp);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FACEDLG_H__52D75BBA_B5A8_43AE_BAEC_806D20262C24__INCLUDED_)
