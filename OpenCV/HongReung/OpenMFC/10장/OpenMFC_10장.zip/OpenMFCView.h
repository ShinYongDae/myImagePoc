// OpenMFCView.h : interface of the COpenMFCView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OPENMFCVIEW_H__6C7685BB_F1F9_40F9_98F3_E082ED00F525__INCLUDED_)
#define AFX_OPENMFCVIEW_H__6C7685BB_F1F9_40F9_98F3_E082ED00F525__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class COpenMFCView : public CScrollView
{
protected: // create from serialization only
	COpenMFCView();
	DECLARE_DYNCREATE(COpenMFCView)

// Attributes
public:
	COpenMFCDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COpenMFCView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COpenMFCView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COpenMFCView)
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveAs();
	afx_msg void OnEditCopy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnUpdateFileNew(CCmdUI* pCmdUI);
	afx_msg void OnSplitRGB();
	afx_msg void OnFilter2D();
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateEditUndo(CCmdUI* pCmdUI);
	afx_msg void OnEditRedo();
	afx_msg void OnChap7Rgb2gray();
	afx_msg void OnChap7SplitRgb();
	afx_msg void OnChap7CompositeRgb();
	afx_msg void OnChap7Split2Rgb();
	afx_msg void OnChap7SplitHsv();
	afx_msg void OnChap7CompositeHsv();
	afx_msg void OnChap7SplitYcbcr();
	afx_msg void OnChap7CompositeYcbcr();
	afx_msg void OnChap8MakeGrayBand();
	afx_msg void OnChap8AddsubConstant();
	afx_msg void OnChap8AddImage();
	afx_msg void OnChap8SubtractImage();
	afx_msg void OnChap8BlendingEffect();
	afx_msg void OnChap8MakeContrast();
	afx_msg void OnChap8MulConstrant();
	afx_msg void OnChap8MulConstant();
	afx_msg void OnChap8DivConstant();
	afx_msg void OnChap8ContrastBrightness();
	afx_msg void OnChap8ImHistGrayImage();
	afx_msg void OnChap8ImHistGrayBrightness();
	afx_msg void OnChap8ImHistGrayContrast();
	afx_msg void OnChap8HistogramEqualization();
	afx_msg void OnChap8ViewHistData();
	afx_msg void OnChap8LutBasicContrastBrighness();
	afx_msg void OnChap8Threshold();
	afx_msg void OnChap8AdaptiveThreshold();
	afx_msg void OnChap8BinaryLogicalAnd();
	afx_msg void OnChap8BinaryLogicalNand();
	afx_msg void OnChap8BinaryLogicalOr();
	afx_msg void OnChap8GrayLogicalAnd();
	afx_msg void OnChap8GrayLogicNand();
	afx_msg void OnChap8GrayLogicOr();
	afx_msg void OnChap9Conv2();
	afx_msg void OnChap9GrayEmbossing();
	afx_msg void OnChap9RgbEmbossing();
	afx_msg void OnChap9HsvEmbossing();
	afx_msg void OnChap9WildEmbossing();
	afx_msg void OnChap9Blurring1();
	afx_msg void OnChap9Blurring2();
	afx_msg void OnChap9Sharpening();
	afx_msg void OnChap9HighBoost();
	afx_msg void OnChap9Unsharpening();
	afx_msg void OnChap9EnhanceFilter();
	afx_msg void OnChap9BlurLightBlendingFilter();
	afx_msg void OnChap9SoftenFilter();
	afx_msg void OnChap9CompareBlurFilter();
	afx_msg void OnChap9CreateGaussianNoise();
	afx_msg void OnChap9CreateExponetialNoise();
	afx_msg void OnChap9CreatePossionlNoise();
	afx_msg void OnChap9CreateUniformNoise();
	afx_msg void OnChap9CreateImpulseNoise();
	afx_msg void OnChap9CreateSaltPepperNoise();
	afx_msg void OnChap9CompareNoise1();
	afx_msg void OnChap9CreateMultiGaussianNoise();
	afx_msg void OnChap9CreateLaplacianNoise();
	afx_msg void OnChap9CompareNoise2();
	afx_msg void OnChap9MedianFilteringQuicksort();
	afx_msg void OnChap9MedianFilteringQuickselect();
	afx_msg void OnChap9MedianFilteringWirth();
	afx_msg void OnChap9MeanFiltering();
	afx_msg void OnChap9AlphaTrimmedFiltering();
	afx_msg void OnChap9OpeningClosingFiltering();
	afx_msg void OnChap9MaxminFiltering();
	afx_msg void OnChap9GaussianSmoothingFiltering();
	afx_msg void OnChap9GradientEdge();
	afx_msg void OnChap9RangeFilterEdge();
	afx_msg void OnChapSobelEdgeCvsobel();
	afx_msg void OnChap9SobelEdgeMask();
	afx_msg void OnChap9SobelEdge7x7();
	afx_msg void OnChap9SobelDigonalEdge();
	afx_msg void OnChap9PrewittEdge();
	afx_msg void OnChap9RobertsEdge();
	afx_msg void OnChap9EdgeCompare();
	afx_msg void OnChap9LaplacianEdgeMask();
	afx_msg void OnChap9LaplacianEdgeCvlaplace();
	afx_msg void OnChap9LaplacianSharpening();
	afx_msg void OnChap9CompareSobelEdge();
	afx_msg void OnChap9CompareLaplacianEdge();
	afx_msg void OnChap9LogEdgeMask();
	afx_msg void OnChap9LogEdgeFormular();
	afx_msg void OnChap9CannyEdgeCvcanny();
	afx_msg void OnChap9CannyEdgeMask();
	afx_msg void OnChap9CompareCannyEdge();
	afx_msg void OnChap9StoachasticEdge();
	afx_msg void OnChapFreiChenEdge();
	afx_msg void OnChap10Erode();
	afx_msg void OnChap10Dilate();
	afx_msg void OnChap10Opening();
	afx_msg void OnChap10Closing();
	afx_msg void OnChap10Tophat();
	afx_msg void OnChap10TophatContrast();
	afx_msg void OnChap10Well();
	afx_msg void OnChap10WellContrast();
	afx_msg void OnChap10MorphologyGradient();
	afx_msg void OnChap10MorphologySmoothing();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OpenMFCView.cpp
inline COpenMFCDoc* COpenMFCView::GetDocument()
   { return (COpenMFCDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPENMFCVIEW_H__6C7685BB_F1F9_40F9_98F3_E082ED00F525__INCLUDED_)
