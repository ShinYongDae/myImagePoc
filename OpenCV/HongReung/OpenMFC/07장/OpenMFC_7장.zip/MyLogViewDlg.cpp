// MyLogViewDlg.cpp : implementation file
//

#include "stdafx.h"
#include "openmfc.h"
#include "MyLogViewDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyLogViewDlg dialog


//DEL CMyLogViewDlg::CMyLogViewDlg(CWnd* pParent /*=NULL*/)
//DEL 	: CDialog(CMyLogViewDlg::IDD, pParent)
//DEL {
//DEL 	//{{AFX_DATA_INIT(CMyLogViewDlg)
//DEL 		// NOTE: the ClassWizard will add member initialization here
//DEL 	//}}AFX_DATA_INIT
//DEL }


//DEL void CMyLogViewDlg::DoDataExchange(CDataExchange* pDX)
//DEL {
//DEL 	CDialog::DoDataExchange(pDX);
//DEL 	//{{AFX_DATA_MAP(CMyLogViewDlg)
//DEL 		// NOTE: the ClassWizard will add DDX and DDV calls here
//DEL 	//}}AFX_DATA_MAP
//DEL }


BEGIN_MESSAGE_MAP(CMyLogViewDlg, CDialog)
	//{{AFX_MSG_MAP(CMyLogViewDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyLogViewDlg message handlers
