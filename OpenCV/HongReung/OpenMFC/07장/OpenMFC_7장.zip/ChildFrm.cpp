// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "OpenMFC.h"

#include "ChildFrm.h"
#include "OpenMFCDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
	// TODO: add member initialization code here
	
}

CChildFrame::~CChildFrame()
{
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	if( !CMDIChildWnd::PreCreateWindow(cs) )
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers



void CChildFrame::OnClose() 
{
	COpenMFCDoc *pDoc = (COpenMFCDoc *)this->GetActiveDocument();
	ASSERT_VALID(pDoc);
	
	char szFilter[] = "JPEG file(*.jpeg, *.jpg, *.jpe) | *.jpg; *.jpeg; *.jpe |\
Portable Network Graphics file(*.png) | *.png |\
Windows bitmap files(*.bmp, *.dib) | *.bmp; *.dib |\
Sun rasters(*.sr, *.ras) | *.sr; *.ras |\
TIFF files(*.tiff, *.tif) | *.tiff; *.tif |\
�����ϴ� ��� ���� ����|*.jpeg; *.jpg; *.jpe; *.png; *.bmp; *.dib; *.sr; *.ras; *.tiff; *.tif ||";	

	// ���� ������� ��� '�ٸ� ���� �̸����� ����' �Լ� ȣ��
	if( !pDoc->m_szPathName 
		|| pDoc->m_szPathName[0] == '\0' 
		|| pDoc->m_cvvImageBuffer_pos >= 1 ) 
	{
		// ���ϸ��� ���� ��� â �������� �����Ѵ�.
		if( !pDoc->m_szPathName || pDoc->m_szPathName[0] == '\0' )
			strcpy( pDoc->m_szPathName, pDoc->GetTitle() );

		CFileDialog fileDlg(FALSE, 
				  pDoc->m_szPathName, 
				  NULL, 
				  OFN_OVERWRITEPROMPT, 
				  szFilter
				  );

		int iReturn = fileDlg.DoModal();
		
		if( iReturn == IDOK )
		{
			// �ٸ� �̸����� ������ ���� ��θ��� �����´�.
			CString save_pathName = fileDlg.GetPathName(); 

			pDoc->OnSaveDocument( save_pathName );
		}
		else
		{
			strcpy( pDoc->m_szPathName, "" );
		}
	}
	// ���� ������ ��� 
	else
	{
		pDoc->OnSaveDocument( pDoc->m_szPathName );
	}

	CMDIChildWnd::OnClose();
}
