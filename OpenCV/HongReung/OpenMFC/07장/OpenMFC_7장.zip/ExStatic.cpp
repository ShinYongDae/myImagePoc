// ExStatic.cpp : implementation file
//

#include "stdafx.h"
#include "openmfc.h"
#include "ExStatic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExStatic
COLORREF CExStatic::BrushColor = 0x000000FF; // Red 

CExStatic::CExStatic()
{
	m_pBkBrush = new CBrush(BrushColor);
	
}

CExStatic::~CExStatic()
{
	delete m_pBkBrush; 
    m_pBkBrush = NULL;
}


BEGIN_MESSAGE_MAP(CExStatic, CStatic)
	//{{AFX_MSG_MAP(CExStatic)
	ON_WM_CTLCOLOR_REFLECT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExStatic message handlers

HBRUSH CExStatic::CtlColor(CDC* pDC, UINT nCtlColor) 
{
	switch (nCtlColor) { 
        case CTLCOLOR_STATIC: 
            // Change background color and return the background brush. 
            pDC->SetBkColor(BrushColor); 
			
            return (HBRUSH)(m_pBkBrush->GetSafeHandle()); 
            break; //lint !e527 unreachable 


        default: 
            return CStatic::OnCtlColor(pDC, this, nCtlColor); 
    } 

}

/*
void CExStatic::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	/*
	CBrush brush; 
    brush.CreateSolidBrush(RGB(0,0,255));    // black brush 

    CBrush* pOldBrush = dc.SelectObject(&brush);    // select in the right brush, keep pointer to old one 

    // do your drawing
	CRect rect;
	this->GetWindowRect(&rect);
	dc.Rectangle(0, 0, rect.Width(), rect.Height());
	
    // tidy up phase 
    dc.SelectObject(pOldBrush);
    brush.DeleteObject();    // optional - MFC will do this for you when the
	// Do not call CStatic::OnPaint() for painting messages
	*/
//}
//*/
void CExStatic::SetBit(HBITMAP bit)
{
	m_hBitmap = bit;
}

