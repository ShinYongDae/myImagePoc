//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OpenMFC.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_LOGVIEW_BAR                 103
#define IDR_MAINFRAME                   128
#define IDR_OPENMFTYPE                  129
#define IDD_SFILTER_DIALOG              140
#define IDD_FACE_DETECT_DIALOG          148
#define IDC_LOGVIEW_EDIT                1004
#define IDC_COMBO_FILTER_TYPE           1009
#define IDC_PREVIEW_BUTTON              1010
#define IDC_INITIAL_BUTTON              1011
#define IDC_PREVIEW_IMAGE               1012
#define IDC_PAUSE_BUTTON                1024
#define IDC_RESUME_BUTTON               1025
#define IDC_CAPTURE_BUTTON              1026
#define IDC_RESULT_BUTTON               1027
#define IDC_FD_MESSAGE_EDIT             1028
#define IDC_GB_STATIC                   1029
#define ID_FILE_ALL_CLOSE               32771
#define ID_CHAP5_SPLIT_RGB              32773
#define ID_CHAP5_FILTER2D               32774
#define ID_CAMERA_FACE_DETECT           32779
#define ID_CHAP6_RGB2GRAY               32780
#define ID_CHAP6_SPLIT_RGB              32781
#define ID_CHAP6_COMPOSITE_RGB          32782
#define ID_CHAP7_SPLIT_HLS              32783
#define ID_CHAP6_COMPOSITE_HLS          32784
#define ID_CHAP7_SPLIT2_RGB             32785
#define ID_CHAP7_SPLIT_HSV              32786
#define ID_CHAP7_COMPOSITE_HSV          32787
#define ID_CHAP7_SPLIT_YCBCR            32788
#define ID_CHAP7_COMPOSITE_YCBCR        32789
#define ID_CHAP7_RGB2GRAY               32790
#define ID_CHAP7_SPLIT_RGB              32791
#define ID_CHAP7_COMPOSITE_RGB          32792

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32793
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
