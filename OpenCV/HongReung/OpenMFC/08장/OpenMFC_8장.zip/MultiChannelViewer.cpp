// MultiChannelViewer.cpp: implementation of the CMultiChannelViewer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "openmfc.h"
#include "MultiChannelViewer.h"

// ȭ�� ���
#include "MainFrm.h"
#include "ChildFrm.h"
#include "OpenMFCDoc.h"

#include "Color.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMultiChannelViewer::CMultiChannelViewer()
{
    heightCnt = 0;
	widthCnt = 0;
	this->maxDisplayCnt_height = 3;
	this->maxDisplayCnt_width = 3;
	init(this->heightCnt, this->widthCnt);
}

CMultiChannelViewer::CMultiChannelViewer(int heightCnt, int widthCnt)
{
    this->heightCnt = heightCnt;
	this->widthCnt = widthCnt;
	this->maxDisplayCnt_height = 3;
	this->maxDisplayCnt_width = 3;
	init(this->heightCnt, this->widthCnt);
}

CMultiChannelViewer::~CMultiChannelViewer()
{
	int i, j;
	
	for(i=0; i<heightCnt; i++)
	{
		for(j=0; j<widthCnt; j++)
		{
			if( displayImage[i][j].image )
			{
				cvReleaseImage( &(displayImage[i][j].image) );
			}
		}

		free(displayImage[i]);
	}

	free(displayImage);
}


void CMultiChannelViewer::init(int heightCnt, int widthCnt)
{
	background_var = 192;
	text_var = 0;

	bool checked = true;

	// ���� ó�� 
	if(heightCnt < 0 || widthCnt < 0) checked = false;
	else if( heightCnt*widthCnt == 0 || heightCnt*widthCnt == 1 ) checked = false;
	else if(heightCnt  > maxDisplayCnt_height) checked = false;
	else if(widthCnt  > maxDisplayCnt_width) checked = false;

	if( !checked )
	{
		AfxMessageBox( "�� ũ�⸦ 3x3 �̸����� ��� �ֽʽÿ�!", MB_ICONSTOP );
		return;	
	}

	// displayImage, displayImage_title �ʱ�ȭ
	displayImage  = (IplImageSet **)calloc(heightCnt, sizeof(IplImageSet *));

	for(int i=0; i<heightCnt; i++)
	{
		displayImage[i] = (IplImageSet *)calloc(widthCnt, sizeof(IplImageSet));
	}       
}

// â ��� ��ġ ����
void CMultiChannelViewer::GS_setPosition(int heightPos, int widthPos, IplImage *image, char *title) 
{
	// ���� ����.
	IplImage *textImage = GS_insertText( image, title );
	displayImage[heightPos][widthPos].image = (IplImage *)cvCloneImage( textImage );
	strcpy( displayImage[heightPos][widthPos].title, title );
	cvReleaseImage( &textImage );
}

// ���� ����
IplImage *CMultiChannelViewer::GS_insertText( IplImage *src_image, char *title )
{
	int i,j;
	int margin_height = 10;
	int margin_width = 10;

    int nChannels = src_image->nChannels;
    IplImage *dst_image = cvCreateImage( cvSize(src_image->width+margin_width*2, 
										 src_image->height+35), 
										 IPL_DEPTH_8U, nChannels );

	// ��Ʈ ����(only ������)	
	CvFont font;
    float hscale      = 0.4f;
    float vscale      = 0.4f;
    float italicscale = 0.0f;
    int  thickness    = 1;
    cvInitFont (&font, CV_FONT_HERSHEY_SIMPLEX , hscale, vscale, italicscale, thickness, CV_AA);

    if( nChannels == 1 )
    {
        cvSet( dst_image, cvScalarAll(background_var), 0 ); 
        for( i=0; i<src_image->height; i++ ) 
        {
            for( j=0; j<src_image->width; j++)
            {
                cvSetReal2D( dst_image, i+margin_height, j+margin_width, cvGetReal2D( src_image, i, j ) ); 
            }
        }

        cvPutText( dst_image, title, cvPoint(margin_width, src_image->height+margin_height/2+20), &font, cvScalar(text_var, text_var, text_var) );    
    }

    else if( nChannels == 3 )
    {
        cvSet( dst_image, cvScalarAll(background_var), 0 );
        
        IplImage *src_r = cvCreateImage( cvGetSize(src_image), IPL_DEPTH_8U, 1 );
        IplImage *src_g = cvCreateImage( cvGetSize(src_image), IPL_DEPTH_8U, 1 );
        IplImage *src_b = cvCreateImage( cvGetSize(src_image), IPL_DEPTH_8U, 1 );
        cvCvtPixToPlane( src_image, src_r, src_g, src_b, NULL );
		
        IplImage *dst_r = cvCreateImage( cvGetSize(dst_image), IPL_DEPTH_8U, 1 );
        IplImage *dst_g = cvCreateImage( cvGetSize(dst_image), IPL_DEPTH_8U, 1 );
        IplImage *dst_b = cvCreateImage( cvGetSize(dst_image), IPL_DEPTH_8U, 1 );
        cvCvtPixToPlane( dst_image, dst_r, dst_g, dst_b, NULL );
		
        for( i=0; i<src_image->height; i++ ) 
        {
            for( j=0; j<src_image->width; j++)
            {
                cvSetReal2D( dst_r, i+margin_height, j+margin_width, cvGetReal2D( src_r, i, j) ); 
                cvSetReal2D( dst_g, i+margin_height, j+margin_width, cvGetReal2D( src_g, i, j) ); 
                cvSetReal2D( dst_b, i+margin_height, j+margin_width, cvGetReal2D( src_b, i, j) ); 
            }
        }
		
        cvCvtPlaneToPix( dst_r, dst_g, dst_b, NULL, dst_image );
        cvPutText( dst_image, title, cvPoint(margin_width, src_image->height+margin_height/2+20), &font, cvScalar(text_var, text_var, text_var) ); 
	
        cvReleaseImage( &src_r );
        cvReleaseImage( &src_g );
        cvReleaseImage( &src_b );
		
        cvReleaseImage( &dst_r );
        cvReleaseImage( &dst_g );
        cvReleaseImage( &dst_b );
    }
	
    return dst_image;
}

// â ��� 
void CMultiChannelViewer::GS_run(char *caption_title)
{
	CMainFrame *pFrame = (CMainFrame *)AfxGetMainWnd();
	CChildFrame *pChild = (CChildFrame *)pFrame->GetActiveFrame();
	COpenMFCDoc *pDoc = (COpenMFCDoc *)pChild->GetActiveDocument();

	IplImage *result_image = GS_make_IplImage();

	// ���н�
	if( !result_image ) return;

	// ���ο� â�� ����.
	pDoc->CopyClipBoard( result_image );
	((COpenMFCApp *)AfxGetApp())->OnEditPaste();

	// â ������ �����Ѵ�.
	COpenMFCDoc *pDoc1 = (COpenMFCDoc *)
		((CMDIFrameWnd*)AfxGetMainWnd())->GetActiveFrame()
		->GetActiveDocument();

	pDoc1->SetTitle(caption_title);	

	return;
}

// �ϳ��� IplImage�� ��ȯ�Ѵ�.
IplImage *CMultiChannelViewer::GS_make_IplImage()
{
	int i, j, m, n;
	int all_height = 0;
	int all_width = 0;
	int tmp_all_height1 = 0;
	int tmp_all_height2 = 0;
	int tmp_all_width = 0;

	int current_height = 0;
	int current_width = 0;
        
	IplImage *displayRedIMGBuf;
	IplImage *displayGreenIMGBuf;
	IplImage *displayBlueIMGBuf;

	IplImage *tmpRedIMGBuf;
	IplImage *tmpGreenIMGBuf;
	IplImage *tmpBlueIMGBuf;
    
	for(i=0; i<heightCnt; i++)
	{
		tmp_all_width = 0;
    
		for(j=0; j<widthCnt; j++)
		{
			if(displayImage[i][j].image)
			{
				tmp_all_height1 = displayImage[i][j].image->height;
				tmp_all_width += displayImage[i][j].image->width;     
			}
			else 
			{
  				AfxMessageBox( "���� ��� �ֽ��ϴ�. ä���ֽʽÿ�!", MB_ICONSTOP );
				return NULL;	
			}

			if(tmp_all_height1 > tmp_all_height2) tmp_all_height2 = tmp_all_height1;
		}

		if(tmp_all_width > all_width) all_width = tmp_all_width;
		all_height += tmp_all_height2;
	}

	// �޸� �Ҵ�
	displayRedIMGBuf = cvCreateImage( cvSize(all_width, all_height), IPL_DEPTH_8U, 1 );
	displayGreenIMGBuf = cvCreateImage( cvSize(all_width, all_height), IPL_DEPTH_8U, 1 );
	displayBlueIMGBuf = cvCreateImage( cvSize(all_width, all_height), IPL_DEPTH_8U, 1 );
       
	CColor cColor;

	// ȭ�Ұ��� ���� �ֱ�.  
	for(i=0; i<heightCnt; i++)
	{
		for(j=0; j<widthCnt; j++)
		{
			cColor.GS_splitRGB( displayImage[i][j].image, 
							    &tmpRedIMGBuf,
							    &tmpGreenIMGBuf,
							    &tmpBlueIMGBuf );

			tmp_all_height1 = displayImage[i][j].image->height;
        
			for(m=0; m<displayImage[i][j].image->height; m++)
			{
				for(n=0; n<displayImage[i][j].image->width; n++)
				{
					cvSetReal2D( displayRedIMGBuf, m+current_height, n+current_width, cvGetReal2D( tmpRedIMGBuf, m, n ) ); 
					cvSetReal2D( displayGreenIMGBuf, m+current_height, n+current_width, cvGetReal2D( tmpGreenIMGBuf, m, n ) ); 
					cvSetReal2D( displayBlueIMGBuf, m+current_height, n+current_width, cvGetReal2D( tmpBlueIMGBuf, m, n ) ); 
				}   
			}

			current_width += displayImage[i][j].image->width;  
			if(tmp_all_height1 > tmp_all_height2) tmp_all_height2 = tmp_all_height1;

			cvReleaseImage( &tmpRedIMGBuf );
			cvReleaseImage( &tmpGreenIMGBuf );
			cvReleaseImage( &tmpBlueIMGBuf );
		}

		current_height  += tmp_all_height2;
		current_width = 0;
	}       

	IplImage *image = cvCreateImage(cvSize(all_width, all_height), IPL_DEPTH_8U, 3);
	cvCvtPlaneToPix( displayBlueIMGBuf, displayGreenIMGBuf, displayRedIMGBuf, NULL, image );

	cvReleaseImage( &displayRedIMGBuf );
	cvReleaseImage( &displayGreenIMGBuf );
	cvReleaseImage( &displayBlueIMGBuf );

	return image;
}