//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OpenMFC.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_LOGVIEW_BAR                 103
#define IDR_MAINFRAME                   128
#define IDR_OPENMFTYPE                  129
#define IDD_SFILTER_DIALOG              140
#define IDD_FACE_DETECT_DIALOG          148
#define IDC_LOGVIEW_EDIT                1004
#define IDC_COMBO_FILTER_TYPE           1009
#define IDC_PREVIEW_BUTTON              1010
#define IDC_INITIAL_BUTTON              1011
#define IDC_PREVIEW_IMAGE               1012
#define IDC_PAUSE_BUTTON                1024
#define IDC_RESUME_BUTTON               1025
#define IDC_CAPTURE_BUTTON              1026
#define IDC_RESULT_BUTTON               1027
#define IDC_FD_MESSAGE_EDIT             1028
#define IDC_GB_STATIC                   1029
#define ID_FILE_ALL_CLOSE               32771
#define ID_CHAP5_SPLIT_RGB              32773
#define ID_CHAP5_FILTER2D               32774
#define ID_CAMERA_FACE_DETECT           32779
#define ID_CHAP6_RGB2GRAY               32780
#define ID_CHAP6_SPLIT_RGB              32781
#define ID_CHAP6_COMPOSITE_RGB          32782
#define ID_CHAP7_SPLIT_HLS              32783
#define ID_CHAP6_COMPOSITE_HLS          32784
#define ID_CHAP7_SPLIT2_RGB             32785
#define ID_CHAP7_SPLIT_HSV              32786
#define ID_CHAP7_COMPOSITE_HSV          32787
#define ID_CHAP7_SPLIT_YCBCR            32788
#define ID_CHAP7_COMPOSITE_YCBCR        32789
#define ID_CHAP7_RGB2GRAY               32790
#define ID_CHAP7_SPLIT_RGB              32791
#define ID_CHAP7_COMPOSITE_RGB          32792
#define ID_CHAP8_MAKE_GRAY_BAND         32793
#define ID_CHAP8_ADDSUB_CONSTANT        32794
#define ID_CHAP8_ADD_IMAGE              32795
#define ID_CHAP8_SUBTRACT_IMAGE         32796
#define ID_CHAP8_BLENDING_EFFECT        32797
#define HAP8_MAKE_CONTRAST              32798
#define ID_CHAP8_MUL_CONSTANT           32800
#define ID_CHAP8_DIV_CONSTANT           32801
#define ID_CHAP8_CONTRAST_BRIGHTNESS    32803
#define ID_CHAP8_IM_HIST_GRAY_IMAGE     32804
#define ID_CHAP8_IM_HIST_GRAY_BRIGHTNESS 32805
#define ID_CHAP8_IM_HIST_GRAY_CONTRAST  32806
#define ID_CHAP8_HISTOGRAM_EQUALIZATION 32807
#define ID_CHAP8_VIEW_HIST_DATA         32808
#define ID_CHAP8_LUT_BASIC_CONTRAST_BRIGHNESS 32809
#define ID_CHAP8_THRESHOLD              32810
#define ID_CHAP8_ADAPTIVE_THRESHOLD     32811
#define ID_CHAP8_BINARY_LOGICAL_AND     32813
#define ID_CHAP8_BINARY_LOGICAL_NAND    32814
#define ID_CHAP8_BINARY_LOGICAL_OR      32815
#define ID_CHAP8_GRAY_LOGICAL_AND       32816
#define ID_CHAP8_GRAY_LOGIC_NAND        32817
#define ID_CHAP8_GRAY_LOGIC_OR          32818

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32819
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
