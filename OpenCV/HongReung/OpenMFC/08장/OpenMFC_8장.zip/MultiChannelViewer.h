// MultiChannelViewer.h: interface for the CMultiChannelViewer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MULTICHANNELVIEWER_H__EDE8DBC0_74BD_4EE6_9A60_933A0E030579__INCLUDED_)
#define AFX_MULTICHANNELVIEWER_H__EDE8DBC0_74BD_4EE6_9A60_933A0E030579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMultiChannelViewer  
{
public:
	CMultiChannelViewer();
	CMultiChannelViewer(int heightCnt, int widthCnt);
	virtual ~CMultiChannelViewer();

	typedef struct {
		IplImage *image;
		char title[128];
	} IplImageSet;

	IplImageSet **displayImage;

	// â ��� ��ġ ����
	void GS_setPosition(int heightPos, int widthPos, IplImage *image, char *title);
	
	// â ��� 
	void GS_run(char *caption_title);

	// ���� ����
	IplImage *GS_insertText( IplImage *image, char *title );

	// â�� ����� ���� �������� 
	IplImage *GS_make_IplImage();

private:
    int heightCnt;
	int widthCnt;
	int maxDisplayCnt_height;
	int maxDisplayCnt_width;
	int background_var;
	int text_var;

	// �ʱ�ȭ 
	void init(int heightCnt, int widthCnt);

};

#endif // !defined(AFX_MULTICHANNELVIEWER_H__EDE8DBC0_74BD_4EE6_9A60_933A0E030579__INCLUDED_)
