// OpenMFCView.h : interface of the COpenMFCView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OPENMFCVIEW_H__6C7685BB_F1F9_40F9_98F3_E082ED00F525__INCLUDED_)
#define AFX_OPENMFCVIEW_H__6C7685BB_F1F9_40F9_98F3_E082ED00F525__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class COpenMFCView : public CScrollView
{
protected: // create from serialization only
	COpenMFCView();
	DECLARE_DYNCREATE(COpenMFCView)

// Attributes
public:
	COpenMFCDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COpenMFCView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COpenMFCView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COpenMFCView)
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveAs();
	afx_msg void OnEditCopy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnUpdateFileNew(CCmdUI* pCmdUI);
	afx_msg void OnSplitRGB();
	afx_msg void OnFilter2D();
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateEditUndo(CCmdUI* pCmdUI);
	afx_msg void OnEditRedo();
	afx_msg void OnChap7Rgb2gray();
	afx_msg void OnChap7SplitRgb();
	afx_msg void OnChap7CompositeRgb();
	afx_msg void OnChap7Split2Rgb();
	afx_msg void OnChap7SplitHsv();
	afx_msg void OnChap7CompositeHsv();
	afx_msg void OnChap7SplitYcbcr();
	afx_msg void OnChap7CompositeYcbcr();
	afx_msg void OnChap8MakeGrayBand();
	afx_msg void OnChap8AddsubConstant();
	afx_msg void OnChap8AddImage();
	afx_msg void OnChap8SubtractImage();
	afx_msg void OnChap8BlendingEffect();
	afx_msg void OnChap8MakeContrast();
	afx_msg void OnChap8MulConstrant();
	afx_msg void OnChap8MulConstant();
	afx_msg void OnChap8DivConstant();
	afx_msg void OnChap8ContrastBrightness();
	afx_msg void OnChap8ImHistGrayImage();
	afx_msg void OnChap8ImHistGrayBrightness();
	afx_msg void OnChap8ImHistGrayContrast();
	afx_msg void OnChap8HistogramEqualization();
	afx_msg void OnChap8ViewHistData();
	afx_msg void OnChap8LutBasicContrastBrighness();
	afx_msg void OnChap8Threshold();
	afx_msg void OnChap8AdaptiveThreshold();
	afx_msg void OnChap8BinaryLogicalAnd();
	afx_msg void OnChap8BinaryLogicalNand();
	afx_msg void OnChap8BinaryLogicalOr();
	afx_msg void OnChap8GrayLogicalAnd();
	afx_msg void OnChap8GrayLogicNand();
	afx_msg void OnChap8GrayLogicOr();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OpenMFCView.cpp
inline COpenMFCDoc* COpenMFCView::GetDocument()
   { return (COpenMFCDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPENMFCVIEW_H__6C7685BB_F1F9_40F9_98F3_E082ED00F525__INCLUDED_)
