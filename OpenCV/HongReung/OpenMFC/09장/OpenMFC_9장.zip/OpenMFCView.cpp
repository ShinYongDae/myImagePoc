// OpenMFCView.cpp : implementation of the COpenMFCView class
//

#include "stdafx.h"
#include "OpenMFC.h"

#include "OpenMFCDoc.h"
#include "OpenMFCView.h"

#include "Color.h"
#include "FilterDlg.h"
#include "Util.h"
#include "MultiChannelViewer.h"
#include "Pixel.h"
#include "Filter.h"
#include "Noise.h"
#include "Edge.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COpenMFCView

IMPLEMENT_DYNCREATE(COpenMFCView, CScrollView)

BEGIN_MESSAGE_MAP(COpenMFCView, CScrollView)
	//{{AFX_MSG_MAP(COpenMFCView)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_WM_ERASEBKGND()
	ON_UPDATE_COMMAND_UI(ID_FILE_NEW, OnUpdateFileNew)
	ON_COMMAND(ID_CHAP5_SPLIT_RGB, OnSplitRGB)
	ON_COMMAND(ID_CHAP5_FILTER2D, OnFilter2D)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_COMMAND(ID_EDIT_REDO, OnEditRedo)
	ON_COMMAND(ID_CHAP7_RGB2GRAY, OnChap7Rgb2gray)
	ON_COMMAND(ID_CHAP7_SPLIT_RGB, OnChap7SplitRgb)
	ON_COMMAND(ID_CHAP7_COMPOSITE_RGB, OnChap7CompositeRgb)
	ON_COMMAND(ID_CHAP7_SPLIT2_RGB, OnChap7Split2Rgb)
	ON_COMMAND(ID_CHAP7_SPLIT_HSV, OnChap7SplitHsv)
	ON_COMMAND(ID_CHAP7_COMPOSITE_HSV, OnChap7CompositeHsv)
	ON_COMMAND(ID_CHAP7_SPLIT_YCBCR, OnChap7SplitYcbcr)
	ON_COMMAND(ID_CHAP7_COMPOSITE_YCBCR, OnChap7CompositeYcbcr)
	ON_COMMAND(ID_CHAP8_MAKE_GRAY_BAND, OnChap8MakeGrayBand)
	ON_COMMAND(ID_CHAP8_ADDSUB_CONSTANT, OnChap8AddsubConstant)
	ON_COMMAND(ID_CHAP8_ADD_IMAGE, OnChap8AddImage)
	ON_COMMAND(ID_CHAP8_SUBTRACT_IMAGE, OnChap8SubtractImage)
	ON_COMMAND(ID_CHAP8_BLENDING_EFFECT, OnChap8BlendingEffect)
	ON_COMMAND(HAP8_MAKE_CONTRAST, OnChap8MakeContrast)
	ON_COMMAND(ID_CHAP8_MUL_CONSTANT, OnChap8MulConstant)
	ON_COMMAND(ID_CHAP8_DIV_CONSTANT, OnChap8DivConstant)
	ON_COMMAND(ID_CHAP8_CONTRAST_BRIGHTNESS, OnChap8ContrastBrightness)
	ON_COMMAND(ID_CHAP8_IM_HIST_GRAY_IMAGE, OnChap8ImHistGrayImage)
	ON_COMMAND(ID_CHAP8_IM_HIST_GRAY_BRIGHTNESS, OnChap8ImHistGrayBrightness)
	ON_COMMAND(ID_CHAP8_IM_HIST_GRAY_CONTRAST, OnChap8ImHistGrayContrast)
	ON_COMMAND(ID_CHAP8_HISTOGRAM_EQUALIZATION, OnChap8HistogramEqualization)
	ON_COMMAND(ID_CHAP8_VIEW_HIST_DATA, OnChap8ViewHistData)
	ON_COMMAND(ID_CHAP8_LUT_BASIC_CONTRAST_BRIGHNESS, OnChap8LutBasicContrastBrighness)
	ON_COMMAND(ID_CHAP8_THRESHOLD, OnChap8Threshold)
	ON_COMMAND(ID_CHAP8_ADAPTIVE_THRESHOLD, OnChap8AdaptiveThreshold)
	ON_COMMAND(ID_CHAP8_BINARY_LOGICAL_AND, OnChap8BinaryLogicalAnd)
	ON_COMMAND(ID_CHAP8_BINARY_LOGICAL_NAND, OnChap8BinaryLogicalNand)
	ON_COMMAND(ID_CHAP8_BINARY_LOGICAL_OR, OnChap8BinaryLogicalOr)
	ON_COMMAND(ID_CHAP8_GRAY_LOGICAL_AND, OnChap8GrayLogicalAnd)
	ON_COMMAND(ID_CHAP8_GRAY_LOGIC_NAND, OnChap8GrayLogicNand)
	ON_COMMAND(ID_CHAP8_GRAY_LOGIC_OR, OnChap8GrayLogicOr)
	ON_COMMAND(ID_CHAP9_CONV2, OnChap9Conv2)
	ON_COMMAND(ID_CHAP9_GRAY_EMBOSSING, OnChap9GrayEmbossing)
	ON_COMMAND(ID_CHAP9_RGB_EMBOSSING, OnChap9RgbEmbossing)
	ON_COMMAND(ID_CHAP9_HSV_EMBOSSING, OnChap9HsvEmbossing)
	ON_COMMAND(ID_CHAP9_WILD_EMBOSSING, OnChap9WildEmbossing)
	ON_COMMAND(ID_CHAP9_BLURRING1, OnChap9Blurring1)
	ON_COMMAND(ID_CHAP9_BLURRING2, OnChap9Blurring2)
	ON_COMMAND(ID_CHAP9_SHARPENING, OnChap9Sharpening)
	ON_COMMAND(ID_CHAP9_HIGH_BOOST, OnChap9HighBoost)
	ON_COMMAND(ID_CHAP9_UNSHARPENING, OnChap9Unsharpening)
	ON_COMMAND(ID_CHAP9_ENHANCE_FILTER, OnChap9EnhanceFilter)
	ON_COMMAND(ID_CHAP9_BLUR_LIGHT_BLENDING_FILTER, OnChap9BlurLightBlendingFilter)
	ON_COMMAND(ID_CHAP9_SOFTEN_FILTER, OnChap9SoftenFilter)
	ON_COMMAND(ID_CHAP9_COMPARE_BLUR_FILTER, OnChap9CompareBlurFilter)
	ON_COMMAND(ID_CHAP9_CREATE_GAUSSIAN_NOISE, OnChap9CreateGaussianNoise)
	ON_COMMAND(ID_CHAP9_CREATE_EXPONETIAL_NOISE, OnChap9CreateExponetialNoise)
	ON_COMMAND(ID_CHAP9_CREATE_POSSIONL_NOISE, OnChap9CreatePossionlNoise)
	ON_COMMAND(ID_CHAP9_CREATE_UNIFORM_NOISE, OnChap9CreateUniformNoise)
	ON_COMMAND(ID_CHAP9_CREATE_IMPULSE_NOISE, OnChap9CreateImpulseNoise)
	ON_COMMAND(ID_CHAP9_CREATE_SALT_PEPPER_NOISE, OnChap9CreateSaltPepperNoise)
	ON_COMMAND(ID_CHAP9_COMPARE_NOISE_1, OnChap9CompareNoise1)
	ON_COMMAND(ID_CHAP9_CREATE_MULTI_GAUSSIAN_NOISE, OnChap9CreateMultiGaussianNoise)
	ON_COMMAND(ID_CHAP9_CREATE_LAPLACIAN_NOISE, OnChap9CreateLaplacianNoise)
	ON_COMMAND(ID_CHAP9_COMPARE_NOISE_2, OnChap9CompareNoise2)
	ON_COMMAND(ID_CHAP9_MEDIAN_FILTERING_QUICKSORT, OnChap9MedianFilteringQuicksort)
	ON_COMMAND(ID_CHAP9_MEDIAN_FILTERING_QUICKSELECT, OnChap9MedianFilteringQuickselect)
	ON_COMMAND(ID_CHAP9_MEDIAN_FILTERING_WIRTH, OnChap9MedianFilteringWirth)
	ON_COMMAND(ID_CHAP9_MEAN_FILTERING, OnChap9MeanFiltering)
	ON_COMMAND(ID_CHAP9_ALPHA_TRIMMED_FILTERING, OnChap9AlphaTrimmedFiltering)
	ON_COMMAND(ID_CHAP9_OPENING_CLOSING_FILTERING, OnChap9OpeningClosingFiltering)
	ON_COMMAND(ID_CHAP9_MAXMIN_FILTERING, OnChap9MaxminFiltering)
	ON_COMMAND(ID_CHAP9_GAUSSIAN_SMOOTHING_FILTERING, OnChap9GaussianSmoothingFiltering)
	ON_COMMAND(ID_CHAP9_GRADIENT_EDGE, OnChap9GradientEdge)
	ON_COMMAND(ID_CHAP9_RANGE_FILTER_EDGE, OnChap9RangeFilterEdge)
	ON_COMMAND(ID_CHAP_SOBEL_EDGE_CVSOBEL, OnChapSobelEdgeCvsobel)
	ON_COMMAND(ID_CHAP9_SOBEL_EDGE_MASK, OnChap9SobelEdgeMask)
	ON_COMMAND(ID_CHAP9_SOBEL_EDGE_7X7, OnChap9SobelEdge7x7)
	ON_COMMAND(ID_CHAP9_SOBEL_DIGONAL_EDGE, OnChap9SobelDigonalEdge)
	ON_COMMAND(ID_CHAP9_PREWITT_EDGE, OnChap9PrewittEdge)
	ON_COMMAND(ID_CHAP9_ROBERTS_EDGE, OnChap9RobertsEdge)
	ON_COMMAND(ID_CHAP9_EDGE_COMPARE, OnChap9EdgeCompare)
	ON_COMMAND(ID_CHAP9_LAPLACIAN_EDGE_MASK, OnChap9LaplacianEdgeMask)
	ON_COMMAND(ID_CHAP9_LAPLACIAN_EDGE_CVLAPLACE, OnChap9LaplacianEdgeCvlaplace)
	ON_COMMAND(ID_CHAP9_LAPLACIAN_SHARPENING, OnChap9LaplacianSharpening)
	ON_COMMAND(ID_CHAP9_COMPARE_SOBEL_EDGE, OnChap9CompareSobelEdge)
	ON_COMMAND(ID_CHAP9_COMPARE_LAPLACIAN_EDGE, OnChap9CompareLaplacianEdge)
	ON_COMMAND(ID_CHAP9_LOG_EDGE_MASK, OnChap9LogEdgeMask)
	ON_COMMAND(ID_CHAP9_LOG_EDGE_FORMULAR, OnChap9LogEdgeFormular)
	ON_COMMAND(ID_CHAP9_CANNY_EDGE_CVCANNY, OnChap9CannyEdgeCvcanny)
	ON_COMMAND(ID_CHAP9_CANNY_EDGE_MASK, OnChap9CannyEdgeMask)
	ON_COMMAND(ID_CHAP9_COMPARE_CANNY_EDGE, OnChap9CompareCannyEdge)
	ON_COMMAND(ID_CHAP9_STOACHASTIC_EDGE, OnChap9StoachasticEdge)
	ON_COMMAND(ID_CHAP_FREI_CHEN_EDGE, OnChapFreiChenEdge)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COpenMFCView construction/destruction

COpenMFCView::COpenMFCView()
{
	// TODO: add construction code here

}

COpenMFCView::~COpenMFCView()
{
}

BOOL COpenMFCView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// COpenMFCView drawing

void COpenMFCView::OnDraw(CDC* pDC)
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	// TODO: add draw code for native data here
	
	if( pDoc->m_cvvImage.GetImage() )
	{		
		int height = pDoc->m_cvvImage.Height();
		int width  = pDoc->m_cvvImage.Width();	

		CRect rect = CRect(0, 0, width, height);
		pDoc->m_cvvImage.DrawToHDC( pDC->GetSafeHdc(), &rect );

		// â ũ�⿡ ���� �ش�.
		ResizeParentToFit(FALSE);
	}
}

void COpenMFCView::OnInitialUpdate()
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CScrollView::OnInitialUpdate();

	CSize sizeTotal;

	if( pDoc->m_cvvImage.GetImage() ) 
	{
		int height = pDoc->m_cvvImage.Height();
		int width  = pDoc->m_cvvImage.Width();	
		sizeTotal = CSize(width, height);
	}
    else 
	{
		sizeTotal.cx = sizeTotal.cy = 100;
	}

	SetScrollSizes(MM_TEXT, sizeTotal);
	ResizeParentToFit(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// COpenMFCView printing

BOOL COpenMFCView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void COpenMFCView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void COpenMFCView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// COpenMFCView diagnostics

#ifdef _DEBUG
void COpenMFCView::AssertValid() const
{
	CScrollView::AssertValid();
}

void COpenMFCView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

COpenMFCDoc* COpenMFCView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(COpenMFCDoc)));
	return (COpenMFCDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COpenMFCView message handlers


void COpenMFCView::OnFileSave() 
{
	// TODO: Add your command handler code here
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	// ���� ������� ��� '�ٸ� ���� �̸����� ����' �Լ� ȣ��
	if( !pDoc->m_szPathName 
		|| pDoc->m_szPathName[0] == '\0' 
		|| pDoc->m_cvvImageBuffer_pos >= 1 ) 
	{
		OnFileSaveAs();
	}
	// ���� ������ ��� 
	else
	{
		pDoc->OnSaveDocument( pDoc->m_szPathName );
	}
}

void COpenMFCView::OnFileSaveAs() 
{
	// TODO: Add your command handler code here
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: Add your command handler code here

	// ��ȭ���ڿ� ��µ� ���ϵ��� Ȯ���ڿ� ���ؼ� �����ǵ��� ������ ����
	//
	char szFilter[] = "JPEG file(*.jpeg, *.jpg, *.jpe) | *.jpg; *.jpeg; *.jpe |\
Portable Network Graphics file(*.png) | *.png |\
Windows bitmap files(*.bmp, *.dib) | *.bmp; *.dib |\
Sun rasters(*.sr, *.ras) | *.sr; *.ras |\
TIFF files(*.tiff, *.tif) | *.tiff; *.tif |\
�����ϴ� ��� ���� ����|*.jpeg; *.jpg; *.jpe; *.png; *.bmp; *.dib; *.sr; *.ras; *.tiff; *.tif ||";	

	// ���ϸ��� ���� ��� â �������� �����Ѵ�.
	if( !pDoc->m_szPathName || pDoc->m_szPathName[0] == '\0' )
		strcpy( pDoc->m_szPathName, pDoc->GetTitle() );

	CFileDialog fileDlg(FALSE, 
			  pDoc->m_szPathName, 
			  NULL, 
			  OFN_OVERWRITEPROMPT, 
			  szFilter
			  );

	int iReturn = fileDlg.DoModal();
	
	if( iReturn == IDOK )
	{
		// �ٸ� �̸����� ������ ���� ��θ��� �����´�.
		CString save_pathName = fileDlg.GetPathName(); 

		pDoc->OnSaveDocument( save_pathName );
	}
	else
	{
		strcpy( pDoc->m_szPathName, "" );
	}
}

void COpenMFCView::OnEditCopy() 
{
	// TODO: Add your command handler code here
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// Ŭ�����忡 �����ϱ�
	pDoc->CopyClipBoard( pDoc->m_cvvImage.GetImage() );
}


BOOL COpenMFCView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	
	//return CScrollView::OnEraseBkgnd(pDC);

	// â ũ�� ������ ����� �������� �ʰ� �Ѵ�.
	// ������ ��� �������� ���� ��쿡�� �� ����� ������ ���� ����.
	return TRUE;
}

void COpenMFCView::OnUpdateFileNew(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	// ���ο� â ��Ȱ��ȭ.
	pCmdUI->Enable(false);
}

void COpenMFCView::OnSplitRGB() 
{
	//-------------------------------------------------------------------
	// STEP 1 : ��ť��Ʈ Ŭ������ �ִ� m_cvvImage�� �������� ���� ���� ȣ���Ѵ�.
	//-------------------------------------------------------------------
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//-------------------------------------------------------------------
	// STEP 2 : ������ m_cvvImage�� IplImage ���� ������ ���� �����´�.
	//-------------------------------------------------------------------

	// m_cvvImage�� IplImage�� �����´�.
	IplImage *color_image = pDoc->m_cvvImage.GetImage();

	// RGB �÷� ������ �ƴ� ��� 
	if( color_image->nChannels != 3 )
	{
		AfxMessageBox( "�÷� ������ �ƴմϴ�.", MB_ICONSTOP );
		return;
	}

	//-------------------------------------------------------------------
	// STEP 3 : CColor Ŭ������ SplitRGB()�� �����Ѵ�.
	//-------------------------------------------------------------------
	IplImage *red, *green, *blue;

	CColor cColor;
	cColor.SplitRGB( color_image, &red, &green, &blue );

	//-------------------------------------------------------------------
	// STEP 4 : CColor Ŭ������ SplitRGB()�� ������ ����� ����Ѵ�.
	//-------------------------------------------------------------------

	// ���� ä�ο� ���� ���ο� â�� ����.
	pDoc->CopyClipBoard( red );
	((COpenMFCApp *)AfxGetApp())->OnEditPaste();

	// ���� ä�� â ������ �����Ѵ�.
	COpenMFCDoc *pDoc1 = (COpenMFCDoc *)
		((CMDIFrameWnd*)AfxGetMainWnd())->GetActiveFrame()
		->GetActiveDocument();
	pDoc1->SetTitle("[SplitRGB()] ��ȯ ��� - ���� ä��");

	// ��� ä�ο� ���� ���ο� â�� ����.
	pDoc->CopyClipBoard( green );
	((COpenMFCApp *)AfxGetApp())->OnEditPaste();

	// ��� ä�� â ������ �����Ѵ�.
	COpenMFCDoc *pDoc2 = (COpenMFCDoc *)
		((CMDIFrameWnd*)AfxGetMainWnd())->GetActiveFrame()
		->GetActiveDocument();
	pDoc2->SetTitle("[SplitRGB()] ��ȯ ��� - ��� ä��");

	// �Ķ� ä�ο� ���� ���ο� â�� ����.
	pDoc->CopyClipBoard( blue );
	((COpenMFCApp *)AfxGetApp())->OnEditPaste();

	//  �Ķ� ä�� â ������ �����Ѵ�.
	COpenMFCDoc *pDoc3 = (COpenMFCDoc *)
		((CMDIFrameWnd*)AfxGetMainWnd())->GetActiveFrame()
		->GetActiveDocument();
	pDoc3->SetTitle("[SplitRGB()] ��ȯ ��� - �Ķ� ä��");

	//-------------------------------------------------------------------
	// STEP 4 : �Ҵ��� �޸𸮸� �����Ѵ�.
	//-------------------------------------------------------------------
	cvReleaseImage( &red );
	cvReleaseImage( &green );
	cvReleaseImage( &blue );

	// ȭ�� ����
	Invalidate( FALSE );

}

void COpenMFCView::OnFilter2D() 
{
	// ��� ������� ȣ���Ѵ�.
	CFilterDlg dlg;
	dlg.DoModal();		

	// ȭ�� ����
	Invalidate( FALSE );
}

void COpenMFCView::OnEditUndo() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// ��� 
	pDoc->UndoCvvImage();

	Invalidate( FALSE );
}

void COpenMFCView::OnUpdateEditUndo(CCmdUI* pCmdUI) 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	// Ư�� �۾� �������� �ʾҴٸ� [���� �� ���] �޴� ��Ȱ��ȭ �Ѵ�.
	if(pDoc->m_cvvImageBuffer_pos == 0 )
		pCmdUI->Enable(false);
}

void COpenMFCView::OnEditRedo() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// ���� 
	pDoc->RedoCvvImage();

	Invalidate( FALSE );	
}

// �÷� ������ ���ϵ� �������� ��ȯ.
void COpenMFCView::OnChap7Rgb2gray() 
{
	//-------------------------------------------------------------------
	// STEP 1 : ��ť��Ʈ Ŭ������ �ִ� m_cvvImage�� �������� ���� ���� ȣ���Ѵ�.
	//-------------------------------------------------------------------
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//-------------------------------------------------------------------
	// STEP 2 : ������ m_cvvImage�� IplImage ���� ������ ���� �����´�.
	//-------------------------------------------------------------------

	// m_cvvImage�� IplImage�� �����´�.
	IplImage *color_image = pDoc->m_cvvImage.GetImage();

	// RGB �÷� ������ �ƴ� ��� 
	if( color_image->nChannels != 3 )
	{
		AfxMessageBox( "�÷� ������ �ƴմϴ�.", MB_ICONSTOP );
		return;
	}

	//-------------------------------------------------------------------
	// STEP 3 : CColor Ŭ������ GS_rgb2gray() �Լ��� �����Ѵ�.
	//-------------------------------------------------------------------
	CColor cColor;
	IplImage *gray_image = cColor.GS_rgb2gray( color_image );

	//-------------------------------------------------------------------
	// STEP 4 : CColor Ŭ������ GS_rgb2gray()�� ������ ����� ����Ѵ�.
	//-------------------------------------------------------------------
	CMultiChannelViewer mcv(1,2);
	mcv.GS_setPosition( 0, 0, color_image, "Color image");
	mcv.GS_setPosition( 0, 1, gray_image, "Gray image");
	mcv.GS_run("[GS_rgb2gray()] ���ϵ� ���� ��ȯ ��� : �÷� ���� - ���ϵ� ����");

	//-------------------------------------------------------------------
	// STEP 5 : �Ҵ��� �޸𸮸� �����Ѵ�.
	//-------------------------------------------------------------------
	cvReleaseImage( &gray_image );

	Invalidate( FALSE );
}

// RGB �÷� ������ �и� 
void COpenMFCView::OnChap7SplitRgb() 
{
	//-------------------------------------------------------------------
	// STEP 1 : ��ť��Ʈ Ŭ������ �ִ� m_cvvImage�� �������� ���� ���� ȣ���Ѵ�.
	//-------------------------------------------------------------------
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//-------------------------------------------------------------------
	// STEP 2 : ������ m_cvvImage�� IplImage ���� ������ ���� �����´�.
	//-------------------------------------------------------------------

	// m_cvvImage�� IplImage�� �����´�.
	IplImage *rgb_image = pDoc->m_cvvImage.GetImage();

	// RGB �÷� ������ �ƴ� ��� 
	if( rgb_image->nChannels != 3 )
	{
		AfxMessageBox( "�÷� ������ �ƴմϴ�.", MB_ICONSTOP );
		return;
	}

	//-------------------------------------------------------------------
	// STEP 3 : RGB ä�� �и��Ѵ�.
	//-------------------------------------------------------------------
	IplImage *red, *green, *blue;

	CColor cColor;
	cColor.GS_splitRGB( rgb_image, &red, &green, &blue );

	//-------------------------------------------------------------------
	// STEP 4 : ���� ����� ����Ѵ�.
	//-------------------------------------------------------------------
	CMultiChannelViewer mcv(2, 2);
	mcv.GS_setPosition( 0, 0, rgb_image, "Original image");
	mcv.GS_setPosition( 0, 1, red, "Red channel");
	mcv.GS_setPosition( 1, 0, green, "Green channel");
	mcv.GS_setPosition( 1, 1, blue, "Blue channel");
	mcv.GS_run("[GS_splitRGB()] RGB �÷� ���� �и�");

	//-------------------------------------------------------------------
	// STEP 5 : �Ҵ��� �޸𸮸� �����Ѵ�.
	//-------------------------------------------------------------------
	cvReleaseImage( &red );
	cvReleaseImage( &green );
	cvReleaseImage( &blue );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap7CompositeRgb() 
{
	//-------------------------------------------------------------------
	// STEP 1 : ��ť��Ʈ Ŭ������ �ִ� m_cvvImage�� �������� ���� ���� ȣ���Ѵ�.
	//-------------------------------------------------------------------
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//-------------------------------------------------------------------
	// STEP 2 : ������ m_cvvImage�� IplImage ���� ������ ���� �����´�.
	//-------------------------------------------------------------------

	// m_cvvImage�� IplImage�� �����´�.
	IplImage *rgb_image = pDoc->m_cvvImage.GetImage();

	// RGB �÷� ������ �ƴ� ��� 
	if( rgb_image->nChannels != 3 )
	{
		AfxMessageBox( "�÷� ������ �ƴմϴ�.", MB_ICONSTOP );
		return;
	}

	//-------------------------------------------------------------------
	// STEP 3 : RGB ä�� �и��Ѵ�.
	//-------------------------------------------------------------------
	IplImage *red, *green, *blue;

	CColor cColor;
	cColor.GS_splitRGB( rgb_image, &red, &green, &blue );

	//-------------------------------------------------------------------
	// STEP 4 : RGB ä�� �����Ѵ�.
	//-------------------------------------------------------------------
	IplImage *new_rgb_image = cColor.GS_compositeRGB( red, green, blue );

	//-------------------------------------------------------------------
	// STEP 4 : ���� ����� ����Ѵ�.
	//-------------------------------------------------------------------
	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, rgb_image, "Original image");
	mcv.GS_setPosition( 0, 1, new_rgb_image, "Composited image");
	mcv.GS_run("[GS_compositeRGB()] RGB ä�� ����");

	//-------------------------------------------------------------------
	// STEP 5 : �Ҵ��� �޸𸮸� �����Ѵ�.
	//-------------------------------------------------------------------
	cvReleaseImage( &red );
	cvReleaseImage( &green );
	cvReleaseImage( &blue );
	cvReleaseImage( &new_rgb_image );



	Invalidate( FALSE );	
	
}



void COpenMFCView::OnChap7Split2Rgb() 
{
	//-------------------------------------------------------------------
	// STEP 1 : ��ť��Ʈ Ŭ������ �ִ� m_cvvImage�� �������� ���� ���� ȣ���Ѵ�.
	//-------------------------------------------------------------------
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//-------------------------------------------------------------------
	// STEP 2 : ������ m_cvvImage�� IplImage ���� ������ ���� �����´�.
	//-------------------------------------------------------------------

	// m_cvvImage�� IplImage�� �����´�.
	IplImage *rgb_image = pDoc->m_cvvImage.GetImage();

	// RGB �÷� ������ �ƴ� ��� 
	if( rgb_image->nChannels != 3 )
	{
		AfxMessageBox( "�÷� ������ �ƴմϴ�.", MB_ICONSTOP );
		return;
	}

	//-------------------------------------------------------------------
	// STEP 3 : RGB ä�� �и�/�����Ѵ�.
	//-------------------------------------------------------------------
	IplImage *red, *green, *blue;

	CColor cColor;
	cColor.GS_splitRGB( rgb_image, &red, &green, &blue );

	IplImage *black = cvCreateImage( cvGetSize( red ), IPL_DEPTH_8U, 1 );
	cvSetZero( black );

	IplImage *red_image = cvCreateImage( cvGetSize( red ), IPL_DEPTH_8U, 3 );
	IplImage *green_image = cvCreateImage( cvGetSize( green ), IPL_DEPTH_8U, 3 );
	IplImage *blue_image = cvCreateImage( cvGetSize( blue ), IPL_DEPTH_8U, 3 );

	// ����
	cvCvtPlaneToPix( black, black, red, NULL, red_image );
	cvCvtPlaneToPix( black, green, black, NULL, green_image );
	cvCvtPlaneToPix( blue, black, black, NULL, blue_image );

	
	//-------------------------------------------------------------------
	// STEP 4 : ���� ����� ����Ѵ�.
	//-------------------------------------------------------------------
	CMultiChannelViewer mcv(2, 2);
	mcv.GS_setPosition( 0, 0, rgb_image, "Original image");
	mcv.GS_setPosition( 0, 1, red_image, "Red channel");
	mcv.GS_setPosition( 1, 0, green_image, "Green channel");
	mcv.GS_setPosition( 1, 1, blue_image, "Blue channel");
	mcv.GS_run("[GS_splitRGB()] RGB �÷� ���� �и� (3����)");

	//-------------------------------------------------------------------
	// STEP 5 : �Ҵ��� �޸𸮸� �����Ѵ�.
	//-------------------------------------------------------------------
	cvReleaseImage( &red );
	cvReleaseImage( &green );
	cvReleaseImage( &blue );
	cvReleaseImage( &red_image );
	cvReleaseImage( &green_image );
	cvReleaseImage( &blue_image );
	cvReleaseImage( &black );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap7SplitHsv() 
{
	//-------------------------------------------------------------------
	// STEP 1 : ��ť��Ʈ Ŭ������ �ִ� m_cvvImage�� �������� ���� ���� ȣ���Ѵ�.
	//-------------------------------------------------------------------
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//-------------------------------------------------------------------
	// STEP 2 : ������ m_cvvImage�� IplImage ���� ������ ���� �����´�.
	//-------------------------------------------------------------------

	// m_cvvImage�� IplImage�� �����´�.
	IplImage *rgb_image = pDoc->m_cvvImage.GetImage();

	// RGB �÷� ������ �ƴ� ��� 
	if( rgb_image->nChannels != 3 )
	{
		AfxMessageBox( "�÷� ������ �ƴմϴ�.", MB_ICONSTOP );
		return;
	}

	//-------------------------------------------------------------------
	// STEP 3 : RGB �÷� ������ HSV �÷� �������� ��ȯ�Ѵ�.
	//-------------------------------------------------------------------
	IplImage *red, *green, *blue;
	IplImage *hue, *saturation, *value;

	CColor cColor;
	cColor.GS_splitRGB( rgb_image, &red, &green, &blue );
	cColor.GS_rgb2hsv( red, green, blue, &hue, &saturation, &value );

	//-------------------------------------------------------------------
	// STEP 4 : ���� ����� ����Ѵ�.
	//-------------------------------------------------------------------
	CMultiChannelViewer mcv(2, 2);
	mcv.GS_setPosition( 0, 0, rgb_image, "Original image");
	mcv.GS_setPosition( 0, 1, hue, "Hue channel");
	mcv.GS_setPosition( 1, 0, saturation, "Saturation channel");
	mcv.GS_setPosition( 1, 1, value, "Value channel");
	mcv.GS_run("[GS_rgb2hsv()] HSV �÷� ���� �и�");

	//-------------------------------------------------------------------
	// STEP 5 : �Ҵ��� �޸𸮸� �����Ѵ�.
	//-------------------------------------------------------------------
	cvReleaseImage( &red );
	cvReleaseImage( &green );
	cvReleaseImage( &blue );

	cvReleaseImage( &hue );
	cvReleaseImage( &saturation );
	cvReleaseImage( &value );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap7CompositeHsv() 
{
	//-------------------------------------------------------------------
	// STEP 1 : ��ť��Ʈ Ŭ������ �ִ� m_cvvImage�� �������� ���� ���� ȣ���Ѵ�.
	//-------------------------------------------------------------------
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//-------------------------------------------------------------------
	// STEP 2 : ������ m_cvvImage�� IplImage ���� ������ ���� �����´�.
	//-------------------------------------------------------------------

	// m_cvvImage�� IplImage�� �����´�.
	IplImage *rgb_image = pDoc->m_cvvImage.GetImage();

	// RGB �÷� ������ �ƴ� ��� 
	if( rgb_image->nChannels != 3 )
	{
		AfxMessageBox( "�÷� ������ �ƴմϴ�.", MB_ICONSTOP );
		return;
	}

	//-------------------------------------------------------------------
	// STEP 3 : RGB �÷� ������ HSV �÷� �������� ��ȯ�Ѵ�.
	//-------------------------------------------------------------------
	IplImage *red, *green, *blue;
	IplImage *hue, *saturation, *value;

	CColor cColor;
	cColor.GS_splitRGB( rgb_image, &red, &green, &blue );
	cColor.GS_rgb2hsv( red, green, blue, &hue, &saturation, &value );

	//-------------------------------------------------------------------
	// STEP 4 : �ٽ� RGB �÷� �������� �����Ѵ�.
	//-------------------------------------------------------------------
	IplImage *new_red, *new_green, *new_blue;
	cColor.GS_hsv2rgb( hue, saturation, value, &new_red, &new_green, &new_blue );

	IplImage *new_rgb_image = cColor.GS_compositeRGB( new_red, new_green, new_blue );

	//-------------------------------------------------------------------
	// STEP 5 : ���� ����� ����Ѵ�.
	//-------------------------------------------------------------------
	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, rgb_image, "Original image");
	mcv.GS_setPosition( 0, 1, new_rgb_image, "Restored image");
	mcv.GS_run("[GS_hsv2rgb()] HSV �÷� ������ RGB �÷� �������� ����");

	//-------------------------------------------------------------------
	// STEP 6 : �Ҵ��� �޸𸮸� �����Ѵ�.
	//-------------------------------------------------------------------
	cvReleaseImage( &red ); cvReleaseImage( &green ); cvReleaseImage( &blue );
	cvReleaseImage( &new_red ); cvReleaseImage( &new_green ); cvReleaseImage( &new_blue );

	cvReleaseImage( &hue ); cvReleaseImage( &saturation ); cvReleaseImage( &value );
	cvReleaseImage( &new_rgb_image );

	Invalidate( FALSE );		
}

void COpenMFCView::OnChap7SplitYcbcr() 
{
	//-------------------------------------------------------------------
	// STEP 1 : ��ť��Ʈ Ŭ������ �ִ� m_cvvImage�� �������� ���� ���� ȣ���Ѵ�.
	//-------------------------------------------------------------------
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//-------------------------------------------------------------------
	// STEP 2 : ������ m_cvvImage�� IplImage ���� ������ ���� �����´�.
	//-------------------------------------------------------------------

	// m_cvvImage�� IplImage�� �����´�.
	IplImage *rgb_image = pDoc->m_cvvImage.GetImage();

	// RGB �÷� ������ �ƴ� ��� 
	if( rgb_image->nChannels != 3 )
	{
		AfxMessageBox( "�÷� ������ �ƴմϴ�.", MB_ICONSTOP );
		return;
	}

	//-------------------------------------------------------------------
	// STEP 3 : RGB �÷� ������ YCbCr �÷� �������� ��ȯ�Ѵ�.
	//-------------------------------------------------------------------
	IplImage *red, *green, *blue;
	IplImage *Y, *Cb, *Cr;

	CColor cColor;
	cColor.GS_splitRGB( rgb_image, &red, &green, &blue );
	cColor.GS_rgb2ycbcr( red, green, blue, &Y, &Cb, &Cr );

	//-------------------------------------------------------------------
	// STEP 4 : ���� ����� ����Ѵ�.
	//-------------------------------------------------------------------
	CMultiChannelViewer mcv(2, 2);
	mcv.GS_setPosition( 0, 0, rgb_image, "Original image");
	mcv.GS_setPosition( 0, 1, Y, "Y channel");
	mcv.GS_setPosition( 1, 0, Cb, "Cb channel");
	mcv.GS_setPosition( 1, 1, Cr, "Cr channel");
	mcv.GS_run("[GS_rgb2ycbcr()] YCbCr �÷� ���� �и�");

	//-------------------------------------------------------------------
	// STEP 5 : �Ҵ��� �޸𸮸� �����Ѵ�.
	//-------------------------------------------------------------------
	cvReleaseImage( &red );
	cvReleaseImage( &green );
	cvReleaseImage( &blue );

	cvReleaseImage( &Y );
	cvReleaseImage( &Cb );
	cvReleaseImage( &Cr );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap7CompositeYcbcr() 
{
	//-------------------------------------------------------------------
	// STEP 1 : ��ť��Ʈ Ŭ������ �ִ� m_cvvImage�� �������� ���� ���� ȣ���Ѵ�.
	//-------------------------------------------------------------------
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//-------------------------------------------------------------------
	// STEP 2 : ������ m_cvvImage�� IplImage ���� ������ ���� �����´�.
	//-------------------------------------------------------------------

	// m_cvvImage�� IplImage�� �����´�.
	IplImage *rgb_image = pDoc->m_cvvImage.GetImage();

	// RGB �÷� ������ �ƴ� ��� 
	if( rgb_image->nChannels != 3 )
	{
		AfxMessageBox( "�÷� ������ �ƴմϴ�.", MB_ICONSTOP );
		return;
	}

	//-------------------------------------------------------------------
	// STEP 3 : RGB �÷� ������ YCbCr �÷� �������� ��ȯ�Ѵ�.
	//-------------------------------------------------------------------
	IplImage *red, *green, *blue;
	IplImage *Y, *Cb, *Cr;

	CColor cColor;
	cColor.GS_splitRGB( rgb_image, &red, &green, &blue );
	cColor.GS_rgb2ycbcr( red, green, blue, &Y, &Cb, &Cr );

	//-------------------------------------------------------------------
	// STEP 4 : �ٽ� RGB �÷� �������� �����Ѵ�.
	//-------------------------------------------------------------------
	IplImage *new_red, *new_green, *new_blue;
	cColor.GS_ycbcr2rgb( Y, Cb, Cr, &new_red, &new_green, &new_blue );

	IplImage *new_rgb_image = cColor.GS_compositeRGB( new_red, new_green, new_blue );

	//-------------------------------------------------------------------
	// STEP 5 : ���� ����� ����Ѵ�.
	//-------------------------------------------------------------------
	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, rgb_image, "Original image");
	mcv.GS_setPosition( 0, 1, new_rgb_image, "Restored image");
	mcv.GS_run("[GS_ycbcr2rgb()] YCbCr �÷� ������ RGB �÷� �������� ����");

	//-------------------------------------------------------------------
	// STEP 6 : �Ҵ��� �޸𸮸� �����Ѵ�.
	//-------------------------------------------------------------------
	cvReleaseImage( &red ); cvReleaseImage( &green ); cvReleaseImage( &blue );
	cvReleaseImage( &new_red ); cvReleaseImage( &new_green ); cvReleaseImage( &new_blue );

	cvReleaseImage( &Y ); cvReleaseImage( &Cb ); cvReleaseImage( &Cr );
	cvReleaseImage( &new_rgb_image );

	Invalidate( FALSE );		
}

void COpenMFCView::OnChap8MakeGrayBand() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CPixel cPixel;
	IplImage *band_image = cPixel.GS_makeGrayBand();

	// ���ο� â�� ����.
	pDoc->CopyClipBoard( band_image );
	((COpenMFCApp *)AfxGetApp())->OnEditPaste();

	// â ������ �����Ѵ�.
	COpenMFCDoc *pDoc1 = (COpenMFCDoc *)
		((CMDIFrameWnd*)AfxGetMainWnd())->GetActiveFrame()
		->GetActiveDocument();

	pDoc1->SetTitle(_T("������ ����"));

	cvReleaseImage( &band_image );
	Invalidate( FALSE );
}

void COpenMFCView::OnChap8AddsubConstant() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image = pDoc->m_cvvImage.GetImage();
	
	int constant = -50;
	char result_msg[256] = {'0',};

	if( constant >= 0 )
		sprintf(result_msg, "Result image : +%d", constant );
	else
		sprintf(result_msg, "Result image : %d", constant );

	CPixel cPixel;
	IplImage *result_image = cPixel.GS_add_constant( image, constant );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, result_msg);

	CString msg = "[GS_add_constant()] - cvAddS()/cvSubS() : ";
	CString msg_constant = "";
	if( constant >= 0 ) msg_constant.Format("+%d", constant);
	else msg_constant.Format("%d", constant);
	msg += msg_constant;
	mcv.GS_run( (char *) (LPCTSTR)msg );

	cvReleaseImage( &result_image );
	Invalidate( FALSE );
}

void COpenMFCView::OnChap8AddImage() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image1 = pDoc->m_cvvImage.GetImage();

	CPixel cPixel;
	CUtil cUtil;
	IplImage *image2;
	CvvImage cImage;

	// �� ��° ������ �ҷ��´�.
	char szFilter[] = "JPEG file(*.jpeg, *.jpg, *.jpe) | *.jpeg; *.jpg; *.jpe |\
Portable Network Graphics file(*.png) | *.png |\
Windows bitmap files(*.bmp, *.dib) | *.bmp; *.dib |\
Sun rasters(*.sr, *.ras) | *.sr; *.ras |\
TIFF files(*.tiff, *.tif) | *.tiff; *.tif |\
�����ϴ� ��� ���� ����|*.jpeg; *.jpg; *.jpe; *.png; *.bmp; *.dib; *.sr; *.ras; *.tiff; *.tif ||";

	CFileDialog fileDlg(TRUE, 
						NULL, 
						NULL, 
						OFN_EXPLORER|OFN_HIDEREADONLY, 
						szFilter
						);

	if( fileDlg.DoModal() == IDOK ) 
	{
		cImage.Load( fileDlg.GetPathName() );
		image2 = cImage.GetImage();

		// ũ�Ⱑ ��ġ���� ������
		if( image1->height != image2->height 
			|| image2->width != image2->width )
		{
			cUtil.GS_errMsg("ũ�Ⱑ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
		else if( image1->nChannels != image2->nChannels )
		{
			cUtil.GS_errMsg("ä�� ������ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
	}
	else
	{
		return;
	}

	// �� ���� ����
	IplImage *result_image = cPixel.GS_add_image( image1, image2 );

	// ��� ���
	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, image1, "Original image 1");
	mcv.GS_setPosition( 0, 1, image2, "Original image 2");
	mcv.GS_setPosition( 0, 2, result_image, "Result image");
	mcv.GS_run( "[GS_add_image()] - cvAdd()" );

	// �Ҵ��� �޸� ����
	cImage.Destroy();
	cvReleaseImage( &result_image );

	// ȭ�� ����
	Invalidate( FALSE );
}

void COpenMFCView::OnChap8SubtractImage() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image1 = pDoc->m_cvvImage.GetImage();

	CPixel cPixel;
	CUtil cUtil;
	IplImage *image2;
	CvvImage cImage;

	// �� ��° ������ �ҷ��´�.
	char szFilter[] = "JPEG file(*.jpeg, *.jpg, *.jpe) | *.jpeg; *.jpg; *.jpe |\
Portable Network Graphics file(*.png) | *.png |\
Windows bitmap files(*.bmp, *.dib) | *.bmp; *.dib |\
Sun rasters(*.sr, *.ras) | *.sr; *.ras |\
TIFF files(*.tiff, *.tif) | *.tiff; *.tif |\
�����ϴ� ��� ���� ����|*.jpeg; *.jpg; *.jpe; *.png; *.bmp; *.dib; *.sr; *.ras; *.tiff; *.tif ||";

	CFileDialog fileDlg(TRUE, 
						NULL, 
						NULL, 
						OFN_EXPLORER|OFN_HIDEREADONLY, 
						szFilter
						);

	if( fileDlg.DoModal() == IDOK ) 
	{
		cImage.Load( fileDlg.GetPathName() );
		image2 = cImage.GetImage();

		// ũ�Ⱑ ��ġ���� ������
		if( image1->height != image2->height 
			|| image2->width != image2->width )
		{
			cUtil.GS_errMsg("ũ�Ⱑ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
		else if( image1->nChannels != image2->nChannels )
		{
			cUtil.GS_errMsg("ä�� ������ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
	}
	else
	{
		return;
	}

	// �� ���� ����
	IplImage *result_image = cPixel.GS_subtract_image( image1, image2 );

	// ��� ���
	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, image1, "Original image 1");
	mcv.GS_setPosition( 0, 1, image2, "Original image 2");
	mcv.GS_setPosition( 0, 2, result_image, "Result image");
	mcv.GS_run( "[GS_subtract_image()] - cvSub()" );

	// �Ҵ��� �޸� ����
	cImage.Destroy();
	cvReleaseImage( &result_image );

	// ȭ�� ����
	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap8BlendingEffect() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image1 = pDoc->m_cvvImage.GetImage();

	CPixel cPixel;
	CUtil cUtil;
	IplImage *image2;
	CvvImage cImage;

	// �� ��° ������ �ҷ��´�.
	char szFilter[] = "JPEG file(*.jpeg, *.jpg, *.jpe) | *.jpeg; *.jpg; *.jpe |\
Portable Network Graphics file(*.png) | *.png |\
Windows bitmap files(*.bmp, *.dib) | *.bmp; *.dib |\
Sun rasters(*.sr, *.ras) | *.sr; *.ras |\
TIFF files(*.tiff, *.tif) | *.tiff; *.tif |\
�����ϴ� ��� ���� ����|*.jpeg; *.jpg; *.jpe; *.png; *.bmp; *.dib; *.sr; *.ras; *.tiff; *.tif ||";

	CFileDialog fileDlg(TRUE, 
						NULL, 
						NULL, 
						OFN_EXPLORER|OFN_HIDEREADONLY, 
						szFilter
						);

	if( fileDlg.DoModal() == IDOK ) 
	{
		cImage.Load( fileDlg.GetPathName() );
		image2 = cImage.GetImage();

		// ũ�Ⱑ ��ġ���� ������
		if( image1->height != image2->height 
			|| image2->width != image2->width )
		{
			cUtil.GS_errMsg("ũ�Ⱑ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
		else if( image1->nChannels != image2->nChannels )
		{
			cUtil.GS_errMsg("ä�� ������ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
	}
	else
	{
		return;
	}

	// ������
	double alpha = 0.4;
	IplImage *result_image = cPixel.GS_blending_effect( image1, image2, alpha );

	// ��� ���
	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, image1, "Original image 1");
	mcv.GS_setPosition( 0, 1, image2, "Original image 2");
	mcv.GS_setPosition( 0, 2, result_image, "Result image");
	mcv.GS_run( "[GS_blending_effect()] - cvAddWeighted()" );

	// �Ҵ��� �޸� ����
	cImage.Destroy();
	cvReleaseImage( &result_image );

	// ȭ�� ����
	Invalidate( FALSE );	
}

void COpenMFCView::OnChap8MakeContrast() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CPixel cPixel;
	IplImage *contrast_image = cPixel.GS_makeContrast();

	// ���ο� â�� ����.
	pDoc->CopyClipBoard( contrast_image );
	((COpenMFCApp *)AfxGetApp())->OnEditPaste();

	// â ������ �����Ѵ�.
	COpenMFCDoc *pDoc1 = (COpenMFCDoc *)
		((CMDIFrameWnd*)AfxGetMainWnd())->GetActiveFrame()
		->GetActiveDocument();

	pDoc1->SetTitle(_T("���� ����� ��"));

	cvReleaseImage( &contrast_image );
	Invalidate( FALSE );
}

void COpenMFCView::OnChap8MulConstant() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image = pDoc->m_cvvImage.GetImage();
	
	double constant = 1.5;
	char result_msg[256] = {'0',};

	sprintf(result_msg, "Result image : %3.2f", constant );

	CPixel cPixel;
	IplImage *result_image = cPixel.GS_multiple_constant( image, constant );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, result_msg);

	CString msg = "[GS_multiple_constant()] - cvMul() : ";
	CString msg_constant;
	msg_constant.Format("%3.2f", constant);
	msg += msg_constant;
	mcv.GS_run( (char *) (LPCTSTR)msg );

	cvReleaseImage( &result_image );
	Invalidate( FALSE );	
}

void COpenMFCView::OnChap8DivConstant() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image = pDoc->m_cvvImage.GetImage();
	
	double constant = 2.0;
	char result_msg[256] = {'0',};

	CUtil cUtil;
	if( constant == 0.0 )
		cUtil.GS_errMsg("0���� ���� ���� �����ϴ�.");

	sprintf(result_msg, "Result image : %3.2f", constant );

	CPixel cPixel;
	IplImage *result_image = cPixel.GS_divide_constant( image, constant );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, result_msg);

	CString msg = "[GS_divide_constant()] - cvMul() : ";
	CString msg_constant;
	msg_constant.Format("%3.2f", constant);
	msg += msg_constant;
	mcv.GS_run( (char *) (LPCTSTR)msg );

	cvReleaseImage( &result_image );
	Invalidate( FALSE );	
}

void COpenMFCView::OnChap8ContrastBrightness() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image = pDoc->m_cvvImage.GetImage();
	
	double contrast = 1.1;
	int brightness = 30;
	char result_msg[256] = {'0',};

	sprintf(result_msg, "Result image : C-%.1f, B-%d", contrast, brightness );

	CPixel cPixel;
	IplImage *result_image = cPixel.GS_basic_contrast_brightness( image, contrast, brightness );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, result_msg);

	CString msg = "[GS_basic_contrast_brightness()] : ";
	CString msg_constant;
	msg_constant.Format("C-%.1f, B-%d", contrast, brightness );
	msg += msg_constant;
	mcv.GS_run( (char *) (LPCTSTR)msg );

	cvReleaseImage( &result_image );
	Invalidate( FALSE );
}

void COpenMFCView::OnChap8ImHistGrayImage() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CPixel cPixel;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	IplImage *hist_image = cPixel.GS_imhist( gray_image );

	cUtil.GS_showWindow( gray_image, "�� ���ϵ� ����" );
	cUtil.GS_showWindow( hist_image, "[GS_imhist()]" );

	cvReleaseImage( &hist_image );
	cvReleaseImage( &gray_image );

	Invalidate( FALSE );		
}

void COpenMFCView::OnChap8ImHistGrayBrightness() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CPixel cPixel;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// ��� ����
	int brightness = 40;
	IplImage *result_image = cPixel.GS_add_constant( gray_image, brightness );
	IplImage *hist_image = cPixel.GS_imhist( result_image );

	char msg[256]={'\0',};
	sprintf(msg, "%d�� ������ ���", brightness);
	cUtil.GS_showWindow( result_image, msg );
	cUtil.GS_showWindow( hist_image, "[GS_imhist()]" );

	cvReleaseImage( &hist_image );
	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );		
}

void COpenMFCView::OnChap8ImHistGrayContrast() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CPixel cPixel;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// ���� ��� ����
	double contrast = 2.0;
	IplImage *result_image = cPixel.GS_multiple_constant( gray_image, contrast );
	int max_length = 800;
	IplImage *hist_image = cPixel.GS_imhist( result_image, max_length );

	char msg[256]={'\0',};
	sprintf(msg, "%.1f�� ������ ���", contrast);
	cUtil.GS_showWindow( result_image, msg );
	cUtil.GS_showWindow( hist_image, "[GS_imhist()]" );

	cvReleaseImage( &hist_image );
	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );
}

void COpenMFCView::OnChap8HistogramEqualization() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CPixel cPixel;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// ������׷� ��Ȱȭ
	IplImage *result_image = cPixel.GS_histeq( gray_image );
	IplImage *hist_image = cPixel.GS_imhist( result_image );

	cUtil.GS_showWindow( result_image, "[GS_histeq()]" );
	cUtil.GS_showWindow( hist_image, "[GS_imhist()]" );

	cvReleaseImage( &hist_image );
	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );	
}

void COpenMFCView::OnChap8ViewHistData() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CPixel cPixel;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	IplImage *hist_image = cPixel.GS_imhist( gray_image );

	cUtil.GS_showWindow( gray_image, "�� ���ϵ� ����" );
	cUtil.GS_showWindow( hist_image, "[GS_imhist()]" );

	// ������׷� �����͸� �α�â�� ��� �ϱ�.
	cPixel.GS_view_hist_data( gray_image );
	cvReleaseImage( &hist_image );
	cvReleaseImage( &gray_image );

	Invalidate( FALSE );
}

void COpenMFCView::OnChap8LutBasicContrastBrighness() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CPixel cPixel;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	double contrast = 1.1;
	int brightness = 30;

	LARGE_INTEGER frequency1, tStart1, tEnd1;
	QueryPerformanceFrequency( &frequency1 );
	QueryPerformanceCounter( &tStart1 );

	IplImage *result_image1 = cPixel.GS_basic_contrast_brightness( image, contrast, brightness );

	QueryPerformanceCounter( &tEnd1 );
	double tElpased1 = (double)(tEnd1.QuadPart - tStart1.QuadPart)/(double)frequency1.QuadPart;
	CString msg1 = "";
	msg1.Format("* cvLUT() �Լ� ���� �� : %5.5f ��", tElpased1);
	pDoc->InsertLogWindow(msg1);

	LARGE_INTEGER frequency2, tStart2, tEnd2;
	QueryPerformanceFrequency( &frequency2 );
	QueryPerformanceCounter( &tStart2 );
	Invalidate( FALSE );

	IplImage *result_image2 = cPixel.GS_LUT_basic_contrast_brightness( image, contrast, brightness );

	QueryPerformanceCounter( &tEnd2 );
	double tElpased2 = (double)(tEnd2.QuadPart - tStart2.QuadPart)/(double)frequency2.QuadPart;
	CString msg2 = "";
	msg2.Format("* cvLUT() �Լ� ���� �� : %5.5f ��", tElpased2);
	pDoc->InsertLogWindow(msg2);
	Invalidate( FALSE );

	cUtil.GS_showWindow( result_image1, "���� ��� ����" );
	cUtil.GS_showWindow( result_image2, "LUT ���� ��� ����" );

	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap8Threshold() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CPixel cPixel;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	double threshold = 0; 
	double max_value = 255; // CV_THRESH_BINARY and CV_THRESH_BINARY_INV �϶��� �����.
	int type = 0;

	// CV_THRESH_BINARY
	threshold = 96.0;
	max_value = 255.0;
	type = CV_THRESH_BINARY;
	IplImage *result_image1 = cPixel.GS_threshold( gray_image, threshold, max_value, type );

	// CV_THRESH_BINARY_INV
	threshold = 96.0;
	max_value = 255.0;
	type = CV_THRESH_BINARY_INV;
	IplImage *result_image2 = cPixel.GS_threshold( gray_image, threshold, max_value, type );

	// CV_THRESH_TRUNC
	threshold = 96.0;
	type = CV_THRESH_TRUNC;
	IplImage *result_image3 = cPixel.GS_threshold( gray_image, threshold, type );

	// CV_THRESH_TOZERO
	threshold = 96.0;
	type = CV_THRESH_TOZERO;
	IplImage *result_image4 = cPixel.GS_threshold( gray_image, threshold, type );

	// CV_THRESH_TOZERO_INV 
	threshold = 96.0;
	type = CV_THRESH_TOZERO_INV ;
	IplImage *result_image5 = cPixel.GS_threshold( gray_image, threshold, type );

	// CV_THRESH_OTSU 
	threshold = 255.0;
	max_value = 255.0;
	type = CV_THRESH_OTSU ;
	IplImage *result_image6 = cPixel.GS_threshold( gray_image, threshold, max_value, type );
	
	// ���� ��� ���
	CMultiChannelViewer mcv1(1,3);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original Image");
	mcv1.GS_setPosition( 0, 1, result_image1, "CV_THRESH_BINARY(T: 96, M: 255)");
	mcv1.GS_setPosition( 0, 2, result_image2, "CV_THRESH_BINARY_INV(T: 96, M: 255)");
	mcv1.GS_run("[GS_threshold()] ���� ���� ��ȯ ���");

	CMultiChannelViewer mcv2(1,3);
	mcv2.GS_setPosition( 0, 0, gray_image, "Original Image");
	mcv2.GS_setPosition( 0, 1, result_image3, "CV_THRESH_TRUNC(T: 96)");
	mcv2.GS_setPosition( 0, 2, result_image4, "CV_THRESH_TOZERO(T: 96)");
	mcv2.GS_run("[GS_threshold()] ���� ���� ��ȯ ���");

	CMultiChannelViewer mcv3(1,3);
	mcv3.GS_setPosition( 0, 0, gray_image, "Original Image");
	mcv3.GS_setPosition( 0, 1, result_image5, "CV_THRESH_TOZERO_INV(T: 96)");
	mcv3.GS_setPosition( 0, 2, result_image6, "CV_THRESH_OTSU(T: 0, M:255)");
	mcv3.GS_run("[GS_threshold()] ���� ���� ��ȯ ���");
	
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );
	cvReleaseImage( &result_image5 );
	cvReleaseImage( &result_image6 );

	cvReleaseImage( &gray_image );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap8AdaptiveThreshold() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CPixel cPixel;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	int adaptive_method = -1; 
	int threshold_type = CV_THRESH_BINARY;
	double max_value = 255; // CV_THRESH_BINARY and CV_THRESH_BINARY_INV �϶��� �����.
	int block_size = 7;
	int param = 5;

	// CV_ADAPTIVE_THRESH_MEAN_C
	adaptive_method = CV_ADAPTIVE_THRESH_MEAN_C;
	IplImage *result_image1 = cPixel.GS_adaptive_threshold( gray_image, max_value, adaptive_method, threshold_type, block_size, param );

	// CV_ADAPTIVE_THRESH_GAUSSIAN_C
	adaptive_method = CV_ADAPTIVE_THRESH_GAUSSIAN_C;
	IplImage *result_image2 = cPixel.GS_adaptive_threshold( gray_image, max_value, adaptive_method, threshold_type, block_size, param );
	
	// ���� ��� ���
	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, gray_image, "Original Image");
	mcv.GS_setPosition( 0, 1, result_image1, "CV_ADAPTIVE_THRESH_MEAN_C");
	mcv.GS_setPosition( 0, 2, result_image2, "CV_ADAPTIVE_THRESH_GAUSSIAN_C");
	mcv.GS_run("[GS_adpative_threshold()] ���� ���� ��ȯ ���");
	
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &gray_image );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap8BinaryLogicalAnd() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image1 = pDoc->m_cvvImage.GetImage();

	CPixel cPixel;
	CUtil cUtil;
	CColor cColor;
	IplImage *image2;
	CvvImage cImage;

	// �� ��° ������ �ҷ��´�.
	char szFilter[] = "JPEG file(*.jpeg, *.jpg, *.jpe) | *.jpeg; *.jpg; *.jpe |\
Portable Network Graphics file(*.png) | *.png |\
Windows bitmap files(*.bmp, *.dib) | *.bmp; *.dib |\
Sun rasters(*.sr, *.ras) | *.sr; *.ras |\
TIFF files(*.tiff, *.tif) | *.tiff; *.tif |\
�����ϴ� ��� ���� ����|*.jpeg; *.jpg; *.jpe; *.png; *.bmp; *.dib; *.sr; *.ras; *.tiff; *.tif ||";

	CFileDialog fileDlg(TRUE, 
						NULL, 
						NULL, 
						OFN_EXPLORER|OFN_HIDEREADONLY, 
						szFilter
						);

	if( fileDlg.DoModal() == IDOK ) 
	{
		cImage.Load( fileDlg.GetPathName() );
		image2 = cImage.GetImage();

		// ũ�Ⱑ ��ġ���� ������
		if( image1->height != image2->height 
			|| image2->width != image2->width )
		{
			cUtil.GS_errMsg("ũ�Ⱑ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
		else if( image1->nChannels != image2->nChannels )
		{
			cUtil.GS_errMsg("ä�� ������ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
	}
	else
	{
		return;
	}

	// ���� ����
	IplImage *binary_image1 = cPixel.GS_threshold( cColor.GS_rgb2gray( image1 ),
												  0.0, 1.0, CV_THRESH_OTSU );
	IplImage *binary_image2 = cPixel.GS_threshold( cColor.GS_rgb2gray( image2 ),
												  0.0, 1.0, CV_THRESH_OTSU );

	// AND ����
	IplImage *binary_result_image = cPixel.GS_binary_logic( binary_image1, 
															binary_image2,
															0 );
	// ��� ���
	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, cPixel.GS_binary2gray(binary_image1), "Original image 1");
	mcv.GS_setPosition( 0, 1, cPixel.GS_binary2gray(binary_image2), "Original image 2");
	mcv.GS_setPosition( 0, 2, cPixel.GS_binary2gray(binary_result_image), "AND operation");
	mcv.GS_run( "[GS_binary_logic()] - ���� ���󿡼��� ���� ����" );

	// �Ҵ��� �޸� ����
	cImage.Destroy();
	cvReleaseImage( &binary_image1 );
	cvReleaseImage( &binary_image2 );
	cvReleaseImage( &binary_result_image );

	// ȭ�� ����
	Invalidate( FALSE );	
}

void COpenMFCView::OnChap8BinaryLogicalNand() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image1 = pDoc->m_cvvImage.GetImage();

	CPixel cPixel;
	CUtil cUtil;
	CColor cColor;
	IplImage *image2;
	CvvImage cImage;

	// �� ��° ������ �ҷ��´�.
	char szFilter[] = "JPEG file(*.jpeg, *.jpg, *.jpe) | *.jpeg; *.jpg; *.jpe |\
Portable Network Graphics file(*.png) | *.png |\
Windows bitmap files(*.bmp, *.dib) | *.bmp; *.dib |\
Sun rasters(*.sr, *.ras) | *.sr; *.ras |\
TIFF files(*.tiff, *.tif) | *.tiff; *.tif |\
�����ϴ� ��� ���� ����|*.jpeg; *.jpg; *.jpe; *.png; *.bmp; *.dib; *.sr; *.ras; *.tiff; *.tif ||";

	CFileDialog fileDlg(TRUE, 
						NULL, 
						NULL, 
						OFN_EXPLORER|OFN_HIDEREADONLY, 
						szFilter
						);

	if( fileDlg.DoModal() == IDOK ) 
	{
		cImage.Load( fileDlg.GetPathName() );
		image2 = cImage.GetImage();

		// ũ�Ⱑ ��ġ���� ������
		if( image1->height != image2->height 
			|| image2->width != image2->width )
		{
			cUtil.GS_errMsg("ũ�Ⱑ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
		else if( image1->nChannels != image2->nChannels )
		{
			cUtil.GS_errMsg("ä�� ������ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
	}
	else
	{
		return;
	}

	// ���� ����
	IplImage *binary_image1 = cPixel.GS_threshold( cColor.GS_rgb2gray( image1 ),
												  0.0, 1.0, CV_THRESH_OTSU );
	IplImage *binary_image2 = cPixel.GS_threshold( cColor.GS_rgb2gray( image2 ),
												  0.0, 1.0, CV_THRESH_OTSU );

	// NAND ����
	IplImage *binary_result_image = cPixel.GS_binary_logic( binary_image1, 
															binary_image2,
															1 );
	// ��� ���
	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, cPixel.GS_binary2gray(binary_image1), "Original image 1");
	mcv.GS_setPosition( 0, 1, cPixel.GS_binary2gray(binary_image2), "Original image 2");
	mcv.GS_setPosition( 0, 2, cPixel.GS_binary2gray(binary_result_image), "NAND operation");
	mcv.GS_run( "[GS_binary_logic()] - ���� ���󿡼��� ���� ����" );

	// �Ҵ��� �޸� ����
	cImage.Destroy();
	cvReleaseImage( &binary_image1 );
	cvReleaseImage( &binary_image2 );
	cvReleaseImage( &binary_result_image );

	// ȭ�� ����
	Invalidate( FALSE );	
	
}

void COpenMFCView::OnChap8BinaryLogicalOr() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image1 = pDoc->m_cvvImage.GetImage();

	CPixel cPixel;
	CUtil cUtil;
	CColor cColor;
	IplImage *image2;
	CvvImage cImage;

	// �� ��° ������ �ҷ��´�.
	char szFilter[] = "JPEG file(*.jpeg, *.jpg, *.jpe) | *.jpeg; *.jpg; *.jpe |\
Portable Network Graphics file(*.png) | *.png |\
Windows bitmap files(*.bmp, *.dib) | *.bmp; *.dib |\
Sun rasters(*.sr, *.ras) | *.sr; *.ras |\
TIFF files(*.tiff, *.tif) | *.tiff; *.tif |\
�����ϴ� ��� ���� ����|*.jpeg; *.jpg; *.jpe; *.png; *.bmp; *.dib; *.sr; *.ras; *.tiff; *.tif ||";

	CFileDialog fileDlg(TRUE, 
						NULL, 
						NULL, 
						OFN_EXPLORER|OFN_HIDEREADONLY, 
						szFilter
						);

	if( fileDlg.DoModal() == IDOK ) 
	{
		cImage.Load( fileDlg.GetPathName() );
		image2 = cImage.GetImage();

		// ũ�Ⱑ ��ġ���� ������
		if( image1->height != image2->height 
			|| image2->width != image2->width )
		{
			cUtil.GS_errMsg("ũ�Ⱑ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
		else if( image1->nChannels != image2->nChannels )
		{
			cUtil.GS_errMsg("ä�� ������ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
	}
	else
	{
		return;
	}

	// ���� ����
	IplImage *binary_image1 = cPixel.GS_threshold( cColor.GS_rgb2gray( image1 ),
												  0.0, 1.0, CV_THRESH_OTSU );
	IplImage *binary_image2 = cPixel.GS_threshold( cColor.GS_rgb2gray( image2 ),
												  0.0, 1.0, CV_THRESH_OTSU );

	// OR ����
	IplImage *binary_result_image = cPixel.GS_binary_logic( binary_image1, 
															binary_image2,
															2 );
	// ��� ���
	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, cPixel.GS_binary2gray(binary_image1), "Original image 1");
	mcv.GS_setPosition( 0, 1, cPixel.GS_binary2gray(binary_image2), "Original image 2");
	mcv.GS_setPosition( 0, 2, cPixel.GS_binary2gray(binary_result_image), "OR operation");
	mcv.GS_run( "[GS_binary_logic()] - ���� ���󿡼��� ���� ����" );

	// �Ҵ��� �޸� ����
	cImage.Destroy();
	cvReleaseImage( &binary_image1 );
	cvReleaseImage( &binary_image2 );
	cvReleaseImage( &binary_result_image );

	// ȭ�� ����
	Invalidate( FALSE );	
}

void COpenMFCView::OnChap8GrayLogicalAnd() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image1 = pDoc->m_cvvImage.GetImage();

	CPixel cPixel;
	CUtil cUtil;
	CColor cColor;
	IplImage *image2;
	CvvImage cImage;

	// �� ��° ������ �ҷ��´�.
	char szFilter[] = "JPEG file(*.jpeg, *.jpg, *.jpe) | *.jpeg; *.jpg; *.jpe |\
Portable Network Graphics file(*.png) | *.png |\
Windows bitmap files(*.bmp, *.dib) | *.bmp; *.dib |\
Sun rasters(*.sr, *.ras) | *.sr; *.ras |\
TIFF files(*.tiff, *.tif) | *.tiff; *.tif |\
�����ϴ� ��� ���� ����|*.jpeg; *.jpg; *.jpe; *.png; *.bmp; *.dib; *.sr; *.ras; *.tiff; *.tif ||";

	CFileDialog fileDlg(TRUE, 
						NULL, 
						NULL, 
						OFN_EXPLORER|OFN_HIDEREADONLY, 
						szFilter
						);

	if( fileDlg.DoModal() == IDOK ) 
	{
		cImage.Load( fileDlg.GetPathName() );
		image2 = cImage.GetImage();

		// ũ�Ⱑ ��ġ���� ������
		if( image1->height != image2->height 
			|| image2->width != image2->width )
		{
			cUtil.GS_errMsg("ũ�Ⱑ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
		else if( image1->nChannels != image2->nChannels )
		{
			cUtil.GS_errMsg("ä�� ������ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
	}
	else
	{
		return;
	}

	// ���� ����
	IplImage *gray_image1 = cColor.GS_rgb2gray( image1 );
	IplImage *gray_image2 = cColor.GS_rgb2gray( image2 );


	// AND ����
	IplImage *result_image = cPixel.GS_gray_logic( gray_image1, gray_image2, 0 );

	// ��� ���
	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, gray_image1, "Original image 1");
	mcv.GS_setPosition( 0, 1, gray_image2, "Original image 2");
	mcv.GS_setPosition( 0, 2, result_image, "AND operation");
	mcv.GS_run( "[GS_gray_logic()] - ���ϵ� ���󿡼��� ���� ����" );

	// �Ҵ��� �޸� ����
	cImage.Destroy();
	cvReleaseImage( &gray_image1 );
	cvReleaseImage( &gray_image2 );
	cvReleaseImage( &result_image );

	// ȭ�� ����
	Invalidate( FALSE );
}

void COpenMFCView::OnChap8GrayLogicNand() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image1 = pDoc->m_cvvImage.GetImage();

	CPixel cPixel;
	CUtil cUtil;
	CColor cColor;
	IplImage *image2;
	CvvImage cImage;

	// �� ��° ������ �ҷ��´�.
	char szFilter[] = "JPEG file(*.jpeg, *.jpg, *.jpe) | *.jpeg; *.jpg; *.jpe |\
Portable Network Graphics file(*.png) | *.png |\
Windows bitmap files(*.bmp, *.dib) | *.bmp; *.dib |\
Sun rasters(*.sr, *.ras) | *.sr; *.ras |\
TIFF files(*.tiff, *.tif) | *.tiff; *.tif |\
�����ϴ� ��� ���� ����|*.jpeg; *.jpg; *.jpe; *.png; *.bmp; *.dib; *.sr; *.ras; *.tiff; *.tif ||";

	CFileDialog fileDlg(TRUE, 
						NULL, 
						NULL, 
						OFN_EXPLORER|OFN_HIDEREADONLY, 
						szFilter
						);

	if( fileDlg.DoModal() == IDOK ) 
	{
		cImage.Load( fileDlg.GetPathName() );
		image2 = cImage.GetImage();

		// ũ�Ⱑ ��ġ���� ������
		if( image1->height != image2->height 
			|| image2->width != image2->width )
		{
			cUtil.GS_errMsg("ũ�Ⱑ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
		else if( image1->nChannels != image2->nChannels )
		{
			cUtil.GS_errMsg("ä�� ������ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
	}
	else
	{
		return;
	}

	// ���� ����
	IplImage *gray_image1 = cColor.GS_rgb2gray( image1 );
	IplImage *gray_image2 = cColor.GS_rgb2gray( image2 );


	// NAND ����
	IplImage *result_image = cPixel.GS_gray_logic( gray_image1, gray_image2, 1 );

	// ��� ���
	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, gray_image1, "Original image 1");
	mcv.GS_setPosition( 0, 1, gray_image2, "Original image 2");
	mcv.GS_setPosition( 0, 2, result_image, "NAND operation");
	mcv.GS_run( "[GS_gray_logic()] - ���ϵ� ���󿡼��� ���� ����" );

	// �Ҵ��� �޸� ����
	cImage.Destroy();
	cvReleaseImage( &gray_image1 );
	cvReleaseImage( &gray_image2 );
	cvReleaseImage( &result_image );

	// ȭ�� ����
	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap8GrayLogicOr() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	IplImage *image1 = pDoc->m_cvvImage.GetImage();

	CPixel cPixel;
	CUtil cUtil;
	CColor cColor;
	IplImage *image2;
	CvvImage cImage;

	// �� ��° ������ �ҷ��´�.
	char szFilter[] = "JPEG file(*.jpeg, *.jpg, *.jpe) | *.jpeg; *.jpg; *.jpe |\
Portable Network Graphics file(*.png) | *.png |\
Windows bitmap files(*.bmp, *.dib) | *.bmp; *.dib |\
Sun rasters(*.sr, *.ras) | *.sr; *.ras |\
TIFF files(*.tiff, *.tif) | *.tiff; *.tif |\
�����ϴ� ��� ���� ����|*.jpeg; *.jpg; *.jpe; *.png; *.bmp; *.dib; *.sr; *.ras; *.tiff; *.tif ||";

	CFileDialog fileDlg(TRUE, 
						NULL, 
						NULL, 
						OFN_EXPLORER|OFN_HIDEREADONLY, 
						szFilter
						);

	if( fileDlg.DoModal() == IDOK ) 
	{
		cImage.Load( fileDlg.GetPathName() );
		image2 = cImage.GetImage();

		// ũ�Ⱑ ��ġ���� ������
		if( image1->height != image2->height 
			|| image2->width != image2->width )
		{
			cUtil.GS_errMsg("ũ�Ⱑ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
		else if( image1->nChannels != image2->nChannels )
		{
			cUtil.GS_errMsg("ä�� ������ ��ġ���� �ʽ��ϴ�!");
			cImage.Destroy();
			return;
		}
	}
	else
	{
		return;
	}

	// ���� ����
	IplImage *gray_image1 = cColor.GS_rgb2gray( image1 );
	IplImage *gray_image2 = cColor.GS_rgb2gray( image2 );


	// OR ����
	IplImage *result_image = cPixel.GS_gray_logic( gray_image1, gray_image2, 2 );

	// ��� ���
	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, gray_image1, "Original image 1");
	mcv.GS_setPosition( 0, 1, gray_image2, "Original image 2");
	mcv.GS_setPosition( 0, 2, result_image, "OR operation");
	mcv.GS_run( "[GS_gray_logic()] - ���ϵ� ���󿡼��� ���� ����" );

	// �Ҵ��� �޸� ����
	cImage.Destroy();
	cvReleaseImage( &gray_image1 );
	cvReleaseImage( &gray_image2 );
	cvReleaseImage( &result_image );

	// ȭ�� ����
	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9Conv2() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// CvMat���� ��ȯ.
	float mask[] = { -1.0f/3.0f,  0.0f/3.0f, -1.0f/3.0f,
					    0.0f/3.0f,  7.0f/3.0f,  0.0f/3.0f,
					   -1.0f/3.0f,  0.0f/3.0f, -1.0f/3.0f };

	CvMat mat_kernel = cvMat( 3, 3, CV_32FC1, mask );
	IplImage *result_image = cFilter.GS_conv2( gray_image, &mat_kernel );

	// ��� ���
	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, "Result image");
	mcv.GS_run( "[GS_conv2()] - ȸ�� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );
	cvReleaseData( &mat_kernel );;

	Invalidate( FALSE );		
}

void COpenMFCView::OnChap9GrayEmbossing() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	IplImage *result_image1 = cFilter.GS_embossing( gray_image, 0 );
	IplImage *result_image2 = cFilter.GS_embossing( gray_image, 1 );
	IplImage *result_image3 = cFilter.GS_embossing( gray_image, 2 );

	// ��� ���
	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image1, "135 angle");
	mcv.GS_setPosition( 0, 2, result_image2, "90 angle");
	mcv.GS_setPosition( 0, 3, result_image3, "45 angle");
	mcv.GS_run( "[GS_embossing()] - ���ϵ� ���󿡼��� ȸ�� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );


	Invalidate( FALSE );	
	
}

void COpenMFCView::OnChap9RgbEmbossing() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();

	IplImage *result_image1 = cFilter.GS_rgb_embossing( image, 0 );
	IplImage *result_image2 = cFilter.GS_rgb_embossing( image, 1 );
	IplImage *result_image3 = cFilter.GS_rgb_embossing( image, 2 );

	// ��� ���
	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image1, "135 angle");
	mcv.GS_setPosition( 0, 2, result_image2, "90 angle");
	mcv.GS_setPosition( 0, 3, result_image3, "45 angle");
	mcv.GS_run( "[GS_rgb_embossing()] - RGB �÷� ���������� ȸ�� ���� ���" );

	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );	
	
}

void COpenMFCView::OnChap9HsvEmbossing() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();

	IplImage *result_image1 = cFilter.GS_hsv_embossing( image, 0 );
	IplImage *result_image2 = cFilter.GS_hsv_embossing( image, 1 );
	IplImage *result_image3 = cFilter.GS_hsv_embossing( image, 2 );

	// ��� ���
	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image1, "135 angle");
	mcv.GS_setPosition( 0, 2, result_image2, "90 angle");
	mcv.GS_setPosition( 0, 3, result_image3, "45 angle");
	mcv.GS_run( "[GS_hsv_embossing()] - HSV �÷� ���������� ȸ�� ���� ���" );

	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9WildEmbossing() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}
	
	IplImage *result_image1 = cFilter.GS_wild_embossing( gray_image, 0 );
	IplImage *result_image2 = cFilter.GS_wild_embossing( gray_image, 1 ); 
	IplImage *result_image3 = cFilter.GS_wild_embossing( gray_image, 2 ); 
	IplImage *result_image4 = cFilter.GS_wild_embossing( gray_image, 3 ); 
	IplImage *result_image5 = cFilter.GS_wild_embossing( gray_image, 4 ); 

	// ��� ���
	CMultiChannelViewer mcv1(1, 3);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 0, 1, result_image1, "North");
	mcv1.GS_setPosition( 0, 2, result_image2, "West");
	mcv1.GS_run( "[GS_wild_embossing()] - ���ϵ� ���󿡼��� ȸ�� ���� ���" );

	// ��� ���
	CMultiChannelViewer mcv2(1, 3);
	mcv2.GS_setPosition( 0, 0, result_image3, "South");
	mcv2.GS_setPosition( 0, 1, result_image4, "East");
	mcv2.GS_setPosition( 0, 2, result_image5, "NorthEast");
	mcv2.GS_run( "[GS_wild_embossing()] - ���ϵ� ���󿡼��� ȸ�� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );
	cvReleaseImage( &result_image5 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9Blurring1() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	LARGE_INTEGER frequency1, tStart1, tEnd1;
	QueryPerformanceFrequency( &frequency1 );
	QueryPerformanceCounter( &tStart1 );

	// Using cvFilter2D(), 3x3
	IplImage *result_image1 = cFilter.GS_blurring( gray_image, 0, 0 );

	QueryPerformanceCounter( &tEnd1 );
	double tElpased1 = (double)(tEnd1.QuadPart - tStart1.QuadPart)/(double)frequency1.QuadPart;
	CString msg1 = "";
	msg1.Format("* [3x3] ������ ���� �ð� : %5.5f ��", tElpased1);
	pDoc->InsertLogWindow(msg1);
	Invalidate( FALSE );

	LARGE_INTEGER frequency2, tStart2, tEnd2;
	QueryPerformanceFrequency( &frequency2 );
	QueryPerformanceCounter( &tStart2 );

	// Using cvFilter2D(), 5x5
	IplImage *result_image2 = cFilter.GS_blurring( gray_image, 0, 1 );

	QueryPerformanceCounter( &tEnd2 );
	double tElpased2 = (double)(tEnd2.QuadPart - tStart2.QuadPart)/(double)frequency2.QuadPart;
	CString msg2 = "";
	msg2.Format("* [5x5] ������ ���� �ð� : %5.5f ��", tElpased2);
	pDoc->InsertLogWindow(msg2);
	Invalidate( FALSE );

	LARGE_INTEGER frequency3, tStart3, tEnd3;
	QueryPerformanceFrequency( &frequency3 );
	QueryPerformanceCounter( &tStart3 );

	// Using cvFilter2D(), 7x7
	IplImage *result_image3 = cFilter.GS_blurring( gray_image, 0, 2 );

	QueryPerformanceCounter( &tEnd3 );
	double tElpased3 = (double)(tEnd3.QuadPart - tStart3.QuadPart)/(double)frequency3.QuadPart;
	CString msg3 = "";
	msg3.Format("* [7x7] ������ ���� �ð� : %5.5f ��", tElpased3);
	pDoc->InsertLogWindow(msg3);
	Invalidate( FALSE );

	// ��� ���
	CMultiChannelViewer mcv1(1, 4);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 0, 1, result_image1, "[3x3] blurring");
	mcv1.GS_setPosition( 0, 2, result_image2, "[5x5] blurring");
	mcv1.GS_setPosition( 0, 3, result_image3, "[7x7] blurring");
	mcv1.GS_run( "[GS_blurring()] - cvFilter2D(), 3x3, 5x5, 7x7 ������ ����ũ ȸ��" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );
}

void COpenMFCView::OnChap9Blurring2() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// Using cvSmooth(), �⺻ ������, 3x3
	IplImage *result_image1 = cFilter.GS_blurring( gray_image, 1, 0 ); // CV_BLUR

	// Using cvSmooth(), ����þ� ������, 3x3
	IplImage *result_image2 = cFilter.GS_blurring( gray_image, 2, 0 ); // CV_GAUSSIAN

	// Using cvSmooth(), �߰��� ������, 3x3
	IplImage *result_image3 = cFilter.GS_blurring( gray_image, 3, 0 ); // CV_MEDIAN

	// Using cvSmooth(), �����ͷ� ������
	IplImage *result_image4 = cFilter.GS_blurring( gray_image, 4, 0 ); // CV_BILATERAL

	CMultiChannelViewer mcv1(2, 3);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 0, 1, result_image1, "[3x3] CV_BLUR");
	mcv1.GS_setPosition( 0, 2, result_image2, "[3x3] CV_GAUSSIAN");
	mcv1.GS_setPosition( 1, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 1, 1, result_image3, "[3x3] CV_MEDIAN");
	mcv1.GS_setPosition( 1, 2, result_image4, "[3x3] CV_BILATERAL");
	mcv1.GS_run( "[GS_blurring()] - cvSmooth()�� 4���� ������ ���(3x3)" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap9Sharpening() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// 
	IplImage *result_image1 = cFilter.GS_sharpening( gray_image, 0 );
	IplImage *result_image2 = cFilter.GS_sharpening( gray_image, 1 );
	IplImage *result_image3 = cFilter.GS_sharpening( gray_image, 2 );

	//
	IplImage *result_image4 = cFilter.GS_sharpening( gray_image, 3 );
	IplImage *result_image5 = cFilter.GS_sharpening( gray_image, 4 );
	IplImage *result_image6 = cFilter.GS_sharpening( gray_image, 5 );

	CMultiChannelViewer mcv1(1, 4);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 0, 1, result_image1, "method = 0");
	mcv1.GS_setPosition( 0, 2, result_image2, "method = 1");
	mcv1.GS_setPosition( 0, 3, result_image3, "method = 2");
	mcv1.GS_run( "[GS_sharpening()] - �����׿� ���� ȸ�� ���" );

	CMultiChannelViewer mcv2(1, 4);
	mcv2.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv2.GS_setPosition( 0, 1, result_image4, "method = 3");
	mcv2.GS_setPosition( 0, 2, result_image5, "method = 4");
	mcv2.GS_setPosition( 0, 3, result_image6, "method = 5");
	mcv2.GS_run( "[GS_sharpening()] - �����׿� ���� ȸ�� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );
	cvReleaseImage( &result_image5 );
	cvReleaseImage( &result_image6 );

	Invalidate( FALSE );
}

void COpenMFCView::OnChap9HighBoost() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	float bias = 128.0f;

	// 
	IplImage *result_image1 = cFilter.GS_high_boost( gray_image, 1.0f, bias );
	IplImage *result_image2 = cFilter.GS_high_boost( gray_image, 1.2f, bias );
	IplImage *result_image3 = cFilter.GS_high_boost( gray_image, 1.5f, bias );

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image1, "alpha = 1.0");
	mcv.GS_setPosition( 0, 2, result_image2, "alpha = 1.2");
	mcv.GS_setPosition( 0, 3, result_image3, "alpha = 1.5");
	mcv.GS_run( "[GS_high_boost()] - ������ ���� ��� ���͸� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap9Unsharpening() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	float bias = 32.0f;

	// 
	IplImage *result_image1 = cFilter.GS_unsharpening( gray_image, 0, bias );
	IplImage *result_image2 = cFilter.GS_unsharpening( gray_image, 1, bias );
	IplImage *result_image3 = cFilter.GS_unsharpening( gray_image, 2, bias );

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image1, "By 3x3 mask");
	mcv.GS_setPosition( 0, 2, result_image2, "By 5x5 mask");
	mcv.GS_setPosition( 0, 3, result_image3, "By 7x7 mask");
	mcv.GS_run( "[GS_unsharpening()] - ������� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap9EnhanceFilter() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// 
	IplImage *result_image1 = cFilter.GS_enhance_filter( gray_image, 0 );
	IplImage *result_image2 = cFilter.GS_enhance_filter( gray_image, 1 );

	CMultiChannelViewer mcv1(1, 3);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 0, 1, result_image1, "Enhance focus filter");
	mcv1.GS_setPosition( 0, 2, result_image2, "Enhance detail filter");
	mcv1.GS_run( "[GS_enhance_filter()] - ���ڽ� ��Ŀ��/������ ���� 1ȸ ���� ���" );

	// 
	IplImage *result_image3 = cFilter.GS_enhance_filter( result_image1, 0 );
	IplImage *result_image4 = cFilter.GS_enhance_filter( result_image2, 1 );

	CMultiChannelViewer mcv2(1, 3);
	mcv2.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv2.GS_setPosition( 0, 1, result_image3, "Enhance focus filter");
	mcv2.GS_setPosition( 0, 2, result_image4, "Enhance detail filter");
	mcv2.GS_run( "[GS_enhance_filter()] - ���ڽ� ��Ŀ��/������ ���� 2ȸ ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );

	Invalidate( FALSE );
}

void COpenMFCView::OnChap9BlurLightBlendingFilter() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// 
	IplImage *result_image1 = cFilter.GS_blur_lb_filter( gray_image, 0 );
	IplImage *result_image2 = cFilter.GS_blur_lb_filter( gray_image, 1 );

	CMultiChannelViewer mcv1(1, 3);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 0, 1, result_image1, "Blur light filter");
	mcv1.GS_setPosition( 0, 2, result_image2, "Blur blending filter");
	mcv1.GS_run( "[GS_blur_lb_filter()] - ���� ����Ʈ/������ ���� 1ȸ ���� ���" );

	// 
	IplImage *result_image3 = cFilter.GS_blur_lb_filter( result_image1, 0 );
	IplImage *result_image4 = cFilter.GS_blur_lb_filter( result_image2, 1 );

	CMultiChannelViewer mcv2(1, 3);
	mcv2.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv2.GS_setPosition( 0, 1, result_image3, "Blur light filter");
	mcv2.GS_setPosition( 0, 2, result_image4, "Blur blending filter");
	mcv2.GS_run( "[GS_blur_lb_filter()] - ���� ����Ʈ/������ ���� 2ȸ ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9SoftenFilter() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// 
	IplImage *result_image1 = cFilter.GS_soften_filter( gray_image, 0 );
	IplImage *result_image2 = cFilter.GS_soften_filter( gray_image, 1 );
	IplImage *result_image3 = cFilter.GS_soften_filter( gray_image, 2 );

	CMultiChannelViewer mcv1(1, 4);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 0, 1, result_image1, "method = 0");
	mcv1.GS_setPosition( 0, 2, result_image2, "method = 1");
	mcv1.GS_setPosition( 0, 3, result_image3, "method = 2");
	mcv1.GS_run( "[GS_soften_filter()] - ������ ���� 1ȸ ���� ���" );

	// 
	IplImage *result_image4 = cFilter.GS_soften_filter( result_image1, 0 );
	IplImage *result_image5 = cFilter.GS_soften_filter( result_image2, 1 );
	IplImage *result_image6 = cFilter.GS_soften_filter( result_image3, 2 );

	CMultiChannelViewer mcv2(1, 4);
	mcv2.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv2.GS_setPosition( 0, 1, result_image4, "method = 0");
	mcv2.GS_setPosition( 0, 2, result_image5, "method = 1");
	mcv2.GS_setPosition( 0, 3, result_image6, "method = 2");
	mcv2.GS_run( "[GS_soften_filter()] - ������ ���� 2ȸ ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );
	cvReleaseImage( &result_image5 );
	cvReleaseImage( &result_image6 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9CompareBlurFilter() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// ������
	IplImage *blurring_image = cFilter.GS_blurring( gray_image, 0, 0 );

	// ���� ����Ʈ/������ ���� 
	IplImage *result_image1 = cFilter.GS_blur_lb_filter( gray_image, 0 );
	IplImage *result_image2 = cFilter.GS_blur_lb_filter( gray_image, 1 );
	IplImage *result_image3 = cFilter.GS_blur_lb_filter( result_image1, 0 );
	IplImage *result_image4 = cFilter.GS_blur_lb_filter( result_image2, 1 );

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, blurring_image, "Blurring image");
	mcv.GS_setPosition( 0, 2, result_image3, "Blur light filter");
	mcv.GS_setPosition( 0, 3, result_image4, "Blur blending filter");
	mcv.GS_run( "�������� ���� ����Ʈ/������ ���� 2ȸ ���� ��� ��" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );
	cvReleaseImage( &blurring_image );

	Invalidate( FALSE );
}

void COpenMFCView::OnChap9CreateGaussianNoise() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CNoise cNoise;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	double dev = 100.0;
	double ave = 0.0;
	int length = 1000;
	IplImage *result_image = cNoise.GS_gaussian_noise( gray_image, dev, ave, length );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, "GAUSSIAN NOISE");
	mcv.GS_run( "[GS_gaussian_noise()]" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap9CreateExponetialNoise() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CNoise cNoise;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	double dev = 100.0;
	double ave = 0.0;
	int length = 1000;
	IplImage *result_image = cNoise.GS_exponential_noise( gray_image, dev, ave, length );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, "EXPONENTIAL NOISE");
	mcv.GS_run( "[GS_exponential_noise()]" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );		
}

void COpenMFCView::OnChap9CreatePossionlNoise() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CNoise cNoise;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	double dev = 100.0;
	double ave = 0.0;
	int length = 1000;
	IplImage *result_image = cNoise.GS_possion_noise( gray_image, dev, ave, length );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, "POSSION NOISE");
	mcv.GS_run( "[GS_possion_noise()]" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9CreateUniformNoise() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CNoise cNoise;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	double dev = 100.0;
	double ave = 0.0;
	IplImage *result_image = cNoise.GS_uniform_noise( gray_image, dev, ave );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, "UNIFORM NOISE");
	mcv.GS_run( "[GS_uniform_noise()]" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );
}

void COpenMFCView::OnChap9CreateImpulseNoise() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CNoise cNoise;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	double dev = 100.0;
	int length = 1000;
	IplImage *result_image = cNoise.GS_impulse_noise( gray_image, dev, length );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, "IMPULSE NOISE");
	mcv.GS_run( "[GS_impulse_noise()]" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9CreateSaltPepperNoise() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CNoise cNoise;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	double dev = 100.0;
	int length = 1000;
	IplImage *result_image = cNoise.GS_salt_pepper_noise( gray_image, dev, length );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, "SALT & PEPPER NOISE");
	mcv.GS_run( "[GS_salt_pepper_noise()]" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9CompareNoise1() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CNoise cNoise;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	double dev = 100.0;
	double ave = 0.0;
	int length = 1000;

	IplImage *result_image1 = cNoise.GS_gaussian_noise( gray_image, dev, ave, length );
	IplImage *result_image2 = cNoise.GS_exponential_noise( gray_image, dev, ave, length );
	IplImage *result_image3 = cNoise.GS_possion_noise( gray_image, dev, ave, length );
	IplImage *result_image4 = cNoise.GS_uniform_noise( gray_image, dev, ave );
	IplImage *result_image5 = cNoise.GS_impulse_noise( gray_image, dev, length );
	IplImage *result_image6 = cNoise.GS_salt_pepper_noise( gray_image, dev, length );

	CMultiChannelViewer mcv1(1, 4);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 0, 1, result_image1, "GAUSSIAN NOISE");
	mcv1.GS_setPosition( 0, 2, result_image2, "EXPONENTIAL NOISE");
	mcv1.GS_setPosition( 0, 3, result_image3, "POSSION NOISE");
	mcv1.GS_run( "�� ���� ���� ���� ���" );

	CMultiChannelViewer mcv2(1, 4);
	mcv2.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv2.GS_setPosition( 0, 1, result_image4, "UNIFORM NOISE");
	mcv2.GS_setPosition( 0, 2, result_image5, "IMPLUSE NOISE");
	mcv2.GS_setPosition( 0, 3, result_image6, "SALT & PEPPER NOISE");
	mcv2.GS_run( "�� ���� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );
	cvReleaseImage( &result_image5 );
	cvReleaseImage( &result_image6 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9CreateMultiGaussianNoise() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CNoise cNoise;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	double noiseRange = 0.3;
	IplImage *result_image = cNoise.GS_multi_gaussian_noise( gray_image, noiseRange );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, "MULTI-GAUSSIAN NOISE");
	mcv.GS_run( "[GS_multi_gaussian_noise()]" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9CreateLaplacianNoise() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CNoise cNoise;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	double laplacianCoff = -20.0;
	IplImage *result_image = cNoise.GS_laplacian_noise( gray_image, laplacianCoff );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, "LAPLACIAN NOISE");
	mcv.GS_run( "[GS_laplacian_noise()]" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap9CompareNoise2() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CNoise cNoise;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	double noiseRange = 0.3;
	double laplacianCoff = -20.0;
	
	IplImage *result_image1 = cNoise.GS_multi_gaussian_noise( gray_image, noiseRange );
	IplImage *result_image2 = cNoise.GS_laplacian_noise( gray_image, laplacianCoff );

	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image1, "MULTI-GAUSSIAN NOISE");
	mcv.GS_setPosition( 0, 2, result_image2, "LAPLACIAN NOISE");
	mcv.GS_run( "���� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9MedianFilteringQuicksort() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CNoise cNoise;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// ���޽� ���� ����
	IplImage *impulse_noise_image = cNoise.GS_impulse_noise( gray_image, 100.0, 2500 );

	// ���� ���� ����
	IplImage *uniform_noise_image = cNoise.GS_uniform_noise( gray_image );
	
	//
	IplImage *result_image1 = cFilter.GS_median_filtering( impulse_noise_image, 3, 3 );
	IplImage *result_image2 = cFilter.GS_median_filtering( uniform_noise_image, 3, 3 );

	CMultiChannelViewer mcv1(1, 2);
	mcv1.GS_setPosition( 0, 0, impulse_noise_image, "Impulse noise image");
	mcv1.GS_setPosition( 0, 1, result_image1, "Using quick sort");
	mcv1.GS_run( "[GS_median_filtering()] �� ������ �̿��� �̵�� ���͸� ���" );

	CMultiChannelViewer mcv2(1, 2);
	mcv2.GS_setPosition( 0, 0, uniform_noise_image, "Uniform noise image");
	mcv2.GS_setPosition( 0, 1, result_image2, "Using quick sort");
	mcv2.GS_run( "[GS_median_filtering()] �� ������ �̿��� �̵�� ���͸� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &impulse_noise_image );
	cvReleaseImage( &uniform_noise_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );

	Invalidate( FALSE );	
	
}

void COpenMFCView::OnChap9MedianFilteringQuickselect() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CNoise cNoise;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// ���޽� ���� ����
	IplImage *impulse_noise_image = cNoise.GS_impulse_noise( gray_image, 100.0, 2500 );

	// ���� ���� ����
	IplImage *uniform_noise_image = cNoise.GS_uniform_noise( gray_image );
	
	//
	IplImage *result_image1 = cFilter.GS_median_filtering( impulse_noise_image, 3, 3, 1 );
	IplImage *result_image2 = cFilter.GS_median_filtering( uniform_noise_image, 3, 3, 1 );

	CMultiChannelViewer mcv1(1, 2);
	mcv1.GS_setPosition( 0, 0, impulse_noise_image, "Impulse noise image");
	mcv1.GS_setPosition( 0, 1, result_image1, "Using quick select");
	mcv1.GS_run( "[GS_median_filtering()] �� ������ �̿��� �̵�� ���͸� ���" );

	CMultiChannelViewer mcv2(1, 2);
	mcv2.GS_setPosition( 0, 0, uniform_noise_image, "Uniform noise image");
	mcv2.GS_setPosition( 0, 1, result_image2, "Using quick select");
	mcv2.GS_run( "[GS_median_filtering()] �� ������ �̿��� �̵�� ���͸� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &impulse_noise_image );
	cvReleaseImage( &uniform_noise_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9MedianFilteringWirth() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CNoise cNoise;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// ���޽� ���� ����
	IplImage *impulse_noise_image = cNoise.GS_impulse_noise( gray_image, 100.0, 2500 );

	// ���� ���� ����
	IplImage *uniform_noise_image = cNoise.GS_uniform_noise( gray_image );
	
	//
	IplImage *result_image1 = cFilter.GS_median_filtering( impulse_noise_image, 3, 3, 2 );
	IplImage *result_image2 = cFilter.GS_median_filtering( uniform_noise_image, 3, 3, 2 );

	CMultiChannelViewer mcv1(1, 2);
	mcv1.GS_setPosition( 0, 0, impulse_noise_image, "Impulse noise image");
	mcv1.GS_setPosition( 0, 1, result_image1, "Using wirth sort");
	mcv1.GS_run( "[GS_median_filtering()] ���� ������ �̿��� �̵�� ���͸� ���" );

	CMultiChannelViewer mcv2(1, 2);
	mcv2.GS_setPosition( 0, 0, uniform_noise_image, "Uniform noise image");
	mcv2.GS_setPosition( 0, 1, result_image2, "Using wirth sort");
	mcv2.GS_run( "[GS_median_filtering()] ���� ������ �̿��� �̵�� ���͸� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &impulse_noise_image );
	cvReleaseImage( &uniform_noise_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9MeanFiltering() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CNoise cNoise;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// ���޽� ���� ����
	IplImage *impulse_noise_image = cNoise.GS_impulse_noise( gray_image );

	// ���� ���� ����
	IplImage *uniform_noise_image = cNoise.GS_uniform_noise( gray_image );
	
	//
	IplImage *result_image1 = cFilter.GS_mean_filtering( impulse_noise_image );
	IplImage *result_image2 = cFilter.GS_mean_filtering( uniform_noise_image );

	CMultiChannelViewer mcv1(1, 2);
	mcv1.GS_setPosition( 0, 0, impulse_noise_image, "Impulse noise image");
	mcv1.GS_setPosition( 0, 1, result_image1, "Result image");
	mcv1.GS_run( "[GS_mean_filtering()] ��հ� ���͸� ���" );

	CMultiChannelViewer mcv2(1, 2);
	mcv2.GS_setPosition( 0, 0, uniform_noise_image, "Uniform noise image");
	mcv2.GS_setPosition( 0, 1, result_image2, "Result image");
	mcv2.GS_run( "[GS_mean_filtering()] ��հ� ���͸� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &impulse_noise_image );
	cvReleaseImage( &uniform_noise_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );

	Invalidate( FALSE );	
	
}

void COpenMFCView::OnChap9AlphaTrimmedFiltering() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CNoise cNoise;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// ���޽� ���� ����
	IplImage *impulse_noise_image = cNoise.GS_impulse_noise( gray_image );

	// ����þ� ���� ����
	IplImage *gaussian_noise_image = cNoise.GS_gaussian_noise( gray_image );
	
	//
	IplImage *result_image1 = cFilter.GS_alpha_trim_mean_filtering( impulse_noise_image, 0.1 );
	IplImage *result_image2 = cFilter.GS_alpha_trim_mean_filtering( gaussian_noise_image, 0.5 );

	IplImage *result_image3 = cFilter.GS_alpha_trim_mean_filtering( impulse_noise_image, 0.1 );
	IplImage *result_image4 = cFilter.GS_alpha_trim_mean_filtering( gaussian_noise_image, 0.5 );

	CMultiChannelViewer mcv1(1, 3);
	mcv1.GS_setPosition( 0, 0, impulse_noise_image, "Impulse noise image");
	mcv1.GS_setPosition( 0, 1, result_image1, "Result image (alpha=0.1)");
	mcv1.GS_setPosition( 0, 2, result_image2, "Result image (alpha=0.5)");
	mcv1.GS_run( "[GS_alpha_trim_mean_filtering()] ��-trimmed ��հ� ���͸� ���" );

	CMultiChannelViewer mcv2(1, 3);
	mcv2.GS_setPosition( 0, 0, gaussian_noise_image, "Gaussian noise image");
	mcv2.GS_setPosition( 0, 1, result_image3, "Result image (alpha=0.1)");
	mcv2.GS_setPosition( 0, 2, result_image4, "Result image (alpha=0.5)");
	mcv2.GS_run( "[GS_alpha_trim_mean_filtering()] ��-trimmed ��հ� ���͸� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &impulse_noise_image );
	cvReleaseImage( &gaussian_noise_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );

	Invalidate( FALSE );
	
}


void COpenMFCView::OnChap9MaxminFiltering() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CNoise cNoise;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// ���޽� ���� ����
	IplImage *impulse_noise_image = cNoise.GS_impulse_noise( gray_image );

	// ���� ���� ����
	IplImage *uniform_noise_image = cNoise.GS_uniform_noise( gray_image );
	
	//
	IplImage *result_image1 = cFilter.GS_maxmin_filtering( impulse_noise_image, 0 );
	IplImage *result_image2 = cFilter.GS_maxmin_filtering( impulse_noise_image, 1 );
 
	//
	IplImage *result_image3 = cFilter.GS_maxmin_filtering( uniform_noise_image, 0 );
	IplImage *result_image4 = cFilter.GS_maxmin_filtering( uniform_noise_image, 1);

	//
	IplImage *result_image5 = cFilter.GS_maxmin_filtering( gray_image, 0 );
	IplImage *result_image6 = cFilter.GS_maxmin_filtering( gray_image, 1);

	CMultiChannelViewer mcv1(1, 3);
	mcv1.GS_setPosition( 0, 0, impulse_noise_image, "Impulse noise image");
	mcv1.GS_setPosition( 0, 1, result_image1, "Result image(maximum)");
	mcv1.GS_setPosition( 0, 2, result_image2, "Result image(minimum)");
	mcv1.GS_run( "[GS_maxmin_filtering()] ���޽� ���� ����, �ִ밪 ���͸�, �ּҰ� ���͸� ��� ��" );

	CMultiChannelViewer mcv2(1, 3);
	mcv2.GS_setPosition( 0, 0, uniform_noise_image, "Uniform noise image");
	mcv2.GS_setPosition( 0, 1, result_image3, "Result image(maximum)");
	mcv2.GS_setPosition( 0, 2, result_image4, "Result image(minimum)");
	mcv2.GS_run( "[GS_maxmin_filtering()] ���� ���� ����, �ִ밪 ���͸�, �ּҰ� ���͸� ��� ��" );

	CMultiChannelViewer mcv3(1, 3);
	mcv3.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv3.GS_setPosition( 0, 1, result_image5, "Result image(maximum)");
	mcv3.GS_setPosition( 0, 2, result_image6, "Result image(minimum)");
	mcv3.GS_run( "[GS_maxmin_filtering()] �� ����, �ִ밪 ���͸�, �ּҰ� ���͸� ��� ��" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &impulse_noise_image );
	cvReleaseImage( &uniform_noise_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );
	cvReleaseImage( &result_image5 );
	cvReleaseImage( &result_image6 );

	Invalidate( FALSE );	
	
}


void COpenMFCView::OnChap9OpeningClosingFiltering() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CNoise cNoise;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	// ���޽� ���� ����
	IplImage *impulse_noise_image = cNoise.GS_impulse_noise( gray_image );
	
	// ���� ���͸� : �ִ밪 ���͸� ������ �ּҰ� ���͸�
	IplImage *result_image1 = cFilter.GS_maxmin_filtering( impulse_noise_image, 0 ); // �ִ�
	IplImage *result_image2 = cFilter.GS_maxmin_filtering( result_image1, 1 ); // �ּ�

	// ���� ���͸� : �ּҰ� ���͸� ������ �ִ밪 ���͸�
	IplImage *result_image3 = cFilter.GS_maxmin_filtering( impulse_noise_image, 1 ); // �ּ�
	IplImage *result_image4 = cFilter.GS_maxmin_filtering( result_image3, 0 ); // �ִ�

	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, impulse_noise_image, "Impulse noise image");
	mcv.GS_setPosition( 0, 1, result_image2, "Result image(Opening)");
	mcv.GS_setPosition( 0, 2, result_image4, "Result image(Closing)");
	mcv.GS_run( "���޽� ���� ����, ���� ���͸�, ���� ���͸�" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &impulse_noise_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9GaussianSmoothingFiltering() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CFilter cFilter;
	CUtil  cUtil;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	double sigma = 0.4;
	IplImage *result_image1 = cFilter.GS_gaussian_smoothing_filtering( gray_image, sigma );

	sigma = 0.8;
	IplImage *result_image2 = cFilter.GS_gaussian_smoothing_filtering( gray_image, sigma );

	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image1, "Result image(sigma=0.4)");
	mcv.GS_setPosition( 0, 2, result_image2, "Result image(sigma=0.8)");
	mcv.GS_run( "[GS_gaussian_smoothing_filtering()] ����þ� ������ ���͸� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap9GradientEdge() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_gradient_edge( gray_image, 0 ); // ����
	IplImage *result_image2 = cEdge.GS_gradient_edge( gray_image, 1 ); // ����
	IplImage *result_image3 = cEdge.GS_gradient_edge( gray_image, 2 ); // magnitude

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image3, "Gradient edge");
	mcv.GS_setPosition( 0, 2, result_image2, "Horizontal edge");
	mcv.GS_setPosition( 0, 3, result_image1, "Vertical edge");
	mcv.GS_run( "[GS_gradient_edge()] �׷���Ʈ ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap9RangeFilterEdge() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image = cEdge.GS_range_filter_edge( gray_image );

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, "Edge image");
	mcv.GS_run( "[GS_range_filter_edge()] ���� ���Ϳ� ���� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChapSobelEdgeCvsobel() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_sobel_edge_cvSobel( gray_image, 0 ); // ����
	IplImage *result_image2 = cEdge.GS_sobel_edge_cvSobel( gray_image, 1 ); // ����
	IplImage *result_image3 = cEdge.GS_sobel_edge_cvSobel( gray_image, 2 ); // magnitude

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image3, "Sobel edge");
	mcv.GS_setPosition( 0, 2, result_image2, "Horizontal edge");
	mcv.GS_setPosition( 0, 3, result_image1, "Vertical edge");
	mcv.GS_run( "[GS_sobel_edge_cvSobel()] �Һ� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9SobelEdgeMask() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_sobel_edge( gray_image, 0 ); // ����
	IplImage *result_image2 = cEdge.GS_sobel_edge( gray_image, 1 ); // ����
	IplImage *result_image3 = cEdge.GS_sobel_edge( gray_image, 2 ); // magnitude

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image3, "Sobel edge");
	mcv.GS_setPosition( 0, 2, result_image2, "Horizontal edge");
	mcv.GS_setPosition( 0, 3, result_image1, "Vertical edge");
	mcv.GS_run( "[GS_sobel_edge()] �Һ� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9SobelEdge7x7() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_sobel_edge_7x7( gray_image, 0 ); // ����
	IplImage *result_image2 = cEdge.GS_sobel_edge_7x7( gray_image, 1 ); // ����
	IplImage *result_image3 = cEdge.GS_sobel_edge_7x7( gray_image, 2 ); // magnitude

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image3, "Sobel edge");
	mcv.GS_setPosition( 0, 2, result_image2, "Horizontal edge");
	mcv.GS_setPosition( 0, 3, result_image1, "Vertical edge");
	mcv.GS_run( "[GS_sobel_edge_7x7()] �Һ� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9SobelDigonalEdge() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_sobel_diagonal_edge( gray_image, 0 ); // ����
	IplImage *result_image2 = cEdge.GS_sobel_diagonal_edge( gray_image, 1 ); // ����
	IplImage *result_image3 = cEdge.GS_sobel_diagonal_edge( gray_image, 2 ); // magnitude

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image3, "Sobel edge");
	mcv.GS_setPosition( 0, 2, result_image2, "Digonal edge 1");
	mcv.GS_setPosition( 0, 3, result_image1, "Digonal edge 2");
	mcv.GS_run( "[GS_sobel_diagonal_edge()] �Һ� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9CompareSobelEdge() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_sobel_edge( gray_image ); 
	IplImage *result_image2 = cEdge.GS_sobel_edge_cvSobel( gray_image ); 

	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image1, "Sobel edge by mask");
	mcv.GS_setPosition( 0, 2, result_image2, "Sobel edge by cvSobel()");
	mcv.GS_run( "�Һ� ���� ���� ��� ��, ����ũ, cvSobel()" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );

	Invalidate( FALSE );
}

void COpenMFCView::OnChap9PrewittEdge() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_prewitt_edge( gray_image, 0 ); // ����
	IplImage *result_image2 = cEdge.GS_prewitt_edge( gray_image, 1 ); // ����
	IplImage *result_image3 = cEdge.GS_prewitt_edge( gray_image, 2 ); // magnitude

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image3, "Prewitt edge");
	mcv.GS_setPosition( 0, 2, result_image2, "Horizontal edge");
	mcv.GS_setPosition( 0, 3, result_image1, "Vertical edge");
	mcv.GS_run( "[GS_prewitt_edge()] ������ ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9RobertsEdge() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_roberts_edge( gray_image, 0 ); // ����
	IplImage *result_image2 = cEdge.GS_roberts_edge( gray_image, 1 ); // ����
	IplImage *result_image3 = cEdge.GS_roberts_edge( gray_image, 2 ); // magnitude

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image3, "Roberts edge");
	mcv.GS_setPosition( 0, 2, result_image2, "Digonal edge 1");
	mcv.GS_setPosition( 0, 3, result_image1, "Digonal edge 2");
	mcv.GS_run( "[GS_roberts_edge()] �ι��� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9EdgeCompare() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_sobel_edge( gray_image ); 
	IplImage *result_image2 = cEdge.GS_prewitt_edge( gray_image ); 
	IplImage *result_image3 = cEdge.GS_roberts_edge( gray_image ); 

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image1, "Sobel edge");
	mcv.GS_setPosition( 0, 2, result_image2, "Prewitt edge");
	mcv.GS_setPosition( 0, 3, result_image3, "Roberts edge");
	mcv.GS_run( "�Һ�/������/�ι��� ���� ���� ��� ��" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChap9LaplacianEdgeMask() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_laplacian_edge( gray_image, 0 ); // 4���� - 1
	IplImage *result_image2 = cEdge.GS_laplacian_edge( gray_image, 1 ); // 4���� - 2
	IplImage *result_image3 = cEdge.GS_laplacian_edge( gray_image, 2 ); // 8���� - 1
	IplImage *result_image4 = cEdge.GS_laplacian_edge( gray_image, 3 ); // 8���� - 2

	CMultiChannelViewer mcv1(1, 3);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 0, 1, result_image1, "Four direction 1");
	mcv1.GS_setPosition( 0, 2, result_image2, "Four direction 2");
	mcv1.GS_run( "[GS_laplacian_edge()] ���ö�þ� ���� ���� ���" );

	CMultiChannelViewer mcv2(1, 3);
	mcv2.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv2.GS_setPosition( 0, 1, result_image3, "Eight direction 1");
	mcv2.GS_setPosition( 0, 2, result_image4, "Eight direction 2");
	mcv2.GS_run( "[GS_laplacian_edge()] ���ö�þ� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );

	Invalidate( FALSE );	
	
}

void COpenMFCView::OnChap9LaplacianEdgeCvlaplace() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image = cEdge.GS_laplacian_edge_cvLaplace( gray_image ); 

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image, "Laplacian Edge");
	mcv.GS_run( "[GS_laplacian_edge_cvLaplace()] ���ö�þ� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );	
	
}

void COpenMFCView::OnChap9LaplacianSharpening() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_laplacian_sharpening( gray_image, 0 ); // 4���� - 1
	IplImage *result_image2 = cEdge.GS_laplacian_sharpening( gray_image, 1 ); // 4���� - 2
	IplImage *result_image3 = cEdge.GS_laplacian_sharpening( gray_image, 2 ); // 8���� - 1
	IplImage *result_image4 = cEdge.GS_laplacian_sharpening( gray_image, 3 ); // 8���� - 2

	CMultiChannelViewer mcv1(1, 3);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 0, 1, result_image1, "Four direction 1");
	mcv1.GS_setPosition( 0, 2, result_image2, "Four direction 2");
	mcv1.GS_run( "[GS_laplacian_sharpening()] ���ö�þ� ������ ���" );

	CMultiChannelViewer mcv2(1, 3);
	mcv2.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv2.GS_setPosition( 0, 1, result_image3, "Eight direction 1");
	mcv2.GS_setPosition( 0, 2, result_image4, "Eight direction 2");
	mcv2.GS_run( "[GS_laplacian_sharpening()] ���ö�þ� ������ ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );

	Invalidate( FALSE );	
	
	
}

void COpenMFCView::OnChap9CompareLaplacianEdge() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_laplacian_edge( gray_image, 1 ); 
	IplImage *result_image2 = cEdge.GS_laplacian_edge_cvLaplace( gray_image );

	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image1, "Laplacian edge by mask");
	mcv.GS_setPosition( 0, 2, result_image2, "Laplacian edge by cvLaplace()");
	mcv.GS_run( "���ö�þ� ���� ���� ��� ��, ����ũ, cvLaplace()" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap9LogEdgeMask() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	double sigma = 0.8;

	//
	IplImage *result_image1 = cEdge.GS_LoG_edge( gray_image, sigma, 0 ); // 4���� - 1
	IplImage *result_image2 = cEdge.GS_LoG_edge( gray_image, sigma, 1 ); // 4���� - 2
	IplImage *result_image3 = cEdge.GS_LoG_edge( gray_image, sigma, 2 ); // 8���� - 1
	IplImage *result_image4 = cEdge.GS_LoG_edge( gray_image, sigma, 3 ); // 8���� - 2

	CMultiChannelViewer mcv1(1, 3);
	mcv1.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv1.GS_setPosition( 0, 1, result_image1, "Four direction 1");
	mcv1.GS_setPosition( 0, 2, result_image2, "Four direction 2");
	mcv1.GS_run( "[GS_LoG_edge()] LoG ���� ���� ���" );

	CMultiChannelViewer mcv2(1, 3);
	mcv2.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv2.GS_setPosition( 0, 1, result_image3, "Eight direction 1");
	mcv2.GS_setPosition( 0, 2, result_image4, "Eight direction 2");
	mcv2.GS_run( "[GS_LoG_edge()] LoG ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );
	cvReleaseImage( &result_image4 );

	Invalidate( FALSE );	
	
}

void COpenMFCView::OnChap9LogEdgeFormular() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;
	
	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	double sigma = 0.8;

	//
	IplImage *result_image = cEdge.GS_LoG2_edge( gray_image, sigma ); 

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image" );
	mcv.GS_setPosition( 0, 1, result_image, "LoG edge, sigma=0.8" );
	mcv.GS_run( "[GS_LoG2_edge()] ���Ŀ� ���� LoG ���� ���� ��� " );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );
	
	Invalidate( FALSE );
}

void COpenMFCView::OnChap9CannyEdgeCvcanny() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	double threshold1 = 0.0;
	double threshold2 = 70.0;

	//
	IplImage *result_image = cEdge.GS_canny_edge_cvCanny( gray_image, threshold1, threshold2 ); 

	CMultiChannelViewer mcv(1, 2);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image" );
	mcv.GS_setPosition( 0, 1, result_image, "Canny edge by cvCanny()" );
	mcv.GS_run( "[GS_canny_edge_cvCanny()] ĳ�� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap9CannyEdgeMask() 
{

	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	double sigma = 0.4;
	int threshold = 70;

	//
	IplImage *result_image1 = cEdge.GS_canny_edge( gray_image, sigma, threshold, 0 ); 
	IplImage *result_image2 = cEdge.GS_canny_edge( gray_image, sigma, threshold, 1 );
	IplImage *result_image3 = cEdge.GS_canny_edge( gray_image, sigma, threshold, 2 );

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image" );
	mcv.GS_setPosition( 0, 1, result_image1, "Canny edge with Sobel" );
	mcv.GS_setPosition( 0, 2, result_image2, "Canny edge with Prewitt" );
	mcv.GS_setPosition( 0, 3, result_image3, "Canny edge with Roberts" );
	mcv.GS_run( "[GS_canny_edge()] ĳ�� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );	
}

void COpenMFCView::OnChap9CompareCannyEdge() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	double sigma = 0.4;

	//
	IplImage *result_image1 = cEdge.GS_canny_edge_cvCanny( gray_image, 30, 70 ); 
	IplImage *result_image2 = cEdge.GS_canny_edge( gray_image, sigma, 30, 0 );

	CMultiChannelViewer mcv(1, 3);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image" );
	mcv.GS_setPosition( 0, 1, result_image1, "Canny edge with cvCanny()" );
	mcv.GS_setPosition( 0, 2, result_image2, "Canny edge with Sobel" );
	mcv.GS_run( "[GS_canny_edge()] ĳ�� ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );

	Invalidate( FALSE );		
}

void COpenMFCView::OnChap9StoachasticEdge() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_stochastic_edge( gray_image, 0 ); // ����
	IplImage *result_image2 = cEdge.GS_stochastic_edge( gray_image, 1 ); // ����
	IplImage *result_image3 = cEdge.GS_stochastic_edge( gray_image, 2 ); // magnitude

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image3, "Stochastic edge");
	mcv.GS_setPosition( 0, 2, result_image2, "Horizontal edge");
	mcv.GS_setPosition( 0, 3, result_image1, "Vertical edge");
	mcv.GS_run( "[GS_stochastic_edge()] ����ĳ��ƽ ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );
	
}

void COpenMFCView::OnChapFreiChenEdge() 
{
	COpenMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CColor cColor;
	CEdge cEdge;

	IplImage *image = pDoc->m_cvvImage.GetImage();
	IplImage *gray_image;

	// �÷��̸� ���ϵ��� ��ȯ
	if( image->nChannels == 3 ) 
	{
		gray_image = cColor.GS_rgb2gray( image );
	}
	else
	{
		gray_image = cvCloneImage( image );
	}

	//
	IplImage *result_image1 = cEdge.GS_freichen_edge( gray_image, 0 ); // ����
	IplImage *result_image2 = cEdge.GS_freichen_edge( gray_image, 1 ); // ����
	IplImage *result_image3 = cEdge.GS_freichen_edge( gray_image, 2 ); // magnitude

	CMultiChannelViewer mcv(1, 4);
	mcv.GS_setPosition( 0, 0, gray_image, "Original image");
	mcv.GS_setPosition( 0, 1, result_image3, "Frei-Chen edge");
	mcv.GS_setPosition( 0, 2, result_image2, "Horizontal edge");
	mcv.GS_setPosition( 0, 3, result_image1, "Vertical edge");
	mcv.GS_run( "[GS_freichen_edge()] ������þ ���� ���� ���" );

	cvReleaseImage( &gray_image );
	cvReleaseImage( &result_image1 );
	cvReleaseImage( &result_image2 );
	cvReleaseImage( &result_image3 );

	Invalidate( FALSE );	
}
