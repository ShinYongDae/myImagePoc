// Noise.cpp: implementation of the CNoise class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "openmfc.h"
#include "Noise.h"
#include "Util.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNoise::CNoise()
{

}

CNoise::~CNoise()
{

}

// Gaussian noise ���� 
// ex) dev = 100.0, ave = 0.0, length = 1000
IplImage *CNoise::GS_gaussian_noise(IplImage *src_image, double dev, double ave, int length)
{
	CUtil cUtil;
    int i, j;
    double var, area, tmp;
    double *prob, *tmpProb;
	double M_PI = 3.141592654;

	int height = src_image->height;
	int width = src_image->width;
	IplImage *dst_image = cUtil.GS_createImage( cvGetSize(src_image), src_image->nChannels );
	if( src_image->nChannels != 1 ) return dst_image;

    prob = (double *)calloc(length, sizeof(double));
    tmpProb = (double *)calloc(length, sizeof(double));

    var = -1.0 * length/2.0;
    area = 1.0 / sqrt(2 * M_PI * dev);
    tmpProb[0] = area * exp(-(var*var)/(2.0*dev));
    prob[0] = 0.0;

    // ����þ� ������ ä���.
    for (i=1; i<length; i++)
    {
		var++;
        tmpProb[i] = area * exp(-(var*var)/(2.0*dev));
        prob[i] = prob[i-1] + (tmpProb[i-1] + tmpProb[i])/2.0;
    }

    // ������ ä���.
    for(i=0; i<height; i++)
    {
        for(j=0; j<width; j++)
        {
            tmp = cvGetReal2D(src_image, i, j) + GS_get_noise(prob, length) - length/2 + ave;
			cvSetReal2D( dst_image, i, j, cUtil.GS_clamping(tmp) ); 
        }
    }

    free(tmpProb);
    free(prob);

    return dst_image;	
}

// exponential noise ���� 
// ex) dev = 100.0, ave = 0.0, length = 1000
IplImage *CNoise::GS_exponential_noise(IplImage *src_image, double dev, double ave, int length)
{
	CUtil cUtil;
    int i, j;
    double tmp, std;
    double *prob, *tmpProb;
	double M_PI = 3.141592654;

	int height = src_image->height;
	int width = src_image->width;
	IplImage *dst_image = cUtil.GS_createImage( cvGetSize(src_image), src_image->nChannels );
	if( src_image->nChannels != 1 ) return dst_image;

    prob = (double *)calloc(length, sizeof(double));
    tmpProb = (double *)calloc(length, sizeof(double));

	std = sqrt( dev );
    tmpProb[0] = 1.0/std;
    prob[0] = 0.0;

    for (i=1; i<length; i++)
    {
        tmpProb[i] = exp(-i/std)/std;
        prob[i] = prob[i-1] + (tmpProb[i-1] + tmpProb[i])/2.0;
    }

    // ������ ä���.
    for(i=0; i<height; i++)
    {
        for(j=0; j<width; j++)
        {
            tmp = cvGetReal2D(src_image, i, j) + GS_get_noise(prob, length) - std + ave;
            cvSetReal2D( dst_image, i, j, cUtil.GS_clamping(tmp) ); 
        }
    }

    free(tmpProb);
    free(prob);

    return dst_image;	
}

// possion noise ���� 
// ex) dev = 100.0, ave = 0.0, length = 1000
IplImage *CNoise::GS_possion_noise(IplImage *src_image, double dev, double ave, int length)
{
	CUtil cUtil;
    int i, j;
    double tmp;
    double *prob, *tmpProb;
	double M_PI = 3.141592654;

	int height = src_image->height;
	int width = src_image->width;
	IplImage *dst_image = cUtil.GS_createImage( cvGetSize(src_image), src_image->nChannels );
	if( src_image->nChannels != 1 ) return dst_image;

    prob = (double *)calloc(length, sizeof(double));
    tmpProb = (double *)calloc(length, sizeof(double));

    tmpProb[0] = exp(-dev);
    prob[0] = 0.0;

    for (i=1; i<length; i++)
    {
        tmpProb[i] = tmpProb[i-1] * dev/i;
        prob[i] = prob[i-1] + (tmpProb[i-1] + tmpProb[i])/2.0;
    }

    // ������ ä���.
    for(i=0; i<height; i++)
    {
        for(j=0; j<width; j++)
        {
            tmp = cvGetReal2D(src_image, i, j) + GS_get_noise(prob, length) - dev + ave;
            cvSetReal2D( dst_image, i, j, cUtil.GS_clamping(tmp) ); 
        }
    }

    free(tmpProb);
    free(prob);

    return dst_image;	
}

// uniform noise ���� 
// ex) dev = 100.0, ave = 0.0
IplImage *CNoise::GS_uniform_noise(IplImage *src_image, double dev, double ave)
{
	CUtil cUtil;
    int i, j, range;
	double tmp;

	int height = src_image->height;
	int width = src_image->width;
	IplImage *dst_image = cUtil.GS_createImage( cvGetSize(src_image), src_image->nChannels );
	if( src_image->nChannels != 1 ) return dst_image;

    // ������ ä���.
    for(i=0; i<height; i++)
    {
        for(j=0; j<width; j++)
        {
            range = (int)sqrt(dev*3)*2;
            tmp = cvGetReal2D(src_image, i, j) + (double)(rand() % range) - range/2 + ave;
            cvSetReal2D( dst_image, i, j, cUtil.GS_clamping(tmp) );
        }
    }

    return dst_image;	
}

// impulse noise ���� 
// ex) dev = 100.0, length = 1000
IplImage *CNoise::GS_impulse_noise(IplImage *src_image, double dev, int length)
{
	CUtil cUtil;
    int i, j, level = 256;

	int height = src_image->height;
	int width = src_image->width;
	IplImage *dst_image = cUtil.GS_createImage( cvGetSize(src_image), src_image->nChannels );
	if( src_image->nChannels != 1 ) return dst_image;

    // ������ ä���.
    for(i=0; i<height; i++)
    {
        for(j=0; j<width; j++)
        {
            if((rand() % length) < dev)
            {
	            cvSetReal2D( dst_image, i, j, level-1 ); 
            }
            else
            {
 				cvSetReal2D( dst_image, i, j, cvGetReal2D(src_image, i, j) );
            }
        }
    }

    return dst_image;	
}

// salt & paper noise ���� 
// ex) dev = 100.0, length = 1000
IplImage *CNoise::GS_salt_pepper_noise(IplImage *src_image, double dev, int length)
{
	CUtil cUtil;
    int i, j, level = 256;
	int salt_pepper_var, var;

	int height = src_image->height;
	int width = src_image->width;
	IplImage *dst_image = cUtil.GS_createImage( cvGetSize(src_image), src_image->nChannels );
	if( src_image->nChannels != 1 ) return dst_image;

    // ������ ä���.
    for(i=0; i<height; i++)
    {
        for(j=0; j<width; j++)
        {
            if((rand() % length) < dev)
            {
				salt_pepper_var = (int)( rand() % 2 );

				// salt
				if( salt_pepper_var < 1 ) var = 0;
				// pepper
				else var = level - 1;

				cvSetReal2D( dst_image, i, j, var );
            }
            else
            {
                cvSetReal2D( dst_image, i, j, cvGetReal2D(src_image, i, j) );
            }
        }
    }

    return dst_image;	
}

// multi-gaussian noise ����
// ex) noiseRange = 0.3
IplImage *CNoise::GS_multi_gaussian_noise(IplImage *src_image, double noiseRange)
{
	CUtil cUtil;
	double EPSILON = 0.000001;
	double randValue = 0.0;
	double var = 0.0, preGauss = 0.0, gauss = 0.0;
	double M_PI = 3.141592654;

	int height = src_image->height;
	int width = src_image->width;
	IplImage *dst_image = cUtil.GS_createImage( cvGetSize(src_image), src_image->nChannels );
	if( src_image->nChannels != 1 ) return dst_image;

    // ������ ä���.
    for(int i=0; i<height; i++)
    {
        for(int j=0; j<width; j++)
        {
			// STEP 1 : 1�� gaussian noise �߻�
			randValue = rand() / (RAND_MAX + 1.0);
			preGauss = randValue <= EPSILON ? 255.0 : sqrt(-2.0 * log(randValue));        

			// Step2 : 2�� gaussian noise ���� 
			randValue = rand() / (RAND_MAX + 1.0);
			gauss = preGauss * cos(2.0*M_PI*randValue); // sin()�� ����
			var = 0.5 + cvGetReal2D(src_image, i, j) + cvGetReal2D(src_image, i, j)*noiseRange*gauss;

			cvSetReal2D( dst_image, i, j, cUtil.GS_clamping(var) ); 
        }
    }
	
	return dst_image;
}

// laplacian noise ����
// ex) lapacianCoff = -20.0
IplImage *CNoise::GS_laplacian_noise(IplImage *src_image, double laplacianCoff)
{
	CUtil cUtil;
	double EPSILON = 0.000001;
	double randValue = 0.0, var = 0.0, tmp = 0.0, pVar = 0.0;

	int height = src_image->height;
	int width = src_image->width;
	IplImage *dst_image = cUtil.GS_createImage( cvGetSize(src_image), src_image->nChannels );
	if( src_image->nChannels != 1 ) return dst_image;

    // ������ ä���.
    for(int i=0; i<height; i++)
    {
        for(int j=0; j<width; j++)
        {
			randValue = rand() / (RAND_MAX + 1.0);
			pVar = cvGetReal2D(src_image, i, j);

			if( randValue <= 0.5 )
			{
				var = (randValue <=EPSILON) ? (pVar - 255) 
						: 0.5 + pVar + laplacianCoff*log(2.0*randValue); 
			}
			else 
			{
				tmp = 1.0 - randValue;
				var = (tmp <= 0.5*EPSILON) ? (pVar + 255) 
						:  0.5 + pVar - laplacianCoff*log(2.0*tmp); 
			}

			cvSetReal2D( dst_image, i, j, cUtil.GS_clamping(var) ); 
        }
    }
	
	return dst_image;
}

//�ش� ������ �� ���Ƿ� �����Ͽ� �����´�.
int CNoise::GS_get_noise(double *prob, int length)
{
    int low = 0;
    int mid = (length - 1) / 2;
    int high = length - 1;
	int random = 1 + rand() % (length - 1);

    // ���� Ž����(binary search) ����
    while (low < high)
    {
        mid = (low + high) / 2;
        if (prob[mid] * length < random)
        {
            low = mid + 1;
        }
        else if (prob[mid] * length > random)
        {
            high = mid - 1;
        }
        else
        {
            low = high = mid;
        }
    }

   return mid;
}