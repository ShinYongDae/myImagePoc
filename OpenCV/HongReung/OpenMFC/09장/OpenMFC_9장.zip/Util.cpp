/*
 * Util.cpp : ��ƿ��Ƽ ���� Ŭ���� 
 * Modified by Lee, Moon-Ho (conv2@korea.com)
 * Last Modified : 2006/11/16
 */

#include "stdafx.h"
#include "openmfc.h"
#include "Util.h"

// ȭ�� ���
#include "MainFrm.h"
#include "ChildFrm.h"
#include "OpenMFCDoc.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUtil::CUtil()
{

}

CUtil::~CUtil()
{

}

// Wirth sort : not recurisive sorting algorithm by N. Devilard from N. Wirth's book
BYTE CUtil::GS_writh_sort( BYTE *data, int length )
{
	int i, j, l, m, k;
	short x;

	l=0; m=length-1; 
	k = (length % 2 == 1) ? (length/2 -1) : length/2;

	while( l<m )
	{
		x = data[k];
		i=l;
		j=m;
		do 
		{
			while( data[i] < x ) i++;
			while( x < data[j] ) j--;
			if( i<=j )
			{
				GS_SWAP( data, i, j );
				i++; j--;
			}
		}
		while( i<=j );
		if( j<k ) l = i;
		if( k<i ) m = j;
	}
        
	return data[k];
}

// Quick Select
BYTE CUtil::GS_quick_select(BYTE *data, int length )
{
	int low, high;
	int median;
	int middle, ll, hh;

	low = 0; 
	high = length - 1; 
	median = (low + high)/2;

	for( ; ; ) 
	{
		/* One elements only */
		if( high <= low )
		{
			return data[median];
		}
    
		/* Two elements only */
		if( high == low + 1 ) 
		{
			if( data[low] > data[high] )
			{
				GS_SWAP( data, low, high );
			}
        
			return data[median];
		}
    
		/* Find median of low, middle and high items; swap into position low */
		middle = ( low + high )/2;
    
		if( data[middle] > data[high] ) GS_SWAP( data, middle, high );
		if( data[low] > data[high] ) GS_SWAP( data, low, high );
		if( data[middle] > data[low] ) GS_SWAP( data, middle, low );
    
		/* Swap low item (now in position middle) into position (low+1) */
		GS_SWAP( data, middle, low+1 );
    
		/* Nibble from each end towards middle, swapping items when stuck */
		ll = low + 1;
		hh = high;
		for( ; ; )
		{
			do ll++; while ( data[low] > data[ll] );
			do hh--; while (data[hh] > data[low] );
        
			if( hh<ll ) break;
        
			GS_SWAP( data, ll, hh );
		}
    
		/* Swap middle item (in position low) back into correct position */
		GS_SWAP( data, low, hh );
    
		/* Re-set active partition */
		if( hh <= median ) low = ll;
		if( hh >= median ) high = hh - 1;
	}
}

// swap 
void CUtil::GS_SWAP(BYTE *data, int x, int y)
{
	BYTE tmp;
	tmp = data[x];
	data[x] = data[y];
	data[y] = tmp;
}

// quick sort
void CUtil::GS_quick_sort(BYTE *data, int left, int right)
{
	int i,j;
	BYTE x,y;

	i = left;
	j = right;

	x = data[(left+right)/2];
	
	do {
		while(data[i]<x && i<right) i++;
		while(x<data[j] && j>left) j--;

		if(i<=j) {
			y = data[i];
			data[i] = data[j];
			data[j] = y;
			i++;
			j--;
		}
	}while(i<=j);

	if(left<j) GS_quick_sort(data,left,j);
	if(i<right) GS_quick_sort(data,i,right);
}

// 2������ 1�������� ��ȯ
float *CUtil::GS_toSingleArray( float **data, int height, int width )
{
	int cnt = -1;
	float *single_data = GS_floatAlloc1D( height*width );

	for(int i=0; i<height; i++)
	{
		for(int j=0; j<width; j++)
		{
			single_data[++cnt] = data[i][j];
		}
	}

	return single_data;
}

// 2���� �޸� �Ҵ�
float **CUtil::GS_floatAlloc2D(int height, int width)
{
	float **data;

	data = (float **)calloc(height, sizeof(float *));
	for(int i=0; i<height; i++)
	{
		data[i] = (float *)calloc(width, sizeof(float));
	}

	return data;
}

// 2���� �޸� �Ҵ�
double **CUtil::GS_doubleAlloc2D(int height, int width)
{
	double **data;

	data = (double **)calloc(height, sizeof(double *));
	for(int i=0; i<height; i++)
	{
		data[i] = (double *)calloc(width, sizeof(double));
	}

	return data;
}

// �Ҵ��� 2���� �޸� ����
void CUtil::GS_free2D(double **data, int length)
{
	for(int i=0; i<length; i++)
		free( data[i] );

	free(data);
}

// �Ҵ��� 2���� �޸� ����
void CUtil::GS_free2D(float **data, int length)
{
	for(int i=0; i<length; i++)
		free( data[i] );

	free(data);
}

// 1���� �޸� �Ҵ�
float *CUtil::GS_floatAlloc1D( int length )
{
	return (float *)calloc(length, sizeof(float));
}

// �Ҵ��� 1���� �޸� ����
void CUtil::GS_free1D( float *data )
{
	if( !data ) free(data);
}


// �ϳ��� â���� ����ش�. not using OpenCV
void CUtil::GS_showWindow( IplImage *image, char *caption_title )
{
	CMainFrame *pFrame = (CMainFrame *)AfxGetMainWnd();
	CChildFrame *pChild = (CChildFrame *)pFrame->GetActiveFrame();
	COpenMFCDoc *pDoc = (COpenMFCDoc *)pChild->GetActiveDocument();

	// ���н�
	if( !image ) return;

	// ���ο� â�� ����.
	pDoc->CopyClipBoard( image );
	((COpenMFCApp *)AfxGetApp())->OnEditPaste();

	// â ������ �����Ѵ�.
	COpenMFCDoc *pDoc1 = (COpenMFCDoc *)
		((CMDIFrameWnd*)AfxGetMainWnd())->GetActiveFrame()
		->GetActiveDocument();

	pDoc1->SetTitle(caption_title);	

	return;	
}

IplImage *CUtil::GS_createImage( CvSize size, int nChannels )
{
	IplImage *dst_image = cvCreateImage( size, IPL_DEPTH_8U, nChannels );
	cvSetZero( dst_image );

	return dst_image;
}

IplImage *CUtil::GS_createImage( CvSize size, int depth, int nChannels )
{
	IplImage *dst_image = cvCreateImage( size, depth, nChannels );
	cvSetZero( dst_image );

	return dst_image;
}


// ������ ũ�� ��������, ������ ���̰� 4�� ����� �°� ���/Ȯ��
IplImage *CUtil::GS_resizeForBitmap( int resize_height, int resize_width, IplImage *image )
{
	// (����!) BITMAP�� Ư�� : ������ ���̰� 4�� ����� �ƴϸ� ��׷���
	int height = image->height;
	int width = image->width - (image->width%4);

	int sHeight;
	int sWidth;

	if( height > resize_height )
	{
		sHeight = resize_height;
		width = (int)(width*(resize_height/(double)height));
		sWidth = width - (width%4);
	}
	else if( width > resize_width )
	{
		sHeight = height;
		sWidth = resize_width - (resize_width%4);		
	}
	else
	{
		sHeight = height;
		sWidth = width;
	}

	// sHeight x sWidth ũ���� ���� ����
	IplImage *resize_image = cvCreateImage( cvSize( sWidth, sHeight ), 
											IPL_DEPTH_8U,
											image->nChannels);

	// sHeight x sWidth ũ��� Ȯ��/��� �Ѵ�.
	cvResize( image, resize_image, CV_INTER_CUBIC );

	return resize_image;
}

// IplImage�� HBITMAP���� ��ȯ
// ��ó : http://www.opencv.org/mailarch/2005-11/msg00070.html 
HBITMAP CUtil::GS_IplImage2Bitmap( IplImage *image )
{
	HDC hDC = ::CreateCompatibleDC(0);
	BYTE tmp[ sizeof(BITMAPINFO)+255*4 ];
	BITMAPINFO *bmi = (BITMAPINFO *)tmp;
	HBITMAP hBmp;

	int height = image->height;
	int width = image->width;
	int widthStep = width + (width % 4);
	int nChannels = image->nChannels;
	int bpp = 8*nChannels;

	// ���� ����Ÿ�� ������ ���� ũ��(��, ������ ���̰� 4�� ����� �Ǿ�� ��)
	int bmpDataSize = height*widthStep*nChannels;

	memset( bmi, 0, sizeof(BITMAPINFO) );
	bmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi->bmiHeader.biHeight = height; // ������ ����
	bmi->bmiHeader.biWidth = width; // ������ �ʺ�
	bmi->bmiHeader.biPlanes = 1; // ��Ʈ �÷��� �� (�׻� 1��)
	bmi->bmiHeader.biBitCount = bpp; // �� ȭ�Ҵ� ��Ʈ ����
	bmi->bmiHeader.biCompression = BI_RGB; // BI_RGB : �������� ����
	bmi->bmiHeader.biSizeImage = bmpDataSize; // ������ ũ��
	bmi->bmiHeader.biClrUsed = 0;

	if( bpp == 8 )
	{
		for(int i=0; i<256; i++)
		{
			bmi->bmiColors[i].rgbBlue = i;
			bmi->bmiColors[i].rgbGreen= i;
			bmi->bmiColors[i].rgbRed= i;
		}

		bmi->bmiColors[i].rgbReserved = 0; 
	}
	
	// DIB ������ ����� bmi�� �����Ѵ�.
	hBmp = ::CreateDIBSection( hDC, bmi, DIB_RGB_COLORS, NULL, 0, 0 );
	::DeleteDC(hDC);

	// hBmp�� ���� �����͸� ���� 
	::SetBitmapBits(hBmp, image->imageSize, image->imageData );

	return hBmp;
}

void CUtil::GS_ViewIplImage( char *title, IplImage *image )
{
	cvNamedWindow( title, CV_WINDOW_AUTOSIZE );
	cvShowImage( title, image );
	cvWaitKey(0);
	cvDestroyWindow( title );
}

void CUtil::GS_errMsg( char *msg )
{
	CString str;
	str.Format("%s", msg);
	AfxMessageBox(str, MB_OK|MB_ICONSTOP|MB_SYSTEMMODAL);
}

int CUtil::GS_clamping( int var )
{
	int retVal = -1;

	// saturation ��� ����
	if( var > 255 ) retVal = 255;
	else if( var < 0 ) retVal = 0;
	else retVal = var;

	return retVal;
}

int CUtil::GS_clamping( float var )
{
	return GS_clamping( (int)var );
}

int CUtil::GS_clamping( double var )
{
	return GS_clamping( (int)var );
}
