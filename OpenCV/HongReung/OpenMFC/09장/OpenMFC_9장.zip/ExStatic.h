#if !defined(AFX_EXSTATIC_H__142FB76C_110B_44A9_B725_AEAB36988385__INCLUDED_)
#define AFX_EXSTATIC_H__142FB76C_110B_44A9_B725_AEAB36988385__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ExStatic.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CExStatic window

class CExStatic : public CStatic
{
// Construction
public:
	CExStatic();
	void SetBit(HBITMAP bit);
	static COLORREF BrushColor; 
	HBITMAP m_hBitmap;

// Attributes
public:

// Operations
public:

private:
	CBrush* m_pBkBrush;
	CExStatic& operator= (const CExStatic&) {return *this;} 
    CExStatic(const CExStatic&) {} 
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExStatic)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CExStatic();

	// Generated message map functions
protected:
	//{{AFX_MSG(CExStatic)
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXSTATIC_H__142FB76C_110B_44A9_B725_AEAB36988385__INCLUDED_)
