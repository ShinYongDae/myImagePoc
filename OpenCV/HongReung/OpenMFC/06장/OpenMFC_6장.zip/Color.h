// Color.h: interface for the CColor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COLOR_H__51E6F4C5_45B6_440E_8240_FCFF2CFD7CAC__INCLUDED_)
#define AFX_COLOR_H__51E6F4C5_45B6_440E_8240_FCFF2CFD7CAC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CColor  
{
public:
	CColor();
	virtual ~CColor();
	void SplitRGB(IplImage *color_image, /* RGB �÷� ���� */
				  IplImage **red,		 /* ���� ä�� */
				  IplImage **green,		 /* ��� ä�� */
				  IplImage **blue);		 /* �Ķ� ä�� */
};

#endif // !defined(AFX_COLOR_H__51E6F4C5_45B6_440E_8240_FCFF2CFD7CAC__INCLUDED_)
