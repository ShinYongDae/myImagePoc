// Noise.h: interface for the CNoise class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NOISE_H__EB536529_B0A4_4B92_9140_8EAE04C7E3EF__INCLUDED_)
#define AFX_NOISE_H__EB536529_B0A4_4B92_9140_8EAE04C7E3EF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CNoise  
{
public:
	CNoise();
	virtual ~CNoise();

	// Gaussian noise
	IplImage *GS_gaussian_noise( IplImage *src_image, double dev=100.0, double ave=0.0, int length=1000 );

	// Exponential noise
	IplImage *GS_exponential_noise( IplImage *src_image, double dev=100.0, double ave=0.0, int length=1000 );

	// Possion noise
	IplImage *GS_possion_noise( IplImage *src_image, double dev=100.0, double ave=0.0, int length=1000);

	// Uniform noise
	IplImage *GS_uniform_noise( IplImage *src_image, double dev=100.0, double ave=0.0 );

	// Impulse noise
	IplImage *GS_impulse_noise( IplImage *src_image, double dev=100.0, int length=1000 );

	// Salt & pepper noise
	IplImage *GS_salt_pepper_noise( IplImage *src_image, double dev=100.0, int length=1000 );

	// Multi-Gaussian noise
	IplImage *GS_multi_gaussian_noise( IplImage *src_image, double noiseRange=0.3 );

	// Laplacian noise
	IplImage *GS_laplacian_noise( IplImage *src_image, double laplacianCoff=-20 );

	// �ش� ������ �� ���Ƿ� �����Ͽ� �����´�.
	int GS_get_noise( double *prob, int length );


};

#endif // !defined(AFX_NOISE_H__EB536529_B0A4_4B92_9140_8EAE04C7E3EF__INCLUDED_)
