// ImageAnalysis.cpp: implementation of the CImageAnalysis class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "openmfc.h"
#include "ImageAnalysis.h"
#include "Util.h"
#include "Pixel.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CImageAnalysis::CImageAnalysis()
{

}

CImageAnalysis::~CImageAnalysis()
{

}

// Pryamid : Up-sampling
IplImage *CImageAnalysis::GS_pryUp( IplImage *src_image, int filter )
{
	int up_height = src_image->height*2;
	int up_width = src_image->width*2;

	// �ʱ�ȭ
	IplImage *dst_image = cvCreateImage( cvSize( up_height, up_height ), 
										 IPL_DEPTH_8U, 
										 src_image->nChannels );

	// 
	cvPyrUp( src_image, dst_image, filter );

	return dst_image;
}

// Pryamid : Down-sampling
IplImage *CImageAnalysis::GS_pryDown( IplImage *src_image, int filter )
{
	int half_height = src_image->height/2;
	int half_width = src_image->width/2;

	// �ʱ�ȭ
	IplImage *dst_image = cvCreateImage( cvSize( half_width, half_height ), 
										 IPL_DEPTH_8U, 
										 src_image->nChannels );

	// 
	cvPyrDown( src_image, dst_image, filter );

	return dst_image;
}

// Pryamid : Segmentation
IplImage *CImageAnalysis::GS_prySegmentation( IplImage *src_image,                               
											  int level, 
											  double threshold1,
											  double threshold2 )
{
	// �ʱ�ȭ
	IplImage *dst_image = cvCreateImage( cvGetSize( src_image ), 
										 IPL_DEPTH_8U, 
										 src_image->nChannels );

	// 
	CvMemStorage* storage = cvCreateMemStorage( 1000 );
	CvSeq* comp1 = cvCreateSeq(0, sizeof(CvSeq), sizeof(CvPoint), storage);
	CvSeq** comp = &comp1;

	// �������� ũ���� ��.
	cvPyrSegmentation( src_image, dst_image, storage, comp, level, threshold1, threshold2 ); 	

	return dst_image;
}

// Pryamid : Mean Shifting
IplImage *CImageAnalysis::GS_pyrMeanShiftFiltering( IplImage *src_image, double sp, double sr )
{
	// �ʱ�ȭ
	IplImage *dst_image = cvCreateImage( cvGetSize( src_image ), 
										 IPL_DEPTH_8U, 
										 src_image->nChannels );

	// {(x,y): X-sp��x��X+sp && Y-sp��y��Y+sp && ||(R,G,B)-(r,g,b)|| �� sr},
	cvPyrMeanShiftFiltering( src_image, dst_image, sp, sr );

	return dst_image;
}

// Harris corner detector
IplImage *CImageAnalysis::GS_cornerHarris( IplImage *src_image, int block_size, int aperture_size, double k )
{
	// ���� ����� ���ϵ� ������.
	if( src_image->nChannels != 1 ) return NULL;

	// �ʱ�ȭ
	IplImage *dst_image = cvCreateImage( cvGetSize( src_image ), 
										 IPL_DEPTH_8U, 
										 src_image->nChannels );

	IplImage *corner_image_32F = cvCreateImage( cvGetSize( src_image ), 
												IPL_DEPTH_32F, 
												src_image->nChannels );

	/* Harris corner detector:
	   Calculates det(M) - k*(trace(M)^2), where M is 2x2 gradient covariation matrix for each pixel */
	cvCornerHarris( src_image, corner_image_32F, block_size, aperture_size, k );

	// 32F -> 8U
	cvConvertScale( corner_image_32F, dst_image, 255, 1 );

	// �Ҵ��� �޸� ���� 
	cvReleaseImage( &corner_image_32F );

	return dst_image;
}

// Calculates constraint image for corner detection
IplImage *CImageAnalysis::GS_preCornerDetect( IplImage *src_image, int aperture_size )
{
	// ���� ����� ���ϵ� ������.
	if( src_image->nChannels != 1 ) return NULL;

	// �ʱ�ȭ
	IplImage *dst_image = cvCreateImage( cvGetSize( src_image ), 
										 IPL_DEPTH_8U, 
										 src_image->nChannels );

	IplImage *corner_image_32F = cvCreateImage( cvGetSize( src_image ), 
												IPL_DEPTH_32F, 
												src_image->nChannels );

	/* Calculates constraint image for corner detection
	   Dx^2 * Dyy + Dxx * Dy^2 - 2 * Dx * Dy * Dxy.
       Applying threshold to the result gives coordinates of corners */
	cvPreCornerDetect( src_image, corner_image_32F, aperture_size );

	// 32F -> 8U
	cvConvertScale( corner_image_32F, dst_image, 255, 1 );

	// �Ҵ��� �޸� ���� 
	cvReleaseImage( &corner_image_32F );

	return dst_image;
}

// �ܰ��� Ž�� : cvFindContours() + cvDrawContours()
IplImage *CImageAnalysis::GS_findContours( IplImage *src_image )
{
	// ���� ����� ���ϵ� ������.
	if( src_image->nChannels != 1 ) return NULL;

	// �ʱ�ȭ
	IplImage *tmp_image = cvCloneImage( src_image );
	IplImage *dst_image = cvCreateImage( cvGetSize( src_image ), 
										 IPL_DEPTH_8U, 3 );
	cvCvtColor( src_image, dst_image, CV_GRAY2BGR);

	// 
	CvMemStorage* storage = cvCreateMemStorage(0);
	CvSeq* contours=NULL;

	/* Retrieves outer and optionally inner boundaries of white (non-zero) connected
       components in the black (zero) background */
	int contour_num;
	contour_num = cvFindContours( tmp_image, 
								  storage, 
								  &contours, 
								  sizeof(CvContour), 
								  CV_RETR_LIST,
								  CV_CHAIN_APPROX_NONE, 
								  cvPoint(0,0));

	/* Draws contour outlines or filled interiors on the image */
	cvDrawContours( dst_image, 
					contours, 
					CV_RGB(255, 0, 0), 
					CV_RGB(255, 0, 0), 
					1, 1, 8);

	// �Ҵ��� �޸� ����
	cvReleaseImage( &tmp_image );

	return dst_image;
}

// Hu Momoment
CvHuMoments *CImageAnalysis::GS_getHuMoments( IplImage *src_image, double threshold )
{
	// ���� ����� ���ϵ� ������.
	if( src_image->nChannels != 1 ) return NULL;	
	
	// ����ȭ
	CPixel cPixel;
	double max_value = 255.0;
	int type = CV_THRESH_BINARY;
	IplImage *binary_image = cPixel.GS_threshold( src_image, threshold, max_value, type );

	// 
	CvMoments *moments = new CvMoments;
	CvHuMoments *hu_moments = new CvHuMoments;

	// ���Ʈ ��´�. 
	// binary = 0 : ���� 
	// binary = 1 : 0�� ���� 0����, ������ ���� 1�� 
	int binary = 1;
	cvMoments( binary_image, moments, binary );
	cvGetHuMoments( moments, hu_moments );

	cvReleaseImage( &binary_image );
	free( moments );

	return hu_moments;	
}

// ����, �߾�, ����ȭ�� �߾� ���Ʈ ���(�Һ� ���Ʈ ����)
double CImageAnalysis::GS_getAllHuMoments( IplImage *src_image, double threshold, int type, int xorder, int yorder )
{
	// ���� ����� ���ϵ� ������.
	if( src_image->nChannels != 1 ) return NULL;	
	
	// ����ȭ
	CPixel cPixel;
	double max_value = 255.0;
	IplImage *binary_image = cPixel.GS_threshold( src_image, threshold, max_value, CV_THRESH_BINARY );

	// 
	CvMoments *moments = new CvMoments;
	CvHuMoments *hu_moments = new CvHuMoments;

	// ���Ʈ ��´�. 
	// binary == 0 �� ��� ����, �߾�, ����ȭ�� �߾�, �Һ� ���Ʈ ���� �� �ִ�.
	int binary = 0;
	cvMoments( src_image, moments, binary );
	
	int x_order = 0;
	int y_order = 0;

	double var = -1.0;

	// if x_order = 0, y_order = 0 then u00
	// ��, x_order >=0, x_order + y_order <=3 �̾�� �Ѵ�.

	// ���� ���Ʈ
	if( type == 0 )
	{
		var = cvGetSpatialMoment( moments, x_order, y_order);
	}
	// �߾� ���Ʈ
	else if( type == 1 )
	{
		var = cvGetCentralMoment( moments, x_order, y_order );
	}
	// ����ȭ�� �߾� ���Ʈ
	else if( type == 2)
	{
		var = cvGetNormalizedCentralMoment( moments, x_order, y_order );
	}

	// �Һ� ���Ʈ ���
	// cvGetHuMoments( moments, hu_moments );

	// �Ҵ��� �޸� ����
	cvReleaseImage( &binary_image );

	return var;	
}


// �⺻ ���� ��ȯ
// http://www-cv.mech.eng.osaka-u.ac.jp/~hamada/openCV/src/sample4-1.cc
IplImage *CImageAnalysis::GS_basicHoughTransform( IplImage *src_image )
{
	// ���� ����� �÷� ������.
	if( src_image->nChannels != 3 ) return NULL;

	IplImage *tmp_src_image = cvCloneImage( src_image );
	IplImage *dst_image = cvCloneImage( src_image );

	IplImage *gray_image = cvCreateImage( cvGetSize(src_image), IPL_DEPTH_8U, 1 );
	IplImage *edge_image = cvCreateImage( cvGetSize(src_image), IPL_DEPTH_8U, 1 );
	CvMemStorage* storage = cvCreateMemStorage( 0 );

	cvCvtColor( tmp_src_image, gray_image, CV_BGR2GRAY );
	cvCanny( gray_image, edge_image, 50, 200, 3 );
	cvCvtColor( edge_image, tmp_src_image, CV_GRAY2BGR) ;

	//
	CvSeq* lines = cvHoughLines2( edge_image, storage, CV_HOUGH_STANDARD, 1, CV_PI/180, 70, 0, 0 );
	if( !lines ) return NULL;

	for(int i=0; i<lines->total; i++)
	{
		float* line = (float*)cvGetSeqElem( lines, i );
		float rho = line[0];
		float theta = line[1];
		CvPoint pt1, pt2;
		double a = cos(theta), b = sin(theta);

		if ( fabs(a)<0.001 )
		{
			pt1.x = pt2.x = cvRound(rho);
			pt1.y = 0;
			pt2.y = tmp_src_image->height;
		}
		else if( fabs(b) < 0.001 )
		{
			pt1.y = pt2.y = cvRound(rho);
			pt1.x = 0;
			pt2.x = tmp_src_image->width;
		} 
		else
		{
			pt1.x = 0;
			pt1.y = cvRound(rho/b);
			pt2.x = cvRound(rho/a);
			pt2.y = 0;
		}

		cvLine( dst_image, pt1, pt2, CV_RGB(255,0,0), 1, 8 );
	}

	return dst_image;
}

// Ȯ���� ���� ��ȯ
// http://www-cv.mech.eng.osaka-u.ac.jp/~hamada/openCV/src/sample4-2.cc
IplImage *CImageAnalysis::GS_probHoughTransform( IplImage *src_image )
{
	// ���� ����� �÷� ������.
	if( src_image->nChannels != 3 ) return NULL;

	IplImage *tmp_src_image = cvCloneImage( src_image );
	IplImage *dst_image = cvCloneImage( src_image );

	IplImage *gray_image = cvCreateImage( cvGetSize(src_image), IPL_DEPTH_8U, 1 );
	IplImage *edge_image = cvCreateImage( cvGetSize(src_image), IPL_DEPTH_8U, 1 );
	CvMemStorage* storage = cvCreateMemStorage( 0 );

	cvCvtColor( tmp_src_image, gray_image, CV_BGR2GRAY );
	cvCanny( gray_image, edge_image, 50, 200, 3 );
	cvCvtColor( edge_image, tmp_src_image, CV_GRAY2BGR) ;

	CvSeq* lines = cvHoughLines2( edge_image, storage, CV_HOUGH_PROBABILISTIC, 1, CV_PI/180, 30, 5, 5 );
	if( !lines ) return NULL;

	for(int i=0; i<lines->total; i++)
	{
		CvPoint* line = (CvPoint*)cvGetSeqElem( lines, i);
		cvLine( dst_image, line[0], line[1], CV_RGB(255,0,0), 1, 8 );
	}

	return dst_image;
}

// ���ø� ��Ī(template matching)
// http://www-cv.mech.eng.osaka-u.ac.jp/~hamada/openCV/src/sample15.cc
IplImage *CImageAnalysis::GS_templateMatching( IplImage *src_image, IplImage *template_image )
{
	CUtil cUtil;

	// ���� ����� �÷� ������.
	if( src_image->nChannels != 3 
		|| template_image->nChannels !=3 ) 
	{
		cUtil.GS_errMsg( "src_image�� template_image�� ä�� ������ ��ġ���� �ʽ��ϴ�!");
		return NULL;
	}

	IplImage *dst_image = cvCloneImage( src_image );
	IplImage *matching_image = cvCreateImage( cvSize(src_image->width - template_image->width +1, 
													 src_image->height - template_image->height+1),
											  IPL_DEPTH_32F, 1);

	/* Measures similarity between template and overlapped windows in the source image
	   and fills the resultant image with the measurements */
	cvMatchTemplate( src_image, template_image, matching_image, CV_TM_SQDIFF);

	//
	double  min_val, max_val;
	CvPoint min_loc, max_loc;
	cvMinMaxLoc( matching_image, &min_val, &max_val, &min_loc, &max_loc, NULL);

	//
	cvRectangle( dst_image, 
				 min_loc, 
				 cvPoint(min_loc.x+template_image->width,min_loc.y+template_image->height),
				 CV_RGB( 255, 0, 0), 
				 1, 
				 8, 
				 0);
	
	return dst_image; 
}