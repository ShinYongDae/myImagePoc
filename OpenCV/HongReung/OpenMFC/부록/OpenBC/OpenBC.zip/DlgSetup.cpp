// DlgSetup.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "OpenBC.h"
#include "DlgSetup.h"
#include "OpenBCDlg.h"


// CDlgSetup ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgSetup, CDialog)
CDlgSetup::CDlgSetup(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSetup::IDD, pParent)
	, m_nShutter(0)
	, m_nRedAG(0)
	, m_nRedDG(0)
	, m_nGreenAG(0)
	, m_nGreenDG(0)
	, m_nBlueAG(0)
	, m_nBlueDG(0)
	, m_ctlShutter(0)
	, m_ctlRedAG(0)
	, m_ctlRedDG(0)
	, m_ctlGreenAG(0)
	, m_ctlGreenDG(0)
	, m_ctlBlueAG(0)
	, m_ctlBlueDG(0)
	, m_bInterpolation(FALSE)
	, m_bPreview(FALSE)
	, m_bLed(FALSE)
{
}

CDlgSetup::~CDlgSetup()
{
}

void CDlgSetup::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_SHUTTER, m_nShutter);
	DDX_Text(pDX, IDC_EDIT_REDAG, m_nRedAG);
	DDX_Text(pDX, IDC_EDIT_REDDG, m_nRedDG);
	DDX_Text(pDX, IDC_EDIT_GREENAG, m_nGreenAG);
	DDX_Text(pDX, IDC_EDIT_GREENDG, m_nGreenDG);
	DDX_Text(pDX, IDC_EDIT_BLUEAG, m_nBlueAG);
	DDX_Text(pDX, IDC_EDIT_BLUEDG, m_nBlueDG);
	DDV_MinMaxInt(pDX, m_nShutter, 0, 32767);
	DDV_MinMaxInt(pDX, m_nRedAG, 0, 63);
	DDV_MinMaxInt(pDX, m_nRedDG, 0, 120);
	DDV_MinMaxInt(pDX, m_nGreenAG, 0, 63);
	DDV_MinMaxInt(pDX, m_nGreenDG, 0, 120);
	DDV_MinMaxInt(pDX, m_nBlueAG, 0, 63);
	DDV_MinMaxInt(pDX, m_nBlueDG, 0, 120);
	DDX_Slider(pDX, IDC_SLIDER_SHUTTER, m_ctlShutter);
	DDX_Slider(pDX, IDC_SLIDER_REDAG, m_ctlRedAG);
	DDX_Slider(pDX, IDC_SLIDER_REDDG, m_ctlRedDG);
	DDX_Slider(pDX, IDC_SLIDER_GREENAG, m_ctlGreenAG);
	DDX_Slider(pDX, IDC_SLIDER_GREENDG, m_ctlGreenDG);
	DDX_Slider(pDX, IDC_SLIDER_BLUEAG, m_ctlBlueAG);
	DDX_Slider(pDX, IDC_SLIDER_BLUEDG, m_ctlBlueDG);
	DDX_Check(pDX, IDC_CHECK_INTERPOLATION, m_bInterpolation);
	DDX_Check(pDX, IDC_CHECK_PREVIEW, m_bPreview);
	DDX_Check(pDX, IDC_CHECK_LED, m_bLed);
}


BEGIN_MESSAGE_MAP(CDlgSetup, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, OnBnClickedButtonDefault)
//	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_SHUTTER, OnNMCustomdrawSliderShutter)
//ON_NOTIFY(NM_THEMECHANGED, IDC_SLIDER_SHUTTER, OnNMThemeChangedSliderShutter)
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_SHUTTER, OnNMReleasedcaptureSliderShutter)
//ON_WM_CREATE()
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_REDAG, OnNMReleasedcaptureSliderRedag)
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_REDDG, OnNMReleasedcaptureSliderReddg)
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_GREENAG, OnNMReleasedcaptureSliderGreenag)
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_GREENDG, OnNMReleasedcaptureSliderGreendg)
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_BLUEAG, OnNMReleasedcaptureSliderBlueag)
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_BLUEDG, OnNMReleasedcaptureSliderBluedg)
END_MESSAGE_MAP()


// CDlgSetup �޽��� ó�����Դϴ�.

void CDlgSetup::OnBnClickedButtonDefault()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);

	m_nShutter = 0;
	m_nRedAG = 0;
	m_nRedDG = 0;
	m_nGreenAG = 0;
	m_nGreenDG = 0;
	m_nBlueAG = 0;
	m_nBlueDG = 0;
	m_ctlShutter = 0;
	m_ctlRedAG = 0;
	m_ctlRedDG = 0;
	m_ctlGreenAG = 0;
	m_ctlGreenDG = 0;
	m_ctlBlueAG = 0;
	m_ctlBlueDG = 0;

	UpdateData(FALSE);
}


BOOL CDlgSetup::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	//�����̵�� Range Setting
	CSliderCtrl* ctl;
	ctl = (CSliderCtrl *)this->GetDlgItem(IDC_SLIDER_SHUTTER);
	ctl->SetRange(0, 32767);

	ctl = (CSliderCtrl *)this->GetDlgItem(IDC_SLIDER_REDAG);
	ctl->SetRange(0, 63);

	ctl = (CSliderCtrl *)this->GetDlgItem(IDC_SLIDER_REDDG);
	ctl->SetRange(0, 120);

	ctl = (CSliderCtrl *)this->GetDlgItem(IDC_SLIDER_GREENAG);
	ctl->SetRange(0, 63);

	ctl = (CSliderCtrl *)this->GetDlgItem(IDC_SLIDER_GREENDG);
	ctl->SetRange(0, 120);

	ctl = (CSliderCtrl *)this->GetDlgItem(IDC_SLIDER_BLUEAG);
	ctl->SetRange(0, 63);

	ctl = (CSliderCtrl *)this->GetDlgItem(IDC_SLIDER_BLUEDG);
	ctl->SetRange(0, 120);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CDlgSetup::OnNMReleasedcaptureSliderShutter(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);
	m_nShutter = m_ctlShutter;
	UpdateData(FALSE);
	*pResult = 0;
}

void CDlgSetup::OnNMReleasedcaptureSliderRedag(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);
	m_nRedAG = m_ctlRedAG;
	UpdateData(FALSE);
	*pResult = 0;
}

void CDlgSetup::OnNMReleasedcaptureSliderReddg(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);
	m_nRedDG = m_ctlRedDG;
	UpdateData(FALSE);
	*pResult = 0;
}

void CDlgSetup::OnNMReleasedcaptureSliderGreenag(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);
	m_nGreenAG = m_ctlGreenAG;
	UpdateData(FALSE);
	*pResult = 0;
}

void CDlgSetup::OnNMReleasedcaptureSliderGreendg(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);
	m_nGreenDG = m_ctlGreenDG;
	UpdateData(FALSE);
	*pResult = 0;
}

void CDlgSetup::OnNMReleasedcaptureSliderBlueag(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);
	m_nBlueAG = m_ctlBlueAG;
	UpdateData(FALSE);
	*pResult = 0;
}

void CDlgSetup::OnNMReleasedcaptureSliderBluedg(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);
	m_nBlueDG = m_ctlBlueDG;
	UpdateData(FALSE);
	*pResult = 0;
}

BOOL CDlgSetup::Create(CWnd* pParentWnd)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	return CDialog::Create(IDD, pParentWnd);
}

void CDlgSetup::SetINI(INIValue val)
{
	m_ctlShutter = val.iShutter_pos;
	m_ctlBlueAG = val.iBGain_pos;
	m_ctlBlueDG = val.iDBGain_pos;
	m_ctlGreenAG = val.iGGain_pos;
	m_ctlGreenDG = val.iDGGain_pos;
	m_ctlRedAG = val.iRGain_pos;
	m_ctlRedDG = val.iDRGain_pos;

	m_nBlueAG = val.iBGain_pos;
	m_nBlueDG = val.iDBGain_pos;
	m_nGreenAG = val.iGGain_pos;
	m_nGreenDG = val.iDGGain_pos;
	m_nRedAG = val.iRGain_pos;
	m_nRedDG = val.iDRGain_pos;
	m_nShutter = val.iShutter_pos;

	UpdateData(false);
}
void CDlgSetup::OnOK()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	UpdateData(true);

	INIValue val;
	
	val.iBGain_pos = m_nBlueAG;
	val.iDBGain_pos = m_nBlueDG;
	val.iGGain_pos = m_nGreenAG;
	val.iDGGain_pos = m_nGreenDG;
	val.iRGain_pos = m_nRedAG;
	val.iDRGain_pos = m_nRedDG;
	val.iShutter_pos = m_nShutter;
	
	COpenBCDlg *dlg = (COpenBCDlg *)this->GetParent();
	dlg->m_wndVideo.SetINIValue(val);

	CDialog::OnOK();
}
