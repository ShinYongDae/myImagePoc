// WndVideo.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "OpenBC.h"
#include "WndVideo.h"
#include "OpenBCDlg.h"
#include <direct.h>
#include <windows.h>
#include <io.h>


extern HWND gBCDlg1;

// Structure of sensor's information.
typedef struct _SENSOR_TYPE {
	int nIndex;	 
	LPSTR szSensorString;	//list string- user view.
	int SensorID;			// Sensor ID: defined at "HW_Init.h"
	int SlaveAddr;			// Device ID
	int nDisplayX;			// Image size x
	int nDisplayY;			// Image size y
	int iDataFormat;		//DataFormat : 0 - YUV, 1 - 8bit bayer, 2 - 10bit bayer
	int OutMode;			//OutMode  : if YUV : YCbYCr- 1, YCrYCb - 2, CbYCrY - 3, CrYCbY - 4
							//		     if Bayer: BGGR - 1, RGGB   - 2, GBRG   - 3, GRBG   - 4
	int IICMode;			//IIC Read/Write initial mode : if 8bit-1, 16bit-2 
	
} SENSOR_TYPE,SENSOR_TYPE2;

SENSOR_TYPE SensorType[] =
{
 
	0, "MT9T001[QXGA]",		MT9T001,  0x5d,	2048,	1536, RAW,GRBG,		BIT16,	//Micron 3M bayer
 	1, "MT9T001[UXGA]",		MT9T001,  0x5d,	1600,	1200, RAW,GRBG,		BIT16,	//Micron 2M bayer
 	2, "MT9T001[SXGA]",		MT9T001,  0x5d,	1280,	1024, RAW,GRBG,		BIT16,	//Micron 1.3M bayer
 	3, "MT9T001[XGA]",		MT9T001,  0x5d,	1024,	768,  RAW,GRBG,		BIT16,	//Micron 0.8M bayer
 	4, "MT9T001[VGA]",		MT9T001,  0x5d,	640,	480,  RAW,GRBG,		BIT16,	//Micron 0.3M bayer
 	
};

SENSOR_TYPE SensorType2[]=
{
 	0, "HV7131R",			HV7131R, 0x11,	640,	480,  1, RGGB,		BIT8,	//MagnaChip VGA
};

#define NUM_SENSOR_TYPE (sizeof(SensorType) / sizeof(SENSOR_TYPE))

// CWndVideo
IMPLEMENT_DYNAMIC(CWndVideo, CWnd)
CWndVideo::CWndVideo()
{
	m_nDrvIndex = 0;
	m_nCurrentSensorType = 4;
	m_nFitmode = 0;
	m_nImageWidth = 320;
	m_nImageHeight = 240;
	m_bPlayMode = false;
	m_b1stBuffer = false;
	m_nBufferStatus = 0;
	m_nCurrentDevice = -1;
	memset(m_strRootdir, 0, 260);
	m_Image = NULL;
	m_ImageIntp = NULL;
	m_ImageChange = NULL;
	m_ImageChange2 = NULL;
	m_ImageChange3 = NULL;
	m_ImageChangeCvLa = NULL;
	m_nImgProcess = 0;
	m_nIdentity = 0;
	m_nCircle = 0;

	m_pYCbCrBuffer = new BYTE[2048*1536*2]; //�迭�� �ʹ� Ŀ�� StackOverflow
	m_pYCbCrBuffer1 = new BYTE[2048*1536*2];
	m_pBmpBuffer = new BYTE[2048*1536*3];
//	memset(m_pYCbCrBuffer, 0, 2048*1536*2);
//	memset(m_pYCbCrBuffer1, 0, 2048*1536*2);
}

CWndVideo::~CWndVideo()
{
	delete m_pYCbCrBuffer;
	delete m_pYCbCrBuffer1;
	delete m_pBmpBuffer;
	
	if(!m_bPlayMode){
		cvReleaseImage(&m_Image);
		cvReleaseImage(&m_ImageIntp);
		cvReleaseImage(&m_ImageChange);
		cvReleaseImage(&m_ImageChange2);
		cvReleaseImage(&m_ImageChange3);
	}
}

BEGIN_MESSAGE_MAP(CWndVideo, CWnd)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CWndVideo �޽��� ó�����Դϴ�.
void CWndVideo::SetImageProcess(DWORD op)
{
	m_nImgProcess = op;
}

void CWndVideo::StartPlay()
{

	MyDelay(1000);
	
	m_bPlayMode = true;

	if(m_bPlayMode)
	{
		if( m_nCurrentDevice ==MT9T001 ){
			m_nImageWidth = SensorType[m_nCurrentSensorType].nDisplayX;
			m_nImageHeight = SensorType[m_nCurrentSensorType].nDisplayY;
			SensorRegInit(SensorType[m_nCurrentSensorType].SensorID, m_nImageWidth);
		}
		else{
			m_nImageWidth = SensorType2[m_nCurrentSensorType].nDisplayX;
			m_nImageHeight = SensorType2[m_nCurrentSensorType].nDisplayY;
			SensorRegInit(SensorType2[m_nCurrentSensorType].SensorID, m_nImageWidth);
		}
		
		Read_User_Control_Set();

		cvReleaseImage(&m_Image);
		cvReleaseImage(&m_ImageIntp);
		cvReleaseImage(&m_ImageChange);
		cvReleaseImage(&m_ImageChange2);
		cvReleaseImage(&m_ImageChange3);

		m_Image = cvCreateImage(cvSize(m_nImageWidth, m_nImageHeight),IPL_DEPTH_8U,1);
		m_ImageIntp = cvCreateImage( cvGetSize(m_Image), IPL_DEPTH_8U, 3);
		m_ImageChange = cvCreateImage( cvGetSize(m_Image), IPL_DEPTH_8U, 1);
		m_ImageChange2 = cvCreateImage( cvGetSize(m_Image), IPL_DEPTH_8U, 1);
		m_ImageChange3 = cvCreateImage( cvGetSize(m_Image), IPL_DEPTH_8U, 1);
		
		m_ImageChangeCvLa = cvCreateImage ( cvGetSize(m_Image),IPL_DEPTH_32F, 1 );
		
		//SetTimer(2, 200, NULL);
		hThreadData = AfxBeginThread(RunThread, this, THREAD_PRIORITY_TIME_CRITICAL);
		//SetThreadPriority(hThreadData, THREAD_PRIORITY_TIME_CRITICAL);
		hThreadDisplay = AfxBeginThread(RunThread2, this, THREAD_PRIORITY_TIME_CRITICAL);
		//SetThreadPriority(hThreadDisplay, THREAD_PRIORITY_TIME_CRITICAL);
	}
	
}

void CWndVideo::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CWnd::OnPaint()��(��) ȣ������ ���ʽÿ�.

	//
		//m_CvvImage.Show(dc.GetSafeHdc(), 0, 0, 300, 300);
	//}
	if(m_bPlayMode){

	}
}

void CWndVideo::MyDelay(DWORD millisec)
{
    DWORD tmp;
	
    tmp = GetTickCount();
    while (GetTickCount() < tmp + millisec);
}

int CWndVideo::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	int i;
	
	COpenBCDlg *dlg = (COpenBCDlg *)this->GetParent();

	// TODO:  ���⿡ Ư��ȭ�� �ۼ� �ڵ带 �߰��մϴ�.
	
	int			nDrvInform[6];	//����̹� ����
	int			nDrvNum;
	char		buf_mode[4][5]={0};
	char		filedir[MAX_PATH]={0};
	LPSTR		lpAppName = "HVS_VISIONCAM";

	for (i=0; i<6; i++) nDrvInform[i] = 0; //init
 	
	nDrvNum = HW_InitCam(&nDrvInform[0]);
	m_nDrvNum = nDrvNum;
	COpenBCDlg * pDlg = (COpenBCDlg *)this->GetParent();
	pDlg->m_nCameraAmount = nDrvNum;

	MyDelay(3000);
	_getcwd(m_strRootdir, MAX_PATH);

	if(nDrvNum == 0)
	{
		AfxMessageBox("ī�޶� ����Ǿ� ���� �ʽ��ϴ�.");
		//���α׷� ����
		dlg->MyClose();

	}

	m_nCurrentDevice = SensorRecognition(m_nDrvIndex);

	if(m_nCurrentDevice == -1){
		AfxMessageBox("������ ����Ǿ� ���� �ʽ��ϴ�.");
		//���α׷� ����
		dlg->MyClose();
	}
	else if(m_nCurrentDevice == MT9T001)
	{
		for (i=0; i<NUM_SENSOR_TYPE; i++) {
			wsprintf(buf_mode[m_nDrvIndex],"%d",m_nCurrentSensorType); //limit
			wsprintf(filedir, "VISION%d_Select", m_nDrvIndex);
			INIWriteStringVision(lpAppName,filedir,buf_mode[m_nDrvIndex]);
 			if(m_nCurrentDevice == MT9T001 ){		
				m_nImageWidth =SensorType[m_nCurrentSensorType].nDisplayX;
				m_nImageHeight =SensorType[m_nCurrentSensorType].nDisplayY;
			}
			else
			{ 
				m_nImageWidth =SensorType2[m_nCurrentSensorType].nDisplayX;
				m_nImageHeight =SensorType2[m_nCurrentSensorType].nDisplayY;
			}
		}
	}
	
	if(!Trig_Read(m_nDrvIndex)){
		AfxMessageBox("Ʈ���Ÿ� äũ�� �ּ���.");
		//���α׷� ����
		dlg->MyClose();
	}

	LED_OnOff(1, m_nDrvIndex);

	return 0;
}


/**************************************************************************************************
* void	SensorRegInit(int SensorID, int Xsize)
* Description:
*      I2C setting of selected sensor
* Inputs:
*      SensorID     :	SensorID (it defined above part)
*	   Xsize		:	Selected size 
**************************************************************************************************/
void CWndVideo::SensorRegInit(int SensorID, int Xsize)
{
	char filedir[MAX_PATH]={0};
	if(HV7131R == SensorID){

		Set_Sensor_Addr (0x11, m_nDrvIndex); //Hynix 0x11
		MyDelay(10);
		VCLK_POLALITY_HighLow(0,m_nDrvIndex);
		
 		IIC_Write(0x01, 0x08, m_nDrvIndex);   //X-flip.
		IIC_Write(0x11, 0x03, m_nDrvIndex);	//Row start address Lower.
		IIC_Write(0x13, 0x03, m_nDrvIndex);	//Column start address Lower.
		IIC_Write(0x14, 0x01, m_nDrvIndex);	//Window Height Upper.
		IIC_Write(0x15, 0xE0, m_nDrvIndex);	//Window Height Lower.
		IIC_Write(0x16, 0x02, m_nDrvIndex);	//Window Width	Upper
		IIC_Write(0x17, 0x80, m_nDrvIndex);	//Window Width	Lower.
		IIC_Write(0x22, 0x00, m_nDrvIndex);
		IIC_Write(0x23, 0x20, m_nDrvIndex);
		
		IIC_Write(0x25, 0x01, m_nDrvIndex);
		IIC_Write(0x26, 0x5b, m_nDrvIndex);
		IIC_Write(0x27, 0x9a, m_nDrvIndex);
		IIC_Write(0x30, 0x20, m_nDrvIndex);	//Pre-amp Gain.
 		IIC_Write(0x31, 0x24, m_nDrvIndex);	//Red Color Gain.	-soyeon.
		IIC_Write(0x32, 0x12, m_nDrvIndex);	//Green Color Gain.	-soyeon.
		IIC_Write(0x33, 0x12, m_nDrvIndex);	//Blue Color Gain.	-soyeon.
	}
	if(MT9T001 == SensorID)  
	{
	 
		CLK24M_OUT (m_nDrvIndex);
 		Set_Sensor_Addr(0x5d, m_nDrvIndex);
		MyDelay(10);
		VCLK_POLALITY_HighLow(0,m_nDrvIndex);

		if(Xsize == 2048){
			IIC_Write16(0x01,0x0014, m_nDrvIndex); //center offset -> Y��ǥ
			IIC_Write16(0x02,0x0020, m_nDrvIndex); //center offset -> X��ǥ

			IIC_Write16(0x03,0x05ff, m_nDrvIndex);
			IIC_Write16(0x04,0x07ff, m_nDrvIndex);

			IIC_Write16(0x05,0x0015, m_nDrvIndex);
		//	IIC_Write16(0x06,0x0030, m_nDrvIndex);
		//	IIC_Write16(0x09,0x047f, m_nDrvIndex);

		}

		if(Xsize == 1600) // UXGA windowing
		{
 			//SY
			IIC_Write16(0x01,0x00C0, m_nDrvIndex); //center offset -> Y��ǥ
			IIC_Write16(0x02,0x0100, m_nDrvIndex); //center offset -> X��ǥ
			
			IIC_Write16(0x03,0x04af, m_nDrvIndex); //1199
			IIC_Write16(0x04,0x063f, m_nDrvIndex); //1599

			IIC_Write16(0x05,0x0015, m_nDrvIndex);//
			IIC_Write16(0x06,0x0030, m_nDrvIndex);
			IIC_Write16(0x09,0x04bf, m_nDrvIndex);
		}
		else if(Xsize == 1280) // SXGA windowing
		{
 
			IIC_Write16(0x01,0x0118, m_nDrvIndex);//center offset -> Y��ǥ
			IIC_Write16(0x02,0x01a0, m_nDrvIndex); //center offset -> X��ǥ
			
			IIC_Write16(0x03,0x03ff, m_nDrvIndex); //1279
			IIC_Write16(0x04,0x04ff, m_nDrvIndex); //1023

			IIC_Write16(0x05,0x0015, m_nDrvIndex); //
			IIC_Write16(0x06,0x0030, m_nDrvIndex);
			IIC_Write16(0x09,0x040f, m_nDrvIndex);

 
		}

		else if(Xsize == 1024) // XGA windowing
		{
 			IIC_Write16(0x01,0x0198, m_nDrvIndex); //center offset -> Y��ǥ
			IIC_Write16(0x02,0x0220, m_nDrvIndex); //center offset -> X��ǥ
			
			IIC_Write16(0x03,0x02ff, m_nDrvIndex); //767
			IIC_Write16(0x04,0x03ff, m_nDrvIndex); //1023

			IIC_Write16(0x05,0x0015, m_nDrvIndex);//
			IIC_Write16(0x06,0x0030, m_nDrvIndex);
			IIC_Write16(0x09,0x030f, m_nDrvIndex);
		}

		else if(Xsize == 800) // SVGA windowing
		{
			IIC_Write16(0x01,0x01a4, m_nDrvIndex); //center offset -> Y��ǥ
			IIC_Write16(0x02,0x0114, m_nDrvIndex); //center offset -> X��ǥ

			IIC_Write16(0x03,0x0257, m_nDrvIndex); //599
			IIC_Write16(0x04,0x031f, m_nDrvIndex); //799

			IIC_Write16(0x05,0x0015, m_nDrvIndex); //
			IIC_Write16(0x06,0x0030, m_nDrvIndex);
			IIC_Write16(0x09,0x0267, m_nDrvIndex);
		}
		else if(Xsize == 640) // VGA windowing
		{
 
			IIC_Write16(0x01,0x0228, m_nDrvIndex); //center offset -> Y��ǥ
			IIC_Write16(0x02,0x02e0, m_nDrvIndex); //center offset -> X��ǥ

			IIC_Write16(0x03,0x01df, m_nDrvIndex); //479
			IIC_Write16(0x04,0x027f, m_nDrvIndex); //639

			IIC_Write16(0x05,0x0015, m_nDrvIndex); //
			IIC_Write16(0x06,0x0030, m_nDrvIndex);
			IIC_Write16(0x09,0x01ef, m_nDrvIndex);
		}

		IIC_Write16(0x05,0x0050, m_nDrvIndex);
 		IIC_Write16(0x06,0x0070, m_nDrvIndex);
	 	IIC_Write16(0x09,0x047f, m_nDrvIndex);
		IIC_Write16(0x2b,0x0008, m_nDrvIndex); //
		IIC_Write16(0x2c,0x0008, m_nDrvIndex);
		IIC_Write16(0x2d,0x0008, m_nDrvIndex);
		IIC_Write16(0x2e,0x0008, m_nDrvIndex);
  
	} 
	wsprintf(filedir, "%s\\HVS_VISION.ini", m_strRootdir);
	
	if(!ParseRegisterFileBoard(filedir))
	{
		AfxMessageBox("Reg File Fail!");
		//ListOut(ghwndDlg,"reg file fail");
	}
 
}


/**************************************************************************************************
* BOOL			ParseRegisterFileBoard(char *filename)
* Description:
*		Write to ini file(file format is "*.set") with I2C commnand
* Inputs:
*      filename    :   set file's name.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/

BOOL	CWndVideo::ParseRegisterFileBoard(char *filename)
{
	FILE		*fp;
	DWORD		wRegAddr, wRegData;
	char		linebufIn[500];//[MAXSTR];
	char		tmp_cmd[50]={0};
	char		tmp_data[50]={0};
	int			tmp_idata=0;
	BOOL		bwrite_start=FALSE;
	int			SleepTime= 20;
	char		filedir[40]={0};
	
	if(m_nCurrentDevice == MT9T001)
		wsprintf(filedir, "[HVS_VISION%d_MT9T001]", m_nDrvIndex);
	else 
		wsprintf(filedir, "[HVS_VISION%d_HV7131R]", m_nDrvIndex);
		

	if ((fp = fopen(filename,"r")) == NULL) {
		return FALSE;
	}
	//add  "     "
	memset(linebufIn, 0, 500); //MAXSTR);
	while (NULL != fgets(linebufIn, 500, fp)) //MAXSTR
	{
		sscanf(linebufIn,"%s",tmp_cmd);
		
		if(0 == strcmp( filedir , tmp_cmd)) //mode
		{
			if(!bwrite_start) bwrite_start = TRUE;
		}
		else if(0 == strcmp("[END]", tmp_cmd) && bwrite_start == TRUE)
		{
			bwrite_start = FALSE;
			break;
		}
		if(TRUE == bwrite_start)
		{	
			if (linebufIn[0] == '0' && (linebufIn[1] == 'x' || linebufIn[1] == 'X')) {
				sscanf(linebufIn,"%x%x",&wRegAddr,&wRegData);
				if(m_nCurrentDevice ==MT9T001 )
					IIC_Write_Proc(SensorType[m_nCurrentSensorType].IICMode, wRegAddr, wRegData);
				else
					IIC_Write_Proc(SensorType2[m_nCurrentSensorType].IICMode, wRegAddr, wRegData);
				MyDelay(3);
			}
 		 
 			memset(linebufIn, 0, strlen(linebufIn));
		}//end bWrite
	}
	fclose(fp);
	return TRUE;/**/
	
}

/**************************************************************************************************
* void	Read_User_Control_Set(void)
* Description:
*     Read setting value about ISP control
**************************************************************************************************/

void	CWndVideo::Read_User_Control_Set(void)
{
	LPSTR	lpAppName;
	char	filedir[MAX_PATH]={0};
	char	buf_mode[10][10]={0};
  	DWORD	wRegAddr, wRegData;
 
	if(m_nCurrentDevice == MT9T001){
		wsprintf(filedir, "HVS_ISP%d_MT9T001", m_nDrvIndex);
 		lpAppName = filedir;
 
 		INIReadStringVision(lpAppName,"Shutter","1200",buf_mode[0],10);
 		INIReadStringVision(lpAppName,"A_RGAIN","8",buf_mode[1],10);
 		INIReadStringVision(lpAppName,"D_RGAIN","0",buf_mode[2],10);
 		INIReadStringVision(lpAppName,"A_GGAIN","7",buf_mode[3],10);
 		INIReadStringVision(lpAppName,"D_GGAIN","0",buf_mode[4],10);
 		INIReadStringVision(lpAppName,"A_BGAIN","8",buf_mode[5],10);
 		INIReadStringVision(lpAppName,"D_BGAIN","0",buf_mode[6],10);

		sscanf(buf_mode[0], "%d", &wRegAddr);	
 		IIC_Write16(ADD_SHUTTER,wRegAddr,m_nDrvIndex);
		MyDelay(1);
		sscanf(buf_mode[1], "%d", &wRegAddr);
 		sscanf(buf_mode[2], "%d", &wRegData);
 		IIC_Write16(ADD_RGAIN,((wRegData<<8)+wRegAddr),m_nDrvIndex);
		MyDelay(1);
		sscanf(buf_mode[3], "%d", &wRegAddr);	
		sscanf(buf_mode[4], "%d", &wRegData);	
		IIC_Write16(ADD_GGAIN1,((wRegData <<8)+(wRegAddr)),m_nDrvIndex);
		IIC_Write16(ADD_GGAIN2,((wRegData <<8)+(wRegAddr)),m_nDrvIndex);
		
		MyDelay(1);
		sscanf(buf_mode[5], "%d", &wRegAddr);	
		sscanf(buf_mode[6], "%d", &wRegData);
 		IIC_Write16(ADD_BGAIN,((wRegData <<8)+(wRegAddr)),m_nDrvIndex);
 
	}
	else {

		wsprintf(filedir, "HVS_ISP%d_HV7131R", m_nDrvIndex);
		lpAppName = filedir;
		
 		INIReadStringVision(lpAppName,"INT_TIME_HIGH","1",buf_mode[0],10);
		INIReadStringVision(lpAppName,"INT_TIME_MIDDLE","5",buf_mode[1],10);
		INIReadStringVision(lpAppName,"INT_TIME_LOW","20",buf_mode[2],10);
		INIReadStringVision(lpAppName,"R_GAIN","0",buf_mode[3],10);
		INIReadStringVision(lpAppName,"G_GAIN","0",buf_mode[4],10);
		INIReadStringVision(lpAppName,"B_GAIN","0",buf_mode[5],10);

		sscanf(buf_mode[0], "%x", &wRegAddr);	
		IIC_Write(INT_TIME_HIGH,wRegAddr,m_nDrvIndex);
		sscanf(buf_mode[1], "%x", &wRegAddr);	
		IIC_Write(INT_TIME_MIDDLE,wRegAddr,m_nDrvIndex);
		sscanf(buf_mode[2], "%x", &wRegAddr);	
		IIC_Write(INT_TIME_LOW,wRegAddr,m_nDrvIndex);

		sscanf(buf_mode[3], "%x", &wRegAddr);	
		IIC_Write(DATA_R_COLORGAIN,wRegAddr,m_nDrvIndex);
 		sscanf(buf_mode[4], "%x", &wRegAddr);	
		IIC_Write(DATA_G_COLORGAIN,wRegAddr,m_nDrvIndex);
 		sscanf(buf_mode[5], "%x", &wRegAddr);	
		IIC_Write(DATA_B_COLORGAIN,wRegAddr,m_nDrvIndex);
		
	}
 
}
 

/**************************************************************************************************
* BOOL			IIC_Write_Proc(int mode, WORD wRegAddr, WORD wRegData)
* Description:
*      write byte data from I2C device
* Inputs:
*      mode		   :  I2C mode : 8it / 16bit
*      wRegAddr    :   Address
*	   wRegData    :   Data to be write
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL	CWndVideo::IIC_Write_Proc(int mode, WORD wRegAddr, WORD wRegData)
{
	BOOL flagTF;
	if (BIT8 == mode) {
		flagTF=	IIC_Write(wRegAddr, wRegData, m_nDrvIndex);
	}
	else if (BIT16 == mode) {
		flagTF=IIC_Write16(wRegAddr, wRegData, m_nDrvIndex);
	}
	
	return flagTF;
}

/**************************************************************************************************
* void	SensorRecognition(int Id_check)
* Description:
*      Sensor recognition with Sensor origianl ID
* Inputs:
*      Id_check     :	Vision's number.
**************************************************************************************************/
int  CWndVideo::SensorRecognition (int Id_check)
{
	WORD	wRegData = 0;
	LPSTR	lpAppName = "HVS_VISIONCAM";
	char	filedir[MAX_PATH]={0};
	char	buf_mode[4][5]={0};
  
	MyDelay(20);
	CLK24M_OUT(m_nDrvIndex);
  	Set_Sensor_Addr(0x5d, Id_check);
	MyDelay(20);
 
	if(IIC_Write16(0xf0, 0x0000, Id_check)){
		wRegData = (WORD)IIC_Read16(0x00, Id_check);
 		if(wRegData== 0x1621){
			wsprintf(filedir, "VISION%d_Model", Id_check);
			INIWriteStringVision(lpAppName,filedir,"MT9T001");
			wsprintf(filedir, "VISION%d_Select",Id_check);
			INIReadStringVision(lpAppName,filedir,"0",buf_mode[Id_check],5);
			m_nCurrentSensorType=	atoi(buf_mode[Id_check]);
			//m_nCurrentSensorType = 0;

			wsprintf(filedir, "VISION%d_Fit",Id_check);
			INIReadStringVision(lpAppName,filedir,"0",buf_mode[Id_check],5);
			m_nFitmode=	atoi(buf_mode[Id_check]);

			//wsprintf(buf_mode[m_nDrvIndex],"%d",m_nCurrentSensorType); //limit
			//wsprintf(filedir, "VISION%d_Select", m_nDrvIndex);
			//INIWriteStringVision(lpAppName,filedir,buf_mode[m_nDrvIndex]);
			//ListOut(ghwndDlg,"%d",Fitmode);
			
 			return MT9T001;
		}
 		else {
 			Set_Sensor_Addr(0x11, Id_check);
			MyDelay(20);
			wRegData = (WORD)IIC_Read(0x00, Id_check);
 			if(wRegData== 0x02){
				wsprintf(filedir, "VISION%d_Model", Id_check);
				INIWriteStringVision(lpAppName,filedir,"HV7131R");
  				m_nCurrentSensorType=	4;
				
				return HV7131R;
			}
 			else {
				return -1;
			}
		}
	}
	else {
 		Set_Sensor_Addr(0x11, Id_check);
		MyDelay(20);
		wRegData = (WORD)IIC_Read(0x00, Id_check);
		
		if(wRegData == 0x02){
			wsprintf(filedir, "VISION%d_Model", Id_check);
			INIWriteStringVision(lpAppName,filedir,"HV7131R");
 			m_nCurrentSensorType=	4;
 			
 			return HV7131R;
		}
 		else {
 			return -1;
		}
	}
}

//Write string
/**************************************************************************************************
* BOOL	INIWriteStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR str)
* Description:
*      Write to ini file 
* Inputs:
*      lpAppName     :	Section's name 
*	   lpKey		 :  key
*	   str			 :  have to write string.	
**************************************************************************************************/
BOOL CWndVideo::INIWriteStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR str)
{
	char filedir[MAX_PATH]={0};
  	wsprintf(filedir, "%s\\HVS_VISION.ini", m_strRootdir);
 	BOOL bresult = WritePrivateProfileString(lpAppName, lpKey, str, filedir);
	return bresult;
 }

//Read string
/**************************************************************************************************
* BOOL	INIReadStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR lpDefault, LPTSTR lpReturn, DWORD nSize)
* Description:
*      Read to ini file 
* Inputs:
*      lpAppName     :	Section's name 
*	   lpKey		 :  key
*      lpDefault	 :  default value
*	   lpReturn		 :  have to read string.
*	   nSize		 :  size of buffer	
**************************************************************************************************/
BOOL CWndVideo::INIReadStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR lpDefault, LPTSTR lpReturn, DWORD nSize)
{
	char filedir[MAX_PATH]={0};
  	wsprintf(filedir, "%s\\HVS_VISION.ini", m_strRootdir);
 	BOOL bresult = GetPrivateProfileString(lpAppName, lpKey, lpDefault, lpReturn, nSize, filedir);
	return bresult;
}

void CWndVideo::OnTimer(UINT nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(nIDEvent == 2)
	{
		
	}

	CWnd::OnTimer(nIDEvent);
}

void CWndVideo::DisplayThread()
{

	for( ; ; )
	{
		if(m_bPlayMode){
			if (1 == m_nBufferStatus) 
			{
				if (m_b1stBuffer) 
				{ //display opposite buffer
					m_Image->imageData = (char*)m_pYCbCrBuffer;
				}else{
					m_Image->imageData = (char*)m_pYCbCrBuffer1;
				}

				if(m_nCurrentDevice == MT9T001 )
					cvCvtColor( m_Image, m_ImageIntp, CV_BayerGB2BGR);
				else
					cvCvtColor( m_Image, m_ImageIntp, CV_BayerBG2BGR);

				
				//�̹��� ��ȯ - Tree Control ���ý�
				ImageProcess();

				
				//CRect rect;	
				HDC hdc = (HDC)::GetDC(this->m_hWnd);
				//GetClientRect(&rect);
				
				if(m_nDrvNum == 1){
					m_CvvImage.Show(hdc, 0, 0, m_nImageWidth, m_nImageHeight);
				}
				else if (m_nDrvNum == 2){
					if(m_nDrvIndex == 0)
					m_CvvImage.Show(hdc, 0, 0, 320, 240);
					else if(m_nDrvIndex == 1)
					m_CvvImage.Show(hdc, 320, 0, 320, 240);
				}
				else if (m_nDrvNum == 3){
					if(m_nDrvIndex == 0)
					m_CvvImage.Show(hdc, 0, 0, 320, 240);
					if(m_nDrvIndex == 1)
					m_CvvImage.Show(hdc, 320, 0, 320, 240);
					if(m_nDrvIndex == 2)
					m_CvvImage.Show(hdc, 0, 320, 320, 240);
				}
				else if( m_nDrvNum == 4){
					if(m_nDrvIndex == 0)
					m_CvvImage.Show(hdc, 0, 0, 320, 240);
					if(m_nDrvIndex == 1)
					m_CvvImage.Show(hdc, 320, 0, 320, 240);
					if(m_nDrvIndex == 2)
					m_CvvImage.Show(hdc, 0, 240, 320, 240);
					if(m_nDrvIndex == 2)
					m_CvvImage.Show(hdc, 320, 240, 320, 240);
				}


				DeleteDC(hdc);

				m_nBufferStatus = 0;
			}
			Sleep(1);
		}
		else
		{
			//DWORD exitcode;
			//::GetExitCodeThread(hThreadDisplay, &exitcode);
			//::ExitThread(exitcode);

			return;
		}
	}//END: for( ; ; )
	
}

void CWndVideo::DataThread()
{
	
	int			getDataTF = 0;
	m_cnt=0;
	
	for( ; ; )	{
		//TRACE("a");
		if(m_nDrvNum > 1){
		
			m_nDrvIndex++;
			//Sleep(100);
			if(m_nDrvIndex == m_nDrvNum)
			{
				m_nDrvIndex = 0;
			}
		}
		if (m_bPlayMode == true) {	// PLAY mode	
			//8 bit bayer mode
			
			if (m_b1stBuffer) {
  				getDataTF = Get_Sensor_RawDataCam(m_nImageWidth*m_nImageHeight, m_pYCbCrBuffer1, m_nDrvIndex);
				//TRACE("a");
				//TRACE("%d", m_nImageWidth);
			}
			else {
  				getDataTF = Get_Sensor_RawDataCam(m_nImageWidth*m_nImageHeight, m_pYCbCrBuffer, m_nDrvIndex);
				//TRACE("b");
			}

 			if(getDataTF==1){
				Display_Frame(this->m_hWnd);
 			}	
	
  			//Sensor���� �������� �����ŭ data�� �������� getDataTF�� 1�� return ��.
			if (1 == getDataTF) {
 				m_cnt=0;
				m_b1stBuffer = !m_b1stBuffer;
				m_nBufferStatus = 1;
			}
			
			//Time out routine
			//���� �Ⱓ���� Data�� ������ ������ Stop����...
			//Sleep(0);
			if (m_cnt == 10000) { //time out
				m_cnt = 0; //it is remained
				//SendMessage(ghwndDlg, WM_COMMAND, IDC_STOP, 0);
				m_bPlayMode = false;
				return;
			}
			else {
				m_cnt++; //idle status
			}
		}
		else if (m_bPlayMode == false) {
			//DWORD		exitcode;
			//::GetExitCodeThread(hThreadData, &exitcode);
			
			//ExitThread(exitcode);
			//::ExitThread(exitcode);

			//KillTimer(2);
			return;
		}	
	}//END: for( ; ; )


}

UINT CWndVideo::RunThread(LPVOID p)
{
     CWndVideo * me = (CWndVideo *)p;
	 me->DataThread();
     return 0;
}

UINT CWndVideo::RunThread2(LPVOID p)
{
	//try{ 
	CWndVideo *me = (CWndVideo *)p;
	 //me->OnPaint();
	 
	 me->DisplayThread();
	//}
	//catch(...)
	//{
	//	TRACE("adsd");
	//}
	return 0;
}



INIValue CWndVideo::GetINIValue()
{
	INIValue val;
	val.iShutter_pos = IIC_Read16(ADD_SHUTTER, m_nDrvIndex);
	val.iRGain_pos = IIC_Read16(ADD_RGAIN, m_nDrvIndex);
	val.iDRGain_pos = val.iRGain_pos >> 8;
	val.iRGain_pos = val.iRGain_pos & 0x00ff;

	val.iGGain_pos = IIC_Read16(ADD_GGAIN1, m_nDrvIndex);
	val.iDGGain_pos = val.iGGain_pos >> 8;
	val.iGGain_pos = val.iGGain_pos & 0x00ff;
	
	val.iBGain_pos = IIC_Read16(ADD_BGAIN, m_nDrvIndex);
	val.iDBGain_pos = val.iBGain_pos >> 8;
	val.iBGain_pos = val.iBGain_pos & 0x00ff;

	return val;
}

void CWndVideo::SetINIValue(INIValue val)
{
	DWORD wTemp;

	IIC_Write16(ADD_SHUTTER,(WORD)val.iShutter_pos, m_nDrvIndex);

	wTemp = IIC_Read16(ADD_RGAIN, m_nDrvIndex);
	wTemp = (wTemp & 0xff00) + (val.iRGain_pos);
	IIC_Write16(ADD_RGAIN,(WORD)wTemp, m_nDrvIndex);

	wTemp = IIC_Read16(ADD_RGAIN, m_nDrvIndex);
	wTemp = wTemp & 0x00ff;
	wTemp = (val.iDRGain_pos << 8) + wTemp;
	IIC_Write16(ADD_RGAIN,(WORD)wTemp, m_nDrvIndex);

	wTemp = IIC_Read16(ADD_GGAIN1, m_nDrvIndex);
	wTemp = (wTemp & 0xff00) + (val.iGGain_pos);
	IIC_Write16(ADD_GGAIN1,(WORD)wTemp, m_nDrvIndex);

	wTemp = IIC_Read16(ADD_GGAIN2, m_nDrvIndex);
	wTemp = (wTemp & 0xff00) + (val.iGGain_pos);
	IIC_Write16(ADD_GGAIN2,(WORD)wTemp, m_nDrvIndex);

	wTemp = IIC_Read16(ADD_GGAIN1, m_nDrvIndex);

	wTemp = wTemp & 0x00ff;
	wTemp = (val.iDGGain_pos << 8) + wTemp;

	IIC_Write16(ADD_GGAIN1,(WORD)wTemp, m_nDrvIndex);

	wTemp = IIC_Read16(ADD_GGAIN2, m_nDrvIndex);

	wTemp = wTemp & 0x00ff;
	wTemp = (val.iDGGain_pos << 8) + wTemp;

	IIC_Write16(ADD_GGAIN2,(WORD)wTemp, m_nDrvIndex);

	wTemp = IIC_Read16(ADD_BGAIN, m_nDrvIndex);

	wTemp = (wTemp & 0xff00) + (val.iBGain_pos);

	IIC_Write16(ADD_BGAIN,(WORD)wTemp, m_nDrvIndex);

	wTemp = IIC_Read16(ADD_BGAIN, m_nDrvIndex);

	wTemp = wTemp & 0x00ff;
	wTemp = (val.iDBGain_pos << 8) + wTemp;

	IIC_Write16(ADD_BGAIN,(WORD)wTemp, m_nDrvIndex);
}

void CWndVideo::StopPlay()
{
	/*
	DWORD exitcode;
	GetExitCodeThread(hThreadDisplay, &exitcode);
	ExitThread(exitcode);

	GetExitCodeThread(hThreadData, &exitcode);
	ExitThread(exitcode);
	*/
	if(m_bPlayMode){
		m_bPlayMode = false;
		Sleep(500);

		cvConvertImage(m_CvvImage.GetImage(), m_CvvImage.GetImage(), CV_CVTIMG_FLIP);
	}
	//memcpy(m_pBmpBuffer, (BYTE*)m_CvvImage.GetImage()->imageData, m_CvvImage.GetImage()->imageSize);//IMAGESIZE_X*IMAGESIZE_Y*3);

}


void CWndVideo::Display_Frame(HWND wnd)
{
	static		BOOL fps_first = TRUE;
	static		LARGE_INTEGER start_time, end_time, freq;
	static		__int16	display_count;
	double		gap;
	
	if( fps_first ) {
		display_count =0;
		QueryPerformanceCounter(&start_time);
		fps_first = FALSE;
	}
	else {
		QueryPerformanceCounter(&end_time);
		QueryPerformanceFrequency(&freq);
		gap = ((double)(end_time.QuadPart - start_time.QuadPart)) / ((double)freq.QuadPart);
 		if( gap >= 1 ) { 
 			fps_first = TRUE;
			//SetDlgItemFloat(hDlg, IDC_DISPLAY_FRAMERATE, (float)(display_count/gap) );
			//COpenBCDlg *dlg = 
			
			//dlg->m_strFrameRate.Format("%f", display_count/gap);
			float tmp = display_count/gap;
			::SendMessage(gBCDlg1, WM_FRAMERATE, (WPARAM)&tmp, 0);
			
		}
	}
	display_count++;
}

/**
NAME gName[TOTAL_AMOUNT] = {
	{COLORMENU1, "�÷� ���� ó��"},
	{COLORMENU2, "ȭ�Ұ� ��� ó��"},
	{COLORMENU3, "���� ���� ���͸�"},
	{COLORMENU4, "���� ����"},
	{COLORMENU5, "��������"},
	{COLORAREA1, "���ϵ� ���� ��ȯ"},
	{PIXELBASE1, "������׷� ��Ȱȭ"},
	{PIXELBASE2, "����ȭ",},
	{PIXELBASE3, "��� ���̺� ����"},
	{AREAFILTER1, "������"},
	{AREAFILTER2, "������"},
	{AREAFILTER3, "��հ� ���͸�"},
	{EDGEEXTRACT1, "�Һ�"},
	{EDGEEXTRACT2, "�ι���"},
	{EDGEEXTRACT3, "������"},
	{MORPHOLOGY1, "ħ�� ����"},
	{MORPHOLOGY2, "��â ����"},
	{MORPHOLOGY3, "���� ����"},
	{MORPHOLOGY4, "���� ����"},
};
**/

void CWndVideo::ImageProcess()
{
	//IplImage* pTmp = cvCloneImage( m_ImageIntp );
	IplConvKernel *selement;
	double var, max_var, constant;
	LARGE_INTEGER frequency1, tStart1, tEnd1;
	LARGE_INTEGER frequency2, tStart2, tEnd2;
	double tElpased1;
	CvMat *lut;
	int i,j;

	CvMat kernel_x, kernel_y; 

	float xx[] = {-1, -1, -1, -1, 9, -1, -1, -1, -1}, yy[] = {-1, -1, -1, -1, 9, -1, -1, -1, -1}; 


	switch(m_nImgProcess)
	{
		case COLORAREA1: //���ϵ� ���� ��ȯ
			cvCvtColor( m_ImageIntp, m_ImageChange, CV_BGR2GRAY);
			//selement = cvCreateStructuringElementEx(3, 3, 1, 1, CV_SHAPE_ELLIPSE);
			//cvDilate( m_ImageChange, m_ImageChange2, selement );
			m_CvvImage.CopyOf(m_ImageChange, 8);
			//cvReleaseStructuringElement( &selement );
		break;

		case PIXELBASE1: //������׷� ��Ȱȭ
			cvCvtColor( m_ImageIntp, m_ImageChange, CV_BGR2GRAY );
			cvEqualizeHist( m_ImageChange, m_ImageChange2 );
			m_CvvImage.CopyOf(m_ImageChange2, 8);
		break;

		case PIXELBASE2: //����ȭ
			cvCvtColor( m_ImageIntp, m_ImageChange, CV_BGR2GRAY );
			cvThreshold(m_ImageChange, m_ImageChange, 127, 255, CV_THRESH_BINARY); 
			m_CvvImage.CopyOf(m_ImageChange, 8);
		break;

		case PIXELBASE3: //������̺� ����	
			
			// ��� �Լ� ����
			var = 0;
			max_var = 222; // test
			constant = 255.0 / log(1+max_var);
			cvCvtColor( m_ImageIntp, m_ImageChange, CV_BGR2GRAY );
			for(i=0; i<m_ImageChange->height; i++)
			{
				for(j=0; j<m_ImageChange->width; j++)
				{
					var = constant * log( 1.0 + cvGetReal2D( m_ImageChange, i, j) );
					cvSetReal2D( m_ImageChange2, i, j, (uchar)cvRound(var) ); 
				}
			}

			lut = cvCreateMat( 1, 256, CV_8UC1 );

			for(i=0; i<256; i++)
			{
				var = (int)( constant * log( 1.0 + i ) );
				lut->data.ptr[i] = (uchar)cvRound(var);
			}

			lut->data.ptr[0] = 0;

			// ���� : src_image, dst_image, lut�� ���� Ÿ���� �����ؾ� ��!!!! 
			//		  ��, CV_8UC1 : 8bit(����), CV_32FC1 : 32bit (�Ǽ�)
			//        ��� ��� �Ѱ����� ���ϸ� �ݵ�� �ؾ� �Ѵ�.
			//        �׷��� ������ ����� ����!!!
			cvLUT( m_ImageChange, m_ImageChange2, lut );
			m_CvvImage.CopyOf(m_ImageChange2, 8);
			
		break;

		case AREAFILTER1: //������
			cvSmooth(m_ImageIntp, m_ImageIntp, CV_BLUR,5,5);
			m_CvvImage.CopyOf(m_ImageIntp,1); 
		break;
		
		case AREAFILTER2: //������

			cvInitMatHeader(&kernel_x, 3, 3, CV_32FC1, xx); 
			//cvInitMatHeader(&kernel_y, 3, 3,CV_32FC1, yy); 
			cvFilter2D(m_ImageIntp, m_ImageIntp, &kernel_x); 
			//cvFilter2D(m_ImageIntp, m_ImageIntp, &kernel_y); 

			m_CvvImage.CopyOf(m_ImageIntp, 32);
		break;

		case AREAFILTER3: //��հ� ���͸�
			cvSmooth(m_ImageIntp, m_ImageIntp, CV_MEDIAN,5,5);
			m_CvvImage.CopyOf(m_ImageIntp,1); 
		break;

		case EDGEEXTRACT1: //�Һ�
			cvCvtColor( m_ImageIntp, m_ImageChange, CV_BGR2GRAY );
			cvSobel( m_ImageChange, m_ImageChange2, 0, 1, 3);
			m_CvvImage.CopyOf(m_ImageChange2, 8);
		break;

		case EDGEEXTRACT2: //���ö�þ�
			cvCvtColor( m_ImageIntp, m_ImageChange, CV_BGR2GRAY );
			cvLaplace( m_ImageChange, m_ImageChangeCvLa, 7);
			m_CvvImage.CopyOf(m_ImageChangeCvLa, 24);
		break;

		case EDGEEXTRACT3: //ĳ��
			cvCvtColor( m_ImageIntp, m_ImageChange, CV_BGR2GRAY );
			cvCanny(  m_ImageChange, m_ImageChange2, 100, 150, 3);
			m_CvvImage.CopyOf(m_ImageChange2, 8);
		break;

		case MORPHOLOGY1: //ħ��
			cvCvtColor( m_ImageIntp, m_ImageChange, CV_BGR2GRAY);
			selement = cvCreateStructuringElementEx(3, 3, 1, 1, CV_SHAPE_ELLIPSE);
			cvErode( m_ImageChange, m_ImageChange2, selement );
			m_CvvImage.CopyOf(m_ImageChange2, 8);
			cvReleaseStructuringElement( &selement );
		break;
						   //8 - ���ϵ�, 24 - �÷�
		case MORPHOLOGY2: //��â
			cvCvtColor( m_ImageIntp, m_ImageChange, CV_BGR2GRAY);
			selement = cvCreateStructuringElementEx(3, 3, 1, 1, CV_SHAPE_ELLIPSE);
			cvDilate( m_ImageChange, m_ImageChange2, selement );
			m_CvvImage.CopyOf(m_ImageChange2, 8);
			cvReleaseStructuringElement( &selement );
		break;

		case MORPHOLOGY3: //����
			cvCvtColor( m_ImageIntp, m_ImageChange, CV_BGR2GRAY);
			selement = cvCreateStructuringElementEx(3, 3, 1, 1, CV_SHAPE_ELLIPSE);
			cvMorphologyEx( m_ImageChange, m_ImageChange2, m_ImageChange3, selement, CV_MOP_OPEN, 1 );
			m_CvvImage.CopyOf(m_ImageChange2, 8);
			cvReleaseStructuringElement( &selement );
		break;

		case MORPHOLOGY4: //����
			cvCvtColor( m_ImageIntp, m_ImageChange, CV_BGR2GRAY);
			selement = cvCreateStructuringElementEx(3, 3, 1, 1, CV_SHAPE_ELLIPSE);
			cvMorphologyEx( m_ImageChange, m_ImageChange2, m_ImageChange3, selement, CV_MOP_CLOSE, 1 );
			m_CvvImage.CopyOf(m_ImageChange2, 8);
			cvReleaseStructuringElement( &selement );
		break;

		default:
		m_CvvImage.CopyOf(m_ImageIntp,1);
	
	}
	//cvReleaseImage(&pTmp);
}

void CWndVideo::ImageSetDefault()
{
	m_nImgProcess = -1;
}

/**************************************************************************************************
* BOOL			SaveImageToBmpFile(void)
* Description:
*		 Image save to bmp file format.
* Inputs:
*       m_pBmpBuffer :  Image buffer : Global variable.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL CWndVideo::SaveImageToBmpFile(void)
{
	//snapshot click
	//if (m_bPlayMode) {
	SuspendThread(hThreadData);
	SuspendThread(hThreadDisplay);
	//m_bPlayMode = false;
	//} 
	
	cvConvertImage(m_CvvImage.GetImage(), m_CvvImage.GetImage(), CV_CVTIMG_FLIP);
	memcpy(m_pBmpBuffer, (BYTE*)m_CvvImage.GetImage()->imageData, m_CvvImage.GetImage()->imageSize);//IMAGESIZE_X*IMAGESIZE_Y*3);

	OPENFILENAME	 SFN;
	char			 lpstrFile[MAX_PATH];
	char			 SaveFileMessage[MAX_PATH]={0};
	
	int				 OffBits;
	HFILE			 bmpFile;
	BITMAPFILEHEADER bmpHeader; // Header for Bitmap file
	BITMAPINFO		 bmpInfo;
	
	OffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
	DWORD dwSizeImage = m_nImageWidth*m_nImageHeight*3;
	
	bmpHeader.bfType = ( (WORD)('M'<<8)|'B' );  
	bmpHeader.bfSize = OffBits + dwSizeImage;
	bmpHeader.bfReserved1 = 0;
	bmpHeader.bfReserved2 = 0;
	bmpHeader.bfOffBits = OffBits;
	
	bmpInfo.bmiHeader.biSize            = sizeof(BITMAPINFOHEADER);
    bmpInfo.bmiHeader.biWidth           = m_nImageWidth;
    bmpInfo.bmiHeader.biHeight          = m_nImageHeight;
    bmpInfo.bmiHeader.biPlanes          = 1;
    bmpInfo.bmiHeader.biBitCount        = 24;
    bmpInfo.bmiHeader.biCompression     = BI_RGB;
    bmpInfo.bmiHeader.biSizeImage       = 0; 
    bmpInfo.bmiHeader.biXPelsPerMeter   = 0;
    bmpInfo.bmiHeader.biYPelsPerMeter   = 0;
    bmpInfo.bmiHeader.biClrUsed         = 0;
    bmpInfo.bmiHeader.biClrImportant    = 0;
	
	wsprintf(lpstrFile, "Image");
	memset(&SFN, 0, sizeof(OPENFILENAME));
	SFN.lStructSize = sizeof(OPENFILENAME);
	SFN.hwndOwner = this->m_hWnd;
	SFN.lpstrFilter = "bmp file(*.bmp)\0*.bmp\0";
	SFN.lpstrFile = lpstrFile;
	SFN.nMaxFile = MAX_PATH;
	
	if (!GetSaveFileName(&SFN))	return FALSE;
	
	strcat(lpstrFile, ".bmp");
	
	if (::_access(lpstrFile, 0) == 0) { 
		wsprintf(SaveFileMessage, "%s is already exists.Do you want replace it?", lpstrFile);
		if (::MessageBox(this->m_hWnd,SaveFileMessage, "Save as", MB_YESNO|MB_ICONWARNING) == IDNO)
			return 0;
		if (::_access(lpstrFile, 6) == -1) { 
			::MessageBox(this->m_hWnd, "Could not save a file.", "File save error", MB_OK|MB_ICONSTOP);
			return 0;
		}
	}
	
	bmpFile = _lcreat(lpstrFile, 0);
	if (bmpFile < 0) {
		return FALSE;
	}
	
	UINT len;
	len = _lwrite(bmpFile, (LPSTR)&bmpHeader, sizeof(BITMAPFILEHEADER));
	len = _lwrite(bmpFile, (LPSTR)&bmpInfo, sizeof(BITMAPINFOHEADER));
	len = _lwrite(bmpFile, (LPSTR)m_pBmpBuffer, bmpHeader.bfSize - sizeof(bmpHeader) - sizeof(bmpInfo)+4);  //+4 is for exact filesize
	_lclose(bmpFile);
	
	MyDelay(100);
	//m_bPlayMode = true;
	ResumeThread(hThreadData);
	ResumeThread(hThreadDisplay);

	return TRUE;	
}