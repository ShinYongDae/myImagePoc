#pragma once


// CDlgSetup ��ȭ �����Դϴ�.

class CDlgSetup : public CDialog
{
	DECLARE_DYNAMIC(CDlgSetup)

public:
	CDlgSetup(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CDlgSetup();
	void SetINI(INIValue val);

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	int m_nShutter;
	int m_nRedAG;
	int m_nRedDG;
	int m_nGreenAG;
	int m_nGreenDG;
	int m_nBlueAG;
	int m_nBlueDG;
	int m_ctlShutter;
	int m_ctlRedAG;
	int m_ctlRedDG;
	int m_ctlGreenAG;
	int m_ctlGreenDG;
	int m_ctlBlueAG;
	int m_ctlBlueDG;

	BOOL m_bInterpolation;
	BOOL m_bPreview;
	BOOL m_bLed;
	
	afx_msg void OnBnClickedButtonDefault();
	afx_msg void OnNMReleasedcaptureSliderShutter(NMHDR *pNMHDR, LRESULT *pResult);
	virtual BOOL OnInitDialog();
	afx_msg void OnNMReleasedcaptureSliderRedag(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMReleasedcaptureSliderReddg(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMReleasedcaptureSliderGreenag(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMReleasedcaptureSliderGreendg(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMReleasedcaptureSliderBlueag(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMReleasedcaptureSliderBluedg(NMHDR *pNMHDR, LRESULT *pResult);

	virtual BOOL Create(CWnd* pParentWnd = NULL);
protected:
	virtual void OnOK();
};
