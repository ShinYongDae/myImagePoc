//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OpenBC.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_OPENBC_DIALOG               102
#define IDC_WND_VIDEO                   103
#define IDR_MAINFRAME                   128
#define IDB_NODE                        129
#define IDD_DIALOG_SETUP                130
#define IDC_BUTTON_START                1001
#define IDC_BUTTON_STOP                 1002
#define IDC_BUTTON_SETUP                1003
#define IDC_TREE_AL                     1004
#define IDC_EDIT_SHUTTER                1008
#define IDC_EDIT_REDAG                  1009
#define IDC_EDIT_REDDG                  1010
#define IDC_EDIT_GREENAG                1012
#define IDC_EDIT_GREENDG                1013
#define IDC_EDIT_BLUEAG                 1014
#define IDC_EDIT_BLUEDG                 1015
#define IDC_CHECK_INTERPOLATION         1019
#define IDC_CHECK_PREVIEW               1020
#define IDC_CHECK_LED                   1021
#define IDC_SLIDER_SHUTTER              1022
#define IDC_SLIDER_GREENAG              1023
#define IDC_SLIDER_REDDG                1024
#define IDC_SLIDER_REDAG                1025
#define IDC_SLIDER_BLUEDG               1026
#define IDC_SLIDER_BLUEAG               1027
#define IDC_SLIDER_GREENDG              1028
#define IDC_BUTTON_DEFAULT              1029
#define IDC_FRAME_RATE                  1030
#define IDC_STATIC_SELECT               1031
#define IDC_BUTTON_CAPTURE              1032
#define IDC_COMBO1                      1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
