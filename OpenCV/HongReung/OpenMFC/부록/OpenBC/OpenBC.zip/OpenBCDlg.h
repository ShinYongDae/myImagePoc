// OpenBCDlg.h : ��� ����
//

#pragma once
#include "WndVideo.h"
#include "afxcmn.h"
// COpenBCDlg ��ȭ ����
#include "DlgSetup.h"
#include "afxwin.h"



class COpenBCDlg : public CDialog
{
// ����
public:
	COpenBCDlg(CWnd* pParent = NULL);	// ǥ�� ������

// ��ȭ ���� ������
	enum { IDD = IDD_OPENBC_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ����

public:
	CWndVideo m_wndVideo; //Video View ó��
	CWndVideo m_wndVideo2, m_wndVideo3, m_wndVideo4;
	int		  m_nCameraAmount;
// ��� ����
private:
	CImageList m_imageList; //Node Icon ImageList
	HTREEITEM m_hTreeItem; //Tree Item Handle
	CDlgSetup *m_pDlgSetup;

public:
	void MyClose();

// ����
protected:
	HICON m_hIcon;

	// �޽��� �� �Լ��� �����߽��ϴ�.
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg LRESULT OnFrameRate(WPARAM wp,LPARAM lp);
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()


public:
	CTreeCtrl m_treeAl;
	afx_msg void OnBnClickedButtonStart();
	afx_msg void OnBnClickedButtonSetup();
	afx_msg void OnClose();
	afx_msg void OnBnClickedButtonStop();
	CString m_strFrameRate;
	afx_msg void OnTvnSelchangedTreeAl(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedButtonDefault();
	CString m_strSelect;
	afx_msg void OnBnClickedButtonCapture();
	CComboBox m_ctlCombo;
	afx_msg void OnCbnSelchangeCombo1();
};
