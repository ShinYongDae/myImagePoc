#ifndef _USB20INTERFACE_H_
#define _USB20INTERFACE_H_

extern "C" __declspec(dllexport) int	Get_Sensor_RawDataCam(int nImageLen, LPBYTE pRawBuffer, int index);
extern "C" __declspec(dllexport) int	HW_InitCam(int *drvInform);

extern "C" __declspec(dllexport) void	Set_Sensor_Addr(WORD wRegData, int index);
extern "C" __declspec(dllexport) BYTE	IIC_Read(WORD wRegAddr, int index);
extern "C" __declspec(dllexport) BOOL	IIC_Write(WORD wRegAddr, WORD wRegData, int index);
extern "C" __declspec(dllexport) DWORD	IIC_Read16(WORD wRegAddr, int index);
extern "C" __declspec(dllexport) BOOL	IIC_Write16(WORD wRegAddr, WORD wRegData, int index);
extern "C" __declspec(dllexport) BOOL	VCLK_POLALITY_HighLow (WORD wRegData, int index);

extern "C" __declspec(dllexport) BOOL	Trig_Read (int index);				 
extern "C" __declspec(dllexport) BOOL	LED_OnOff (WORD wRegData, int index); 
extern "C" __declspec(dllexport) void	CLK24M_OUT (int index);
 


#endif /* _USB20INTERFACE_H_ */