#pragma once


// CWndVideo
#include	<cv.h>
#include	<cxcore.h>
#include	<highgui.h>
#include	"USB20Interface.h"

//CWnd�� ����ϸ� OnPaint ���ٰ� �׸��� �־��.

class CWndVideo : public CWnd
{
	DECLARE_DYNAMIC(CWndVideo)

public:
	CWndVideo();
	virtual ~CWndVideo();
	void StartPlay();
	void StopPlay();
	INIValue GetINIValue();
	void SetINIValue(INIValue val);
	void Display_Frame(HWND wnd);
	void SetImageProcess(DWORD op);
	void ImageProcess();
	void ImageSetDefault();
	BOOL SaveImageToBmpFile(void);
	BOOL		m_bPlayMode;
	int	 m_nIdentity;
	int			m_nDrvNum;
private:
	CvvImage	m_CvvImage;
	IplImage	*m_Image;
	IplImage	*m_ImageIntp;
	IplImage	*m_ImageChange;
	IplImage	*m_ImageChange2;
	IplImage	*m_ImageChange3;
	IplImage	*m_ImageChangeCvLa;
	int			m_nDrvIndex;
	int			m_nCurrentSensorType;
	int			m_nFitmode;
	int			m_nImageWidth;
	int			m_nImageHeight;
	int			m_nCurrentDevice;
	int			m_b1stBuffer;
	char		m_strRootdir[260];
	BYTE		*m_pYCbCrBuffer;
	BYTE		*m_pYCbCrBuffer1;
	BYTE		*m_pBmpBuffer;
	HANDLE		hThreadData;
	HANDLE		hThreadDisplay;
	int			m_nBufferStatus;
	int			m_nCircle;
	//volatile	BOOL running;
	int			m_cnt;
	DWORD		m_nImgProcess;

private:
	void MyDelay(DWORD millisec);
	int  SensorRecognition (int Id_check);
	BOOL INIWriteStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR str);
	BOOL INIReadStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR lpDefault, LPTSTR lpReturn, DWORD nSize);
	void SensorRegInit(int SensorID, int Xsize);
	BOOL ParseRegisterFileBoard(char *filename);
	BOOL IIC_Write_Proc(int mode, WORD wRegAddr, WORD wRegData);
	void Read_User_Control_Set(void);
	void DataThread();
	void DisplayThread();
	static UINT RunThread(LPVOID p);
	static UINT RunThread2(LPVOID p);

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTimer(UINT nIDEvent);
};

//m_CvvImage.Show(hDC, m_rect.left, m_rect.top, m_rect.right, m_rect.bottom);