#if !defined(AFX_DLGCAMTRACKSETUP_H__66B47681_BF98_4419_A218_8AD82B19D07F__INCLUDED_)
#define AFX_DLGCAMTRACKSETUP_H__66B47681_BF98_4419_A218_8AD82B19D07F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgCamTrackSetup.h : header file
//

/////////////////////w////////////////////////////////////////////////////////
// CDlgCamTrackSetup dialog
// Func : Dialog for setting up cam video size and tracking option. modaless.
// last modified : Jan 18th 2007
// Made by Byung Chul Kim
/////////////////////////////////////////////////////////////////////////////

class CDlgCamTrackSetup : public CDialog
{
// Construction
public:
	CDlgCamTrackSetup(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgCamTrackSetup)
	enum { IDD = IDD_DIALOG_SETUP };
	CSliderCtrl	m_slbVMin;
	CSliderCtrl	m_slbVMax;
	CSliderCtrl	m_slbSmin;
	CComboBox	m_comboCamSize;
	CString	m_strSMin;
	CString	m_strVMax;
	CString	m_strVMin;
	//}}AFX_DATA
	BOOL m_bFaceDetected;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgCamTrackSetup)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgCamTrackSetup)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnButtonMotionsetup();
	afx_msg void OnReleasedcaptureSliderSmin(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSliderVmin(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSliderVmax(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonFace();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCAMTRACKSETUP_H__66B47681_BF98_4419_A218_8AD82B19D07F__INCLUDED_)
