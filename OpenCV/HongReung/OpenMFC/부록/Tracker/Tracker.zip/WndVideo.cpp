// WndVideo.cpp : implementation file
//

#include "stdafx.h"
#include "Traker.h"
#include "WndVideo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWndVideo
extern CWndVideo* wndVideoObject;


float hranges_arr[] = {0,180};
float* hranges = hranges_arr;
int hdims = 16;

CWndVideo::CWndVideo()
{
	m_bSetZone = false;
	m_bBeingSelected = false;

	m_bBeingTracked = 0;

	m_iplImage = NULL;
	m_iplHsv = NULL;
	m_iplHue = NULL;
	m_iplMask = NULL;
	m_iplBackproject = NULL;
	m_iplHist = NULL;
	m_bFaceDetected = false;
}

CWndVideo::~CWndVideo()
{
	cvcamStop( ); // Stop showing cam
	cvcamExit( ); // Stop connecting cam
	
	//Release Image Created.
	cvReleaseImage(&m_iplImage);
	cvReleaseImage(&m_iplHsv);
	cvReleaseImage(&m_iplHue);
	cvReleaseImage(&m_iplBackproject);
}


BEGIN_MESSAGE_MAP(CWndVideo, CWnd)
	//{{AFX_MSG_MAP(CWndVideo)
	ON_WM_CREATE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWndVideo message handlers

/***

Purpose of CallCurrentFrame Method : 

As a patch for existing software, use a top-level (non-member) function 
as a wrapper which takes an object obtained through some other technique. 
Depending on the routine you're calling, this "other technique" might 
be trivial or might require a little work on your part. 
The system call that starts a thread, for example, might require you 
to pass a function pointer along with a void*, so you can pass 
the object pointer in the void*. Many real-time operating systems 
do something similar for the function that starts a new task. 
Worst case you could store the object pointer in a global variable; 
this might be required for Unix signal handlers 
(but globals are, in general, undesired). 
In any case, the top-level function would call the 
desired member function on the object. 

Related Link :
http://www.parashift.com/c++-faq-lite/pointers-to-members.html

***/

void CallCurrentFrame(IplImage* frame)
{
	wndVideoObject->CurrentFrame(frame);
}

BOOL CWndVideo::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	return CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
}

void CWndVideo::SetZone(bool value)
{
	
	m_bSetZone = value;
}

CvScalar CWndVideo::Hsv2rgb( float hue )
{
    int rgb[3], p, sector;
    static const int sector_data[][3]=
        {{0,2,1}, {1,2,0}, {1,0,2}, {2,0,1}, {2,1,0}, {0,1,2}};
    hue *= 0.033333333333333333333333333333333f;
    sector = cvFloor(hue);
    p = cvRound(255*(hue - sector));
    p ^= sector & 1 ? 255 : 0;

    rgb[sector_data[sector][0]] = 255;
    rgb[sector_data[sector][1]] = 0;
    rgb[sector_data[sector][2]] = p;

    return cvScalar(rgb[2], rgb[1], rgb[0],0);
}

void CWndVideo::CurrentFrame(IplImage* frame)
{
	if(!frame) return;
	
	// [�� �ν� �ѱ�] ��ư�� Ŭ������ ��
	if(m_bFaceDetected){
		// Load the pre-trained Haar classifier data.
		CvHaarClassifierCascade* classifier = (CvHaarClassifierCascade*)cvLoad(
			"data/haarcascade_frontalface_alt.xml", 0, 0, 0);
 
		// Quit the application if the input source or the classifier data 
		// failed to load properly.
		if(!classifier)
		{
			AfxMessageBox("haarcascade_frontalface_alt.xml ������ �����ϴ�.");
			this->DestroyWindow();
			return;
		}
 
		// Create a CvMemStorage object for use by the face detection function.
		CvMemStorage* facesMemStorage = cvCreateMemStorage(0);
		IplImage* tempFrame = NULL;

		// If this is the first iteration, allocate a temporary image to 
		// use for face detection.
		if (!tempFrame)
		{
			tempFrame = cvCreateImage(cvSize(frame->width, 
				frame->height), IPL_DEPTH_8U, frame->nChannels);
		}
 
		// Copy the current frame into the temporary image.  Also, make 
		// sure the images have the same orientation.
		if(frame->origin == IPL_ORIGIN_TL)
		{
			cvCopy(frame, tempFrame, 0);
		}
		else
		{
			cvFlip(frame, tempFrame, 0);
		}
 
		// Perform face detection on the temporary image, adding a rectangle 
		// around the detected face.
		FaceDetection(tempFrame, frame, facesMemStorage, classifier);
		
		cvReleaseMemStorage(&facesMemStorage);
		if (tempFrame)
		{
			cvReleaseImage(&tempFrame);
		}

	}

	// m_iplImage�� �ʱ�ȭ���� �ʾ��� ��  
	if( m_iplImage == NULL )
	{
		// m_iplImage �ʱ�ȭ 
		m_iplImage = cvCreateImage( cvGetSize(frame), 8, 3 );
		m_iplImage->origin = frame->origin;
		
		// �������� ���� ������ �ʱ�ȭ 
		m_iplHsv = cvCreateImage( cvGetSize(frame), 8, 3 );
		m_iplHue = cvCreateImage( cvGetSize(frame), 8, 1 );
		m_iplMask = cvCreateImage( cvGetSize(frame), 8, 1 );
		m_iplBackproject = cvCreateImage( cvGetSize(frame), 8, 1 );

		// ������׷� �ʱ�ȭ 
		m_cvHist = cvCreateHist( 1, &hdims, CV_HIST_ARRAY, &hranges, 1 );
	}
	
	// ī�޶󿡼� �Ѱܿ� frame�� m_iplImage�� ������ ��, HSV �÷� �������� ��ȯ�Ѵ�.
	cvCopy( frame, m_iplImage, 0 );
    cvCvtColor( m_iplImage, m_iplHsv, CV_BGR2HSV );
	
	// ����ڰ� ������ ��ü ������ ���콺�� �������� ��, �ش� ������ �����Ѵ�.
	if( m_bSetZone )
	{
		if( m_bBeingSelected && m_cvRtSelected.width > 0 && m_cvRtSelected.height > 0 )
		{	
			cvSetImageROI( frame, m_cvRtSelected );
			cvXorS( frame, cvScalarAll(255), frame, 0 );
			cvResetImageROI( frame );
		}
	}


	// ������ ���۵Ǿ��ٸ�
	if( m_bBeingTracked )
	{
			
		// �־��� 3��( Value ä���� max, min, Saturation ä���� min )�� ����
		// �ٽ� HSV �÷� ������ ������ ���δ�.
	    cvInRangeS( m_iplHsv, cvScalar(0, m_iSMin, MIN(m_iVMin, m_iVMax),0),
                    cvScalar(180,256,MAX(m_iVMin,m_iVMax),0), m_iplMask );

		// HSV �÷� ������ �����Ͽ�, Hue ä�θ� �����´�.
        cvSplit( m_iplHsv, m_iplHue, 0, 0, 0 );
		
		if( m_bBeingTracked < 0 )
        {
			float max_val = 0.f;

			// ��ü ������ ���� ������ ����, ���� �������� �����Ͽ� �����Ѵ�.
			cvSetImageROI( m_iplHue, m_cvRtSelected );
			cvSetImageROI( m_iplMask, m_cvRtSelected );

			// ���� ������ ������׷��� ����Ѵ�.
			cvCalcHist( &m_iplHue, m_cvHist, 0, m_iplMask );
			cvGetMinMaxHistValue( m_cvHist, 0, &max_val, 0, 0 );

			// ���� ������ ������׷��� �����Ѵ�.
			cvConvertScale( m_cvHist->bins, m_cvHist->bins, 
							max_val ? 255. / max_val : 0., 0 );

			// ���� ������ �ٽ� �ǵ����� ������ ũ��� ��ȯ�Ѵ�.
			cvResetImageROI( m_iplHue );
			cvResetImageROI( m_iplMask );

			// ���� ����� ���� ������ �ѱ��.
			m_cvRtTracked = m_cvRtSelected;

			// Hue ä�� �� ������ ��� �缳���ϴ� ������ ������ �����Ѵ�.
			m_bBeingTracked = 1;
		}

		// Hue ä���� �̹����� ������׷� ���� �ְ� backproject�� ������ ��ȯ�Ѵ�.
		cvCalcBackProject( &m_iplHue, m_iplBackproject, m_cvHist );

		// backproject�� ����� AND �����ؼ� �����Ѵ�.
		cvAnd( m_iplBackproject, m_iplMask, m_iplBackproject, 0 );

		// CAMSHIFT �˰������� �̿��� �����Ѵ�.
		cvCamShift( m_iplBackproject, m_cvRtTracked,
					cvTermCriteria( CV_TERMCRIT_EPS | CV_TERMCRIT_ITER, 10, 1 ),
					&m_cvTrackComp, &m_cvTrackBox );

		// ���Ӱ� ������ ������ �ٽ� �Ҵ��Ѵ�.
		m_cvRtTracked = m_cvTrackComp.rect;

		if( m_iplImage->origin )
			m_cvTrackBox.angle = -m_cvTrackBox.angle;

		// ������ �κ��� Ÿ�������� �׷��ش�.
		cvEllipseBox( frame, m_cvTrackBox, CV_RGB(255,0,0), 3, CV_AA, 0 );
	}

	// �Ҵ��� �޸� �����Ѵ�.
	if( m_iplImage == NULL )
	{
		cvReleaseHist( &m_cvHist );
		cvReleaseImage( &m_iplHsv );
		cvReleaseImage( &m_iplHue );
		cvReleaseImage( &m_iplMask );
		cvReleaseImage( &m_iplBackproject );
	}
}

int CWndVideo::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	
	int width = VIDEO_WIDTH;
	int height = VIDEO_HEIGHT;
 
	int nselected = cvcamGetCamerasCount();
 
	cvcamSetProperty(0, CVCAM_PROP_ENABLE, &nselected);
	cvcamSetProperty(0, CVCAM_PROP_RENDER, &nselected)  ;
  
	cvcamSetProperty(0, CVCAM_PROP_WINDOW, &(this->m_hWnd));
	cvcamSetProperty(0, CVCAM_RNDWIDTH, &width);  // Camera Width
	cvcamSetProperty(0, CVCAM_RNDHEIGHT, &height);  // Camera Height
	cvcamSetProperty(0, CVCAM_PROP_CALLBACK, CallCurrentFrame ); // CurrentFrame is called per rate.

	cvcamInit();
	cvcamStart();
	
	return 0;
}

void CWndVideo::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	if(m_bSetZone)
	{	
		int x = point.x;
		int y = VIDEO_HEIGHT - point.y;
		m_cvPtOrigin = cvPoint( x, y );
        m_cvRtSelected = cvRect( x , y, 0, 0);
		m_bBeingSelected = true;
	}

	CWnd::OnLButtonDown(nFlags, point);
}

void CWndVideo::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bSetZone)
	{	
		m_bBeingSelected = false;
		m_bSetZone = false;
		if( m_cvRtSelected.width > 0 && m_cvRtSelected.height > 0 )
		{
			//track_object = -1;
			//TRACE("dsdsdsd");
			m_bBeingTracked = -1;
			TRACE("selection : %d %d %d %d\n", m_cvRtSelected.width, m_cvRtSelected.height, m_cvRtSelected.x, m_cvRtSelected.y);
		}
	}
	CWnd::OnLButtonUp(nFlags, point);
}

void CWndVideo::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	// Set the zone while cliking.
	if(m_bBeingSelected)
	{
		int x = point.x;
		int y = VIDEO_HEIGHT - point.y;

		m_cvRtSelected.x = MIN(x, m_cvPtOrigin.x);
        m_cvRtSelected.y = MIN(y, m_cvPtOrigin.y);
        m_cvRtSelected.width = m_cvRtSelected.x + CV_IABS(x - m_cvPtOrigin.x);
        m_cvRtSelected.height = m_cvRtSelected.y + CV_IABS(y - m_cvPtOrigin.y);
        
        m_cvRtSelected.x = MAX( m_cvRtSelected.x, 0 );
        m_cvRtSelected.y = MAX( m_cvRtSelected.y, 0 );
        m_cvRtSelected.width = MIN( m_cvRtSelected.width, VIDEO_WIDTH );
        m_cvRtSelected.height = MIN( m_cvRtSelected.height, VIDEO_HEIGHT );
        m_cvRtSelected.width -= m_cvRtSelected.x;
        m_cvRtSelected.height -= m_cvRtSelected.y;
	}

	CWnd::OnMouseMove(nFlags, point);
}

void CWndVideo::StopWebCam()
{
	cvcamStop( ); // Stop showing cam
	cvcamExit( ); // Stop connecting cam
}

void CWndVideo::SetSMin(int val)
{
	m_iSMin = val;
}

void CWndVideo::SetVMin(int val)
{
	m_iVMin = val;
}

void CWndVideo::SetVMax(int val)
{
	m_iVMax = val;

	TRACE("Option Value : %d %d %d\n", m_iSMin, m_iVMin, m_iVMax);
}

void CWndVideo::SetFaceDetected(BOOL val)
{
	m_bFaceDetected = val;
}

void CWndVideo::FaceDetection(IplImage* frame, IplImage* frame2, CvMemStorage* storage, 
	CvHaarClassifierCascade* classifier)
{
	// "Resets" the memory but does not deallocate it.
	cvClearMemStorage(storage);
 
	// Run the main object recognition function.  The arguments are: 
	// 1. the image to use
	// 2. the pre-trained Haar classifier cascade data
	// 3. memory storage for rectangles around recognized objects
	// 4. a scale factor "by which the search window is scaled between the 
	//    subsequent scans, for example, 1.1 means increasing window by 10%"
	// 5. the "minimum number (minus 1) of neighbor rectangles that makes up 
	//    an object. All the groups of a smaller number of rectangles than 
	//    min_neighbors-1 are rejected. If min_neighbors is 0, the function 
	//    does not any grouping at all and returns all the detected candidate 
	//    rectangles, which may be useful if the user wants to apply a 
	//    customized grouping procedure."
	// 6. flags which determine the mode of operation
	// 7. the minimum object size (if possible, increasing this will 
	//    really speed up the process)
	CvSeq* faces = cvHaarDetectObjects(frame, classifier, storage, 1.1, 
		2, CV_HAAR_DO_CANNY_PRUNING, cvSize(20, 20));
 
	// If any faces were detected, draw rectangles around them.
	if (faces)
	{
		for(int i = 0; i < faces->total; ++i)
		{
			// Setup two points that define the extremes of the rectangle, 
			// then draw it to the image..
			CvPoint point1, point2;
			CvRect* rectangle = (CvRect*)cvGetSeqElem(faces, i);
			point1.x = rectangle->x;
			point2.x = (rectangle->x + rectangle->width);
			point1.y = rectangle->y;
			point2.y = (rectangle->y + rectangle->height);

			//point1.x = point1.x + abs((point1.x - point2.x))/2;
			//point1.y = point1.y + abs((point1.y - point2.y))/2;

			cvRectangle(frame2, point1, point2, CV_RGB(0,255,0), 3, 8, 0);
		}
	}
}
