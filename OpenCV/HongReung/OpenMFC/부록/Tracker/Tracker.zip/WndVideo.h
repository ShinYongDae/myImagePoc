#if !defined(AFX_WNDVIDEO_H__4A0398B8_4EDF_4578_9514_04E5DD08220D__INCLUDED_)
#define AFX_WNDVIDEO_H__4A0398B8_4EDF_4578_9514_04E5DD08220D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WndVideo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWndVideo window
// Func : Show cam video clip
// last modified : Jan 16th 2007
// Made by Byung Chul Kim
/////////////////////////////////////////////////////////////////////////////

class CWndVideo : public CWnd
{
// Construction
public:
	CWndVideo();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWndVideo)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWndVideo();

	void CurrentFrame(IplImage* image);
	void StopWebCam();
	void SetFaceDetected(BOOL val);

	// Generated message map functions
protected:
	//{{AFX_MSG(CWndVideo)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG

protected:
	
	BOOL   m_bBeingSelected; // Flag for setting zone that is being selected.
	BOOL   m_bSetZone; // Set the zone for object tracked.
	int   m_bBeingTracked; // Flag for traking object.

	CvPoint m_cvPtOrigin;
	CvRect  m_cvRtSelected; // Zone Selected.
	CvRect	m_cvRtTracked; // Zone Tracked.
	
	CvBox2D	m_cvTrackBox;	// 2D Track Box
	CvConnectedComp m_cvTrackComp;	//Track Connected Comp
	CvHistogram* m_cvHist;	// Histogram

	IplImage* m_iplImage;
	IplImage* m_iplHsv;
	IplImage* m_iplHue;
	IplImage* m_iplMask;
	IplImage* m_iplBackproject;
	IplImage* m_iplHist;

	int m_iSMin;
	int m_iVMin;
	int m_iVMax;

	BOOL	m_bFaceDetected;	//Face Detection

protected:
	CvScalar Hsv2rgb( float hue );
	void FaceDetection(IplImage* frame, IplImage* frame2, CvMemStorage* storage, 
	CvHaarClassifierCascade* classifier);

public:
	
	void SetZone(bool value);	//Change m_bSetZone.
	void SetSMin(int val);
	void SetVMin(int val);
	void SetVMax(int val);

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WNDVIDEO_H__4A0398B8_4EDF_4578_9514_04E5DD08220D__INCLUDED_)
