// TrakerView.cpp : implementation of the CTrakerView class
//

#include "stdafx.h"
#include "Traker.h"

#include "TrakerDoc.h"
#include "TrakerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTrakerView

IMPLEMENT_DYNCREATE(CTrakerView, CFormView)

BEGIN_MESSAGE_MAP(CTrakerView, CFormView)
	//{{AFX_MSG_MAP(CTrakerView)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
	ON_MESSAGE ( MOTIONSETUP_EVENT, OnMotionSetup )
	ON_MESSAGE ( MOTIONSETUP_EVENT2, OnMotionSetup2 )
	ON_MESSAGE ( MOTIONSETUP_EVENT3, OnMotionSetup3 )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrakerView construction/destruction

CWndVideo* wndVideoObject = NULL;

CTrakerView::CTrakerView()
	: CFormView(CTrakerView::IDD)
{
	//{{AFX_DATA_INIT(CTrakerView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here
	
	m_dlgCamTrackSetup = NULL;
}

CTrakerView::~CTrakerView()
{
	m_wndVideo->DestroyWindow();
	delete wndVideoObject; 
	
	m_dlgCamTrackSetup->DestroyWindow();
	delete m_dlgCamTrackSetup;
	//if(wndVideoObject != NULL)
	//{
	//	delete wndVideoObject;
	//}
}

void CTrakerView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTrakerView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BOOL CTrakerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CTrakerView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	// Set position of WndVideo
	CRect rectVideo;
	rectVideo.SetRect(VIDEO_X_COORD, VIDEO_Y_COORD, VIDEO_WIDTH, VIDEO_HEIGHT);
	
	m_wndVideo = new CWndVideo;
	wndVideoObject = m_wndVideo;
	m_wndVideo->Create(NULL, "Video", WS_CHILD  | WS_VISIBLE | WS_BORDER, rectVideo,
		this, NULL );

	// Set modaless dialog
	 if(m_dlgCamTrackSetup  == NULL)
	 {
		  m_dlgCamTrackSetup = new CDlgCamTrackSetup;                 
		  m_dlgCamTrackSetup->Create(IDD_DIALOG_SETUP);
		  m_dlgCamTrackSetup->ShowWindow(SW_SHOW);
		  
		  int ScrW, ScrH;
		  ScrW = ::GetSystemMetrics(SM_CXSCREEN);
		  ScrH = ::GetSystemMetrics(SM_CYSCREEN);
		  
		  CRect rect;
		  m_dlgCamTrackSetup->GetWindowRect(rect);

		  int DlgW, DlgH;
		  DlgW = rect.Width();
		  DlgH = rect.Height();

		  m_dlgCamTrackSetup->MoveWindow(ScrW - DlgW - 80, 75, DlgW, DlgH);  
	 }
	 else
	 {
		  m_dlgCamTrackSetup->SetFocus();
	 }

}

/////////////////////////////////////////////////////////////////////////////
// CTrakerView printing

BOOL CTrakerView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTrakerView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTrakerView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CTrakerView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
	
}

/////////////////////////////////////////////////////////////////////////////
// CTrakerView diagnostics

#ifdef _DEBUG
void CTrakerView::AssertValid() const
{
	CFormView::AssertValid();


}

void CTrakerView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CTrakerDoc* CTrakerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTrakerDoc)));
	return (CTrakerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTrakerView message handlers

void CTrakerView::StopWebCam()
{
	// At the end of development,the comment beyond this line sholud be unchecked to solve memory leak problem.
	// Another problem is come up debug assertion.
	//m_wndVideo->StopWebCam();
	TRACE("sdsdsdsdsds\n");
}

void CTrakerView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CFormView::OnPaint() for painting messages

	m_wndVideo->Invalidate();
}

void CTrakerView::SetZone()
{
//	this->SendMessage(MOTIONSETUP_EVENT);
	m_wndVideo->SetZone(true);
	
}

long CTrakerView::OnMotionSetup(WPARAM wParam, LPARAM lParam)
{
	
	m_wndVideo->SetZone(true);
	m_wndVideo->SetSMin(wParam);
	m_wndVideo->SetVMin(lParam);

	SetFocus();
	
	return 0;
}

long CTrakerView::OnMotionSetup2(WPARAM wParam, LPARAM lParam)
{
	m_wndVideo->SetVMax(wParam);
	return 0;
}

long CTrakerView::OnMotionSetup3(WPARAM wParam, LPARAM lParam)
{
	m_wndVideo->SetFaceDetected(wParam);
	return 0;
}
