// TrakerView.h : interface of the CTrakerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRAKERVIEW_H__23503FED_9D49_433A_B8C7_93754AF782CD__INCLUDED_)
#define AFX_TRAKERVIEW_H__23503FED_9D49_433A_B8C7_93754AF782CD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "WndVideo.h"
#include "DlgCamTrackSetup.h"



class CTrakerDoc;
class CTrakerView : public CFormView
{
protected: // create from serialization only
	CTrakerView();
	DECLARE_DYNCREATE(CTrakerView)

public:
	//{{AFX_DATA(CTrakerView)
	enum{ IDD = IDD_TRAKER_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CTrakerDoc* GetDocument();

// Operations
public:
	void StopWebCam();
	void SetZone();
protected:
	CDlgCamTrackSetup* m_dlgCamTrackSetup; // Set up cam and tracking option

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTrakerView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL
	afx_msg long OnMotionSetup(WPARAM wParam, LPARAM lParam);
	afx_msg long OnMotionSetup2(WPARAM wParam, LPARAM lParam);
	afx_msg long OnMotionSetup3(WPARAM wParam, LPARAM lParam);
public:
	CWndVideo* m_wndVideo;	// Show cam video

// Implementation
public:
	virtual ~CTrakerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTrakerView)
	afx_msg void OnPaint();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TrakerView.cpp
inline CTrakerDoc* CTrakerView::GetDocument()
   { return (CTrakerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRAKERVIEW_H__23503FED_9D49_433A_B8C7_93754AF782CD__INCLUDED_)
