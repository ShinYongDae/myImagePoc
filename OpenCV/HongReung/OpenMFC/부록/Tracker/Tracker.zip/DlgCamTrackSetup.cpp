// DlgCamTrackSetup.cpp : implementation file
//

#include "stdafx.h"
#include "Traker.h"
#include "DlgCamTrackSetup.h"
#include "TrakerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgCamTrackSetup dialog
#define VMIN_DEFAULT	10
#define VMAX_DEFAULT	256
#define SMIN_DEFAULT	50


#define CAMSIZE_AMOUNT 1
const CString strCamSize[CAMSIZE_AMOUNT] = {"640 X 480"};

class ValuesTrack
{
public:
	int smin;
	int vmin;
	int vmax;
};

CDlgCamTrackSetup::CDlgCamTrackSetup(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCamTrackSetup::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgCamTrackSetup)
	m_strSMin = _T("");
	m_strVMax = _T("");
	m_strVMin = _T("");
	//}}AFX_DATA_INIT

	m_bFaceDetected = false;
}


void CDlgCamTrackSetup::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgCamTrackSetup)
	DDX_Control(pDX, IDC_SLIDER_VMIN, m_slbVMin);
	DDX_Control(pDX, IDC_SLIDER_VMAX, m_slbVMax);
	DDX_Control(pDX, IDC_SLIDER_SMIN, m_slbSmin);
	DDX_Control(pDX, IDC_COMBO_CAMSIZE, m_comboCamSize);
	DDX_Text(pDX, IDC_STATIC_SMIN, m_strSMin);
	DDX_Text(pDX, IDC_STATIC_VMAX, m_strVMax);
	DDX_Text(pDX, IDC_STATIC_VMIN, m_strVMin);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgCamTrackSetup, CDialog)
	//{{AFX_MSG_MAP(CDlgCamTrackSetup)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_MOTIONSETUP, OnButtonMotionsetup)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_SMIN, OnReleasedcaptureSliderSmin)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_VMIN, OnReleasedcaptureSliderVmin)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_VMAX, OnReleasedcaptureSliderVmax)
	ON_BN_CLICKED(IDC_BUTTON_FACE, OnButtonFace)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCamTrackSetup message handlers

void CDlgCamTrackSetup::PostNcDestroy() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	
	CDialog::PostNcDestroy();
}

BOOL CDlgCamTrackSetup::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	for(int i=0; i<CAMSIZE_AMOUNT; i++)
	{
		m_comboCamSize.AddString(strCamSize[i]);
	}
	
	m_comboCamSize.SetCurSel(0);

	m_slbSmin.SetRange(0, 256);
	m_slbVMax.SetRange(0, 256);
	m_slbVMin.SetRange(0, 256);

	m_slbSmin.SetPos(SMIN_DEFAULT);
	m_slbVMax.SetPos(VMAX_DEFAULT);
	m_slbVMin.SetPos(VMIN_DEFAULT);

	m_strSMin.Format("%d", SMIN_DEFAULT);
	m_strVMin.Format("%d", VMIN_DEFAULT);
	m_strVMax.Format("%d", VMAX_DEFAULT);

	UpdateData(false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgCamTrackSetup::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CDialog::OnPaint() for painting messages
}

void CDlgCamTrackSetup::OnButtonMotionsetup() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	CTrakerView* pView = (CTrakerView*) ((CFrameWnd*)AfxGetApp()->GetMainWnd())->GetActiveView();

	pView->SendMessage(MOTIONSETUP_EVENT, m_slbSmin.GetPos(), m_slbVMin.GetPos());
	pView->SendMessage(MOTIONSETUP_EVENT2, m_slbVMax.GetPos());


}


void CDlgCamTrackSetup::OnReleasedcaptureSliderSmin(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int smin = m_slbSmin.GetPos();
	m_strSMin.Format("%d", smin);
	UpdateData(false);
	*pResult = 0;
}

void CDlgCamTrackSetup::OnReleasedcaptureSliderVmin(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int vmin = m_slbVMin.GetPos();
	m_strVMin.Format("%d", vmin);
	UpdateData(false);
	*pResult = 0;
}

void CDlgCamTrackSetup::OnReleasedcaptureSliderVmax(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int vmax = m_slbVMax.GetPos();
	m_strVMax.Format("%d", vmax);
	UpdateData(false);
	*pResult = 0;
}

void CDlgCamTrackSetup::OnButtonFace() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	CTrakerView* pView = (CTrakerView*) ((CFrameWnd*)AfxGetApp()->GetMainWnd())->GetActiveView();
	CButton *btn = (CButton *)this->GetDlgItem(IDC_BUTTON_FACE);
	
	if(!m_bFaceDetected){
		btn->SetWindowText(_T("�� �ν� ����"));
		m_bFaceDetected = true;
		pView->SendMessage(MOTIONSETUP_EVENT3, m_bFaceDetected);
	}
	else
	{
		btn->SetWindowText(_T("�� �ν� ����"));
		m_bFaceDetected = false;
		pView->SendMessage(MOTIONSETUP_EVENT3, m_bFaceDetected);
	}
}
