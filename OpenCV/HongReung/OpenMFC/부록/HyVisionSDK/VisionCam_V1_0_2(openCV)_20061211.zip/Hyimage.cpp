/********************************************************************************************
 * HyVISION USB2.0 VisionCAM
 * PURPOSE : Various Sensor Develop Platform.
 * FILE: Hyimage.CPP
		   - Dialog's main control Procedure (MainDlgProc).
		   - main function routine implemented.
 * MAJOR FUNCTION :
	  - MainDlgProc();
	  - OnPlay();
	  - OnStop();
	  - OnSnapshot();
	  - OnRegRead();
	  - OnRegWrite();
	  - YCbCrToBmp();/RawTobmp();
	  - SaveImageToBmpFile(); /SaveImageToRawFile();	  
	  - DisplayImage(); / DisplayImage2();
	  
 * Copyright (c) 2006 HyVISION SYSTEM Inc.  All right reserved.
 * AUTHOR	: OHSK. KIMSY
 * REV. HISTORY :
 *********************************************************************************************/
#include	<windows.h>
#include	<Commctrl.h>
#include	<stdio.h>
#include	<string.h>
#include	<TCHAR.h>
#include	<io.h>
#include	<direct.h>

#include	"HyCam.h"
#include	"resource.h"
#include	"hyimage.h"
#include	"HW_Init.h"
#include	"USB20Interface.h"
#include	"User_Control.h"



/*-----------------------------------------------------------------------------
   Global Variables
-----------------------------------------------------------------------------*/
HWND		ghwndDlg;
int			IMAGESIZE_X	= 640;
int			IMAGESIZE_Y	= 480;

BYTE		m_pBmpBuffer[2048*1536*3];
BYTE		m_pYCbCrBuffer[2048*1536*2];
BYTE		m_pYCbCrBuffer1[2048*1536*2];

BYTE		Rtbl[256][256];
BYTE		Gtbl[256][256][256];
BYTE		Btbl[256][256];
 
PlayMode	m_PlayMode;
HANDLE		hThreadData,hThreadDisplay;
DWORD		IDThreadData,IDThreadDisplay;
int			gCurrentSensorType=0;
HBITMAP		m_hbit;
BOOL		m_bMakeMemory;						//bitmap�� ����������� ����.

int			gBufferStatus=0;
int			b1stBuffer = FALSE;
int			gDrvIndex = 0;
int			FrameX,FrameY,Caption;				//window frame/ caption size
int			currentDevice;
static int	TriggerOn=0;


//////////////////////////////////////////////////////
// openCV
#include	<cv.h>
#include	<cxcore.h>
#include	<highgui.h>

CvvImage	m_CvvImage;
IplImage	*imgIntP, *imgGray, *imgCanny;
IplImage	*image;
RECT		m_rect;
CvHaarClassifierCascade *cascade;

IplImage	*imgTM1, *imgTM2;
char		targetfileName[MAX_PATH];
CvPoint		left_top;
BOOL		bTargetFile;
CvFont		font;
int			VideoCnt=0;
BOOL		bEnable=FALSE;
CvVideoWriter *VideoOut;

void	detectObjects(IplImage* image, CvHaarClassifierCascade* cascade);
void	TM_targetRectangle(IplImage *pRef);

IplImage	*hist_image;
CvHistogram *hist;
int			hist_size = 64;
float		range_0[]={0,256};
float		*ranges[] = { range_0 };

SENSOR_TYPE SensorType[] =
{
 
	0, "MT9T001[QXGA]",		MT9T001,  0x5d,	2048,	1536, RAW,GRBG,		BIT16,	//Micron 3M bayer
 	1, "MT9T001[UXGA]",		MT9T001,  0x5d,	1600,	1200, RAW,GRBG,		BIT16,	//Micron 2M bayer
 	2, "MT9T001[SXGA]",		MT9T001,  0x5d,	1280,	1024, RAW,GRBG,		BIT16,	//Micron 1.3M bayer
 	3, "MT9T001[XGA]",		MT9T001,  0x5d,	1024,	768,  RAW,GRBG,		BIT16,	//Micron 0.8M bayer
 	4, "MT9T001[VGA]",		MT9T001,  0x5d,	640,	480,  RAW,GRBG,		BIT16,	//Micron 0.3M bayer
 	
};

SENSOR_TYPE SensorType2[]=
{
 	0, "HV7131R[VGA]",		HV7131R, 0x11,	640,	480,  1, RGGB,		BIT8,	//MagnaChip VGA
	1, "HV7131R[QVGA]",		HV7131R, 0x11,	320,	240,  1, RGGB,		BIT8,	//MagnaChip QVGA
};

BOOL CALLBACK MainDlgProc(HWND hDlg, UINT msg, UINT wParam, LONG lParam)
{
  	PAINTSTRUCT		ps;
    static HBRUSH   MyBrush;
	HDC				hdc;
 	char			regfileName[MAX_PATH];
	int				i;
 	int				nDrvNum;
	int				nDrvInform[6];
	char			buf[10];				// txtbuf[30];

 	LPSTR			lpAppName = "HVS_VISIONCAM";
	char			filedir[MAX_PATH]={0};
	char			buf_mode[4][5]={0};
	
	ghwndDlg = hDlg;
	
	switch (msg)
	{
	   case WM_INITDIALOG:
		   	TriggerOn=0;
		    MyBrush = CreateSolidBrush(RGB(83,113,168));
			m_PlayMode = STOP;
			currentDevice = -1;
//			gCurrentSensorType  = 0;  //initial mode
			
 			FrameX = GetSystemMetrics(SM_CXFIXEDFRAME);
			FrameY = GetSystemMetrics(SM_CYFIXEDFRAME);
			Caption = GetSystemMetrics(SM_CYCAPTION);
			
			for (i=0; i<6; i++) nDrvInform[i] = 0; //init
 			nDrvNum = HW_InitCam(&nDrvInform[0]);
  			myDelay(3000); 
			_getcwd(rootdir, MAX_PATH);
			if (nDrvNum==0) {
				ShowWindow(GetDlgItem(hDlg,IDC_PLAY),SW_HIDE);
				ShowWindow(GetDlgItem(hDlg,IDC_STOP),SW_HIDE);
			}
			else {
				ListOut(ghwndDlg, "No. of Camera#:%d", nDrvNum);
				for (i=0; i<nDrvNum; i++) {
					ListOut(ghwndDlg, "ID:%d::%x", i, nDrvInform[i]);
				}
			}	
			for(i=0; i<nDrvNum; i++) {
				wsprintf(buf, "%d", i);
				SendDlgItemMessage(hDlg, IDC_INDEX, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)buf);
			} 
			if(nDrvNum==0){
				MessageBox(hDlg, "Check up, USB port", "No connect", MB_OK|MB_ICONINFORMATION);
				SendMessage(gSplashDlg,WM_CLOSE,0,0);
				SendMessage(ghwndApp, WM_CLOSE, 0, 0);
				return 0;
			}
			SendDlgItemMessage(hDlg, IDC_INDEX, CB_SETCURSEL, 0, 0L);
			SetClassLong (hDlg, GCL_HICON, (LONG) LoadIcon (ghInstApp, MAKEINTRESOURCE(IDI_HVS)));
 			  // Driver refresh delay time
			currentDevice = SensorRecognition(gDrvIndex);
			if(currentDevice == -1){
				MessageBox(hDlg, "Check up, Sensor", "No Sensor", MB_OK|MB_ICONINFORMATION);
				SendMessage(gSplashDlg,WM_CLOSE,0,0);
			 	SendMessage(ghwndApp, WM_CLOSE, 0, 0);
			 	return 0;
			}
			else if(currentDevice == MT9T001){
 				for (i=0; i<NUM_SENSOR_TYPE; i++) {
					SendDlgItemMessage(hDlg, IDC_SENSOR_TYPE, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)SensorType[i].szSensorString);
				}
				if(SensorType[gCurrentSensorType].IICMode== BIT16)
					SendMessage( GetDlgItem(hDlg, IDC_IIC_WIDTH), BM_SETCHECK, BST_CHECKED, 0);
				
			}
			else {
				for (i=0; i<NUM_SENSOR_TYPE2; i++) {
					SendDlgItemMessage(hDlg, IDC_SENSOR_TYPE, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)SensorType2[i].szSensorString);
				}
				if(SensorType2[gCurrentSensorType].IICMode== BIT16)
					SendMessage( GetDlgItem(hDlg, IDC_IIC_WIDTH), BM_SETCHECK, BST_CHECKED, 0);
			}
 
			if(!Trig_Read(gDrvIndex)){
				MessageBox(hDlg, "Check up, Triger", "Triger is low", MB_OK|MB_ICONINFORMATION);
				SendMessage(gSplashDlg,WM_CLOSE,0,0);
				SendMessage(ghwndApp, WM_CLOSE, 0, 0);
				return 0;
			}			
 
			SendDlgItemMessage(hDlg, IDC_SENSOR_TYPE, CB_SETCURSEL, gCurrentSensorType, 0L); //init Mode
  			SendMessage( GetDlgItem(hDlg, IDC_INTERPOLATION), BM_SETCHECK, BST_CHECKED, 0);
 			if(Fitmode==1)SendMessage( GetDlgItem(hDlg, IDC_PREVIEW_MODE), BM_SETCHECK, BST_CHECKED, 0);
		
			SetDlgItemFloat(hDlg, IDC_DISPLAY_FRAMERATE,0);
			SetDlgItemText(hDlg, IDC_INDEX, "0");
			
			EnableWindow(GetDlgItem(ghwndDlg, IDC_STOP), FALSE);
			EnableWindow(GetDlgItem(ghwndDlg, IDC_SNAPSHOT), FALSE);
			MoveWindow(ghwndApp, 0, 0,ResolutionX, ResolutionY, TRUE);
			LED_OnOff(1, gDrvIndex);
 			SendMessage(gSplashDlg,WM_CLOSE,0,0);

			/////////////////////////////////////////
			// openCV
			INIReadStringVision("HVS_OPENCV","OPENCV_ONOFF","0",buf,10);
			sscanf(buf, "%d", &gOpenCV);	
 			INIReadStringVision("HVS_OPENCV","OPENCV_GRAY","0",buf,10);
			sscanf(buf, "%d", &gGRAY);	
 			INIReadStringVision("HVS_OPENCV","OPENCV_GRAY_HISTO","0",buf,10);
			sscanf(buf, "%d", &gGRAYhisto);	
 			INIReadStringVision("HVS_OPENCV","OPENCV_BLUR","0",buf,10);
			sscanf(buf, "%d", &gBLUR);	
 			INIReadStringVision("HVS_OPENCV","OPENCV_CANNY","0",buf,10);
			sscanf(buf, "%d", &gCANNY);	
			INIReadStringVision("HVS_OPENCV","OPENCV_FACEDETECTION","0",buf,10);
			sscanf(buf, "%d", &gFACEDETECTION);	
			INIReadStringVision("HVS_OPENCV","OPENCV_T_MATCHING","0",buf,10);
			sscanf(buf, "%d", &gTMATCHING);
			memset(targetfileName, NULL, sizeof(targetfileName));
			bTargetFile=FALSE;

			gAVI=FALSE;

			cascade=(CvHaarClassifierCascade*)cvLoad("haarcascade_frontalface_default.xml");

			break;

	   case WM_COMMAND:
	      switch (LOWORD(wParam))
		  {
		
			 case IDC_SENSOR_TYPE:
				  if (CBN_SELCHANGE == HIWORD(wParam)) {
					  gCurrentSensorType = SendDlgItemMessage(hDlg, IDC_SENSOR_TYPE, CB_GETCURSEL, 0, 0L);

					  wsprintf(buf_mode[gDrvIndex],"%d",gCurrentSensorType); //limit
					  wsprintf(filedir, "VISION%d_Select", gDrvIndex);
					  INIWriteStringVision(lpAppName,filedir,buf_mode[gDrvIndex]);
 					  if(currentDevice == MT9T001 ){
						 
						  IMAGESIZE_X =SensorType[gCurrentSensorType].nDisplayX;
						  IMAGESIZE_Y =SensorType[gCurrentSensorType].nDisplayY;
					  }
					  else {
						  
						  IMAGESIZE_X =SensorType2[gCurrentSensorType].nDisplayX;
						  IMAGESIZE_Y =SensorType2[gCurrentSensorType].nDisplayY;
					  }
  					  SendMessage(ghwndDlg, WM_COMMAND, IDC_INTERPOLATION, 0);
					  SendMessage(ghwndDlg, WM_COMMAND, IDC_PREVIEW_MODE, 0);
				  }
				  break;
 
			 case IDC_PLAY:
				  OnPlay(hDlg);
				  break;

			 case IDC_STOP:
				  OnStop(hDlg);
				  break;

			 case IDC_SNAPSHOT:
				  OnSnapshot(hDlg);
				  break;

			 case IDC_REGREAD:
				  OnRegRead(hDlg);
				  break;
			 case IDC_REGWRITE:
				  OnRegWrite(hDlg);
 				  break;
 			 case IDC_IIC_WIDTH:
				  OnIICWidth(hDlg);
				  break;
			 case IDC_INDEX:
				 if(CBN_SELCHANGE == HIWORD(wParam))
				 {
					 gDrvIndex = SendDlgItemMessage(hDlg, IDC_INDEX, CB_GETCURSEL, 0, 0L);
					 if(currentDevice == MT9T001 ){
						 for (i=0; i<NUM_SENSOR_TYPE; i++) {
							 SendDlgItemMessage(hDlg, IDC_SENSOR_TYPE, CB_DELETESTRING, 0, (LPARAM) (LPCTSTR)SensorType[i].szSensorString);
						 }
					 }
					 else {
						 for (i=0; i<NUM_SENSOR_TYPE; i++) {
							 SendDlgItemMessage(hDlg, IDC_SENSOR_TYPE, CB_DELETESTRING, 0, (LPARAM) (LPCTSTR)SensorType2[i].szSensorString);
						 }
					 }
 					 currentDevice=SensorRecognition(gDrvIndex);
					 if(currentDevice == MT9T001 ){
 
					for (i=0; i<NUM_SENSOR_TYPE; i++) {
							 SendDlgItemMessage(hDlg, IDC_SENSOR_TYPE, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)SensorType[i].szSensorString);
						 }
 						 IMAGESIZE_X = SensorType[gCurrentSensorType].nDisplayX;
						 IMAGESIZE_Y = SensorType[gCurrentSensorType].nDisplayY;
					 }
					 else {
 						 for (i=0; i<NUM_SENSOR_TYPE2; i++) {
							 SendDlgItemMessage(hDlg, IDC_SENSOR_TYPE, CB_ADDSTRING, 0, (LPARAM) (LPCTSTR)SensorType2[i].szSensorString);
						 }
						 IMAGESIZE_X = SensorType2[gCurrentSensorType].nDisplayX;
						 IMAGESIZE_Y = SensorType2[gCurrentSensorType].nDisplayY;
						 
					 }
					 SendDlgItemMessage(hDlg, IDC_SENSOR_TYPE, CB_SETCURSEL, gCurrentSensorType, 0L); //init Mode
					 SendMessage(ghwndDlg, WM_COMMAND, IDC_PREVIEW_MODE, 0);
				 }
 				 break;
			 case IDC_SETREGFILE:
				  if(!SetRegFile(hDlg, regfileName)) break;

				  if (PLAY == m_PlayMode) ParseRegisterFile(regfileName); //.set format
				  break;
			 case IDC_INTERPOLATION:
				 OnInterpolation(hDlg);
				 break;

			 case IDC_PREVIEW_MODE:
				 OnDisplayMode(hDlg);
 				 break;
 			 case IDC_CLEARLOG:
				  OnClearLog(hDlg);
				  break;
			 case IDC_AE_CONTROL:
 
				 if(currentDevice == MT9T001 ){
					if(!IsWindow(gMironAeDlg))
						CreateDialog(ghInstApp, MAKEINTRESOURCE(IDD_AE_CONTROL),ghwndApp,(DLGPROC)ControlDlgProc);
				 }
				 else{
					 if(!IsWindow(gMagnaAeDlg))
						 CreateDialog(ghInstApp, MAKEINTRESOURCE(IDD_AE_CONTROL2),ghwndApp,(DLGPROC)ControlDlgProc2);
				 }
 
				 break;

			 case IDC_OPENCV_PROCESS:

				 if(!IsWindow(gOpenCVDlg))
						CreateDialog(ghInstApp, MAKEINTRESOURCE(IDD_OPENCV_DLG),ghwndApp,(DLGPROC)OpenCVDlgProc);

				 break;

			 case IDC_LED_ON:
				 LED_OnOff(0, gDrvIndex);
 				 break;
			 case IDC_LED_OFF:
				 LED_OnOff(1, gDrvIndex);
 				 break;
				 
 		 break;
		  } //switch (LOWORD(wParam))
		  break;
	  // Main dialog's bmp 
	   case	WM_PAINT:
			hdc = BeginPaint(hDlg, &ps);
 			Draw(hdc,IDB_HYVISIONDLGV2_BMP, 0, 0, 0, 0, 246,600);
			EndPaint (hDlg, &ps);
			return 0;
			
	   // Main dialog's text color 
	   case	WM_CTLCOLORSTATIC:
			{
				 HWND hTemp = (HWND)lParam;
				 if (hTemp == GetDlgItem(hDlg,IDC_STATIC1)||hTemp == GetDlgItem(hDlg,IDC_STATIC2)
					   ||hTemp == GetDlgItem(hDlg,IDC_STATIC11)||hTemp == GetDlgItem(hDlg,IDC_STATIC12)
				       ||hTemp == GetDlgItem(hDlg,IDC_STATIC3)||hTemp == GetDlgItem(hDlg,IDC_STATIC4)
					   ||hTemp == GetDlgItem(hDlg,IDC_STATIC5)||hTemp == GetDlgItem(hDlg,IDC_STATIC6)				       
					   ||hTemp == GetDlgItem(hDlg,IDC_STATIC7)||hTemp == GetDlgItem(hDlg,IDC_STATIC8)				       
					   ||hTemp == GetDlgItem(hDlg,IDC_STATIC9)||hTemp == GetDlgItem(hDlg,IDC_STATIC10)
					   ||hTemp == GetDlgItem(hDlg,IDC_STATIC_SENSOR)||hTemp ==GetDlgItem(hDlg,IDC_STATICFRAM)
					   ||hTemp == GetDlgItem(hDlg,IDC_STATICFS) || hTemp == GetDlgItem(hDlg,IDC_IIC_WIDTH)
					   ||hTemp == GetDlgItem(hDlg,IDC_IIC_SELECT)||hTemp == GetDlgItem(hDlg,IDC_STATIC_INTERPOLATION)
					   ||hTemp == GetDlgItem(hDlg,IDC_STATIC_INTERPOLATION2) ||hTemp == GetDlgItem(hDlg,IDC_STATIC_FIT)
					   ||hTemp == GetDlgItem(hDlg,IDC_STATIC_CAM)|| hTemp == GetDlgItem(hDlg,IDC_STATIC_LED)
					)
				 {
					SetTextColor((HDC)wParam, RGB(255,255,255) );
					SetBkColor((HDC)wParam, RGB(83,113,168) );
					return (LRESULT)MyBrush;
				 }
				 return (DefWindowProc(hDlg, msg, wParam, lParam));
			}
	
	   case	WM_CLOSE:
		    
			SendMessage(ghwndApp, WM_CLOSE, 0, 0);
			return 0;
	
	   default:
	      return FALSE;
	}	//switch (msg)
    return TRUE;
}
 
/**************************************************************************************************
* void 	OnPlay(HWND hDlg)
* Description:
*       When PLAY button click, Sensor's initial set(register...)and Image display
* Inputs:
*      hDlg    : Dialog's handle
**************************************************************************************************/
void OnPlay(HWND hDlg)
{
//	BYTE		tmpData;
	int			Selection=0;
	
	if (STOP == m_PlayMode) {
		EnableWindow(GetDlgItem(ghwndDlg, IDC_STOP), FALSE);
		OnGetIndex(hDlg);
 		myDelay(300);//500

		if(currentDevice ==MT9T001 ){
			IMAGESIZE_X = SensorType[gCurrentSensorType].nDisplayX;
			IMAGESIZE_Y = SensorType[gCurrentSensorType].nDisplayY;
			SensorRegInit(SensorType[gCurrentSensorType].SensorID, IMAGESIZE_X);
		}
		else{
			IMAGESIZE_X = SensorType2[gCurrentSensorType].nDisplayX;
			IMAGESIZE_Y = SensorType2[gCurrentSensorType].nDisplayY;
			SensorRegInit(SensorType2[gCurrentSensorType].SensorID, IMAGESIZE_X);
		}

	 	Read_User_Control_Set();
		
		////////////////////////////////////////////////////////////////////
		SendDlgItemMessage(hDlg, IDC_SENSOR_TYPE, CB_SETCURSEL, gCurrentSensorType, 0L); // Change Video Mode Selection
		PostMessage(hDlg, WM_COMMAND, MAKEWPARAM(IDC_SENSOR_TYPE, CBN_SELCHANGE), 0L); // Notify change

		//////////////////////////////////////////////////////
		// openCV
		cvReleaseImage(&image);
		cvReleaseImage(&imgIntP);
		cvReleaseImage(&imgGray);
		cvReleaseImage(&imgCanny);

		cvReleaseImage(&hist_image);
		cvReleaseHist(&hist);
						
		image = cvCreateImage(cvSize(IMAGESIZE_X,IMAGESIZE_Y),IPL_DEPTH_8U,1);
		imgIntP = cvCreateImage( cvGetSize(image), IPL_DEPTH_8U, 3);
		imgGray = cvCreateImage( cvGetSize(image), IPL_DEPTH_8U, 1);
		imgCanny = cvCreateImage( cvGetSize(image), IPL_DEPTH_8U, 1);

		hist_image = cvCreateImage(cvSize(320,200), 8, 1);
		hist = cvCreateHist(1, &hist_size, CV_HIST_ARRAY, ranges, 1);

		myDelay(100);
 		ListOut(ghwndDlg,"Play");
		myDelay(100);
		m_PlayMode = PLAY;
		TriggerOn=0;

 	 	MakeThread(); //new make every play	
 		
		///////////////////////////////////
 		EnableWindow(GetDlgItem(ghwndDlg, IDC_SENSOR_TYPE), FALSE);
		EnableWindow(GetDlgItem(ghwndDlg, IDC_INDEX), FALSE);
		EnableWindow(GetDlgItem(ghwndDlg, IDC_PLAY), FALSE);
		EnableWindow(GetDlgItem(ghwndDlg, IDC_STOP), TRUE);
		EnableWindow(GetDlgItem(ghwndDlg, IDC_SNAPSHOT), TRUE);
	}
}
/**************************************************************************************************
* void	OnStop(HWND hDlg)
* Description:
*       When STOP button click, stop to image display
* Inputs:
*      hDlg    : Dialog's handle
**************************************************************************************************/
void deleteDetection()
{
	cvReleaseHaarClassifierCascade(&cascade);
}

BOOL TM_targetFile()
{
	if(!SetRegFile2(targetfileName)) return FALSE;

	if(imgTM1!=NULL) cvReleaseImage(&imgTM1);
	imgTM1 = cvLoadImage(targetfileName, -1);

	return TRUE;
}

void TM_targetRectangle(IplImage *pRef)
{
	double min, max;

	if(imgTM2!=NULL) cvReleaseImage(&imgTM2);
	imgTM2 = cvCreateImage( cvSize( pRef->width - imgTM1->width+1, pRef->height - imgTM1->height+1 ), IPL_DEPTH_32F, 1);

	cvMatchTemplate(pRef, imgTM1, imgTM2, CV_TM_CCOEFF_NORMED); // �������� ���Ͽ� C �� �׸���.
	cvMinMaxLoc(imgTM2, &min, &max, NULL, &left_top); 

	char tmp[128];
	sprintf(tmp, "min=%.2f, max=%.2f, x=%d, y=%d", min, max, left_top.x, left_top.y);
	ListOut(ghwndDlg,tmp);
}

void OnStop(HWND hDlg)
{
	if(m_PlayMode == STOP) return;
	
	EnableWindow(GetDlgItem(ghwndDlg, IDC_PLAY), FALSE);
	EnableWindow(GetDlgItem(ghwndDlg, IDC_SNAPSHOT), FALSE);
	EnableWindow(GetDlgItem(ghwndDlg, IDC_STOP), FALSE);
	m_PlayMode = STOP;
	Sleep(500);
//	CLK24M_OUT (gDrvIndex);

	//////////////////////////////////////////////////////
	// openCV
	if(gOpenCV){
		cvConvertImage(m_CvvImage.GetImage(), m_CvvImage.GetImage(), CV_CVTIMG_FLIP);
		memcpy(m_pBmpBuffer, (BYTE*)m_CvvImage.GetImage()->imageData, m_CvvImage.GetImage()->imageSize);//IMAGESIZE_X*IMAGESIZE_Y*3);
	}
		
	SetDlgItemFloat(hDlg, IDC_DISPLAY_FRAMERATE,0);
	EnableWindow(GetDlgItem(ghwndDlg, IDC_SENSOR_TYPE), TRUE);
 	EnableWindow(GetDlgItem(ghwndDlg, IDC_PLAY), TRUE);
	EnableWindow(GetDlgItem(ghwndDlg, IDC_INDEX), TRUE);

	ListOut(ghwndDlg,"Stop");
	
}
/**************************************************************************************************
* void	OnSnapshot(HWND hDlg)
* Description:
*       When SNAPSHOT button click, image save to bmp file.
* Inputs:
*      hDlg    : Dialog's handle
**************************************************************************************************/
void OnSnapshot(HWND hDlg)
{
	if(m_PlayMode == PAUSE) return;
	
 	if (m_PlayMode != STOP) {
		if(TriggerOn == 1){

			// trigger on
			if (m_PlayMode != PAUSE) {
				SuspendThread(hThreadData);
				SuspendThread(hThreadDisplay);
			} 
			m_PlayMode = PAUSE;

			myDelay(300);
			if(!gOpenCV){
				SaveImageToBmpFile();
			}else{
				SaveImageFileByOpenCV();
			}
			myDelay(300);

			m_PlayMode = PLAY;
			ResumeThread(hThreadData);
			ResumeThread(hThreadDisplay);
		}
		else {
			//snapshot click
			if (m_PlayMode != PAUSE) {

				SuspendThread(hThreadData);
				SuspendThread(hThreadDisplay);
			} 
			m_PlayMode = PAUSE;

			myDelay(300);
			if(!gOpenCV){
				SaveImageToBmpFile();
			}else{
				SaveImageFileByOpenCV();
			}
			myDelay(300);

			m_PlayMode = PLAY;
			ResumeThread(hThreadData);
			ResumeThread(hThreadDisplay);

		}
	}
 

}
/**************************************************************************************************
* void	ListOut(HWND hDlg, LPCSTR format,...)
* Description:
*      Print out of dialog's list box
* Inputs:
*      hDlg    : Dialog's handle
*	   format  : such as 'printf' function.
**************************************************************************************************/
void ListOut(HWND hDlg, LPCSTR format,...)
{
	static int iIndex;

	char szMes[80];
	va_list args;
	va_start(args,format);
	vsprintf(szMes,format,args); //%f���� �ޱ� ���ؼ��� �̰��� ����ؾ� ��
	iIndex = SendDlgItemMessage(hDlg, IDC_LOG, LB_ADDSTRING, 0, (LPARAM) szMes);
 	SendDlgItemMessage(hDlg, IDC_LOG, LB_SETCURSEL, iIndex, 0);
	va_end(args);
}
/**************************************************************************************************
* void	OnClearLog(HWND hDlg)
* Description:
*      Dialog's list box clear.
* Inputs:
*      hDlg    : Dialog's handle
**************************************************************************************************/
void   OnClearLog(HWND hDlg)
{
	SendDlgItemMessage(hDlg, IDC_LOG, LB_RESETCONTENT, 0, 0);
}
/**************************************************************************************************
* void	myDelay(DWORD millisec)
* Description:
*      Delay time insert.
* Inputs:
*      millisec   : wanted time with millisecond
**************************************************************************************************/
void myDelay(DWORD millisec)
{
    DWORD tmp;
	
    tmp = GetTickCount();
    while (GetTickCount() < tmp + millisec);
}
/**************************************************************************************************
* void	OnIICWidth(HWND hDlg)
* Description:
*      I2C mode change
* Inputs:
*      hDlg    : handle
**************************************************************************************************/
void OnIICWidth(HWND hDlg)
{
	if (BST_CHECKED == SendDlgItemMessage(hDlg, IDC_IIC_WIDTH, BM_GETCHECK, 0, 0)) {  //if check
		SensorType[gCurrentSensorType].IICMode = BIT16;
	}
	else {
		SensorType[gCurrentSensorType].IICMode= BIT8;
	}
}
/**************************************************************************************************
* void			OnRegWrite(HWND hDlg)
* Description:
*      When Write button click on dialog ,I2C write
* Inputs:
*      hDlg    : handle
**************************************************************************************************/
void OnRegWrite(HWND hDlg)
{
	WORD	wRegData;
	WORD	wRegAddr;
	TCHAR	szRegAddr[25];
	TCHAR	szRegData[25];
	BOOL	writeflag;
	
	GetDlgItemText(hDlg, IDC_REGADDR, szRegAddr, 10);
	_stscanf(szRegAddr, "%x", &wRegAddr);
	GetDlgItemText(hDlg, IDC_REGDATA, szRegData, 10);
	_stscanf(szRegData, "%x", &wRegData);
	if(currentDevice == MT9T001 )
		writeflag=IIC_Write_Proc(SensorType[gCurrentSensorType].IICMode, wRegAddr, wRegData);
	else 
		writeflag=IIC_Write_Proc(SensorType2[gCurrentSensorType].IICMode, wRegAddr, wRegData);
	
}
/**************************************************************************************************
* void			OnRegRead(HWND hDlg)
* Description:
*      When Read button click on dialog ,I2C read
* Inputs:
*      hDlg    : handle
**************************************************************************************************/
void OnRegRead(HWND hDlg)
{
	WORD	wregData;
	WORD	wRegAddr;
	TCHAR	szRegAddr[25];
	TCHAR	szRegData[25];
	
	GetDlgItemText(hDlg, IDC_REGADDR, szRegAddr, 10);
	_stscanf(szRegAddr, "%x", &wRegAddr);
	if(currentDevice == MT9T001 )
	wregData = IIC_Read_Proc(SensorType[gCurrentSensorType].IICMode, wRegAddr);
	else 
	wregData = IIC_Read_Proc(SensorType2[gCurrentSensorType].IICMode, wRegAddr);

	_stprintf(szRegData, "%x", wregData);
	SetDlgItemText(hDlg, IDC_REGDATA, szRegData);
 
}
/**************************************************************************************************
* BOOL			IIC_Write_Proc(int mode, WORD wRegAddr, WORD wRegData)
* Description:
*      write byte data from I2C device
* Inputs:
*      mode		   :  I2C mode : 8it / 16bit
*      wRegAddr    :   Address
*	   wRegData    :   Data to be write
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL	IIC_Write_Proc(int mode, WORD wRegAddr, WORD wRegData)
{
	BOOL flagTF;
	if (BIT8 == mode) {
		flagTF=	IIC_Write(wRegAddr, wRegData, gDrvIndex);
	}
	else if (BIT16 == mode) {
		flagTF=IIC_Write16(wRegAddr, wRegData, gDrvIndex);
	}
	
	return flagTF;
}
/**************************************************************************************************
* WORD			IIC_Read_Proc(int mode, WORD wRegAddr)
* Description:
*      Read byte data from I2C device
* Inputs:
*      mode		   :  I2C mode : 8it / 16bit
*      wRegAddr    :   Address
* Return:
*      WORD		   :  Data read
**************************************************************************************************/
WORD		IIC_Read_Proc(int mode, WORD wRegAddr)
{
	WORD	wRegData = 0;
	if ( BIT8 == mode) {
		wRegData = IIC_Read(wRegAddr, gDrvIndex);
	}
	else if ( BIT16== mode) {
		wRegData = (WORD)IIC_Read16(wRegAddr, gDrvIndex);
	}
	
	return wRegData;
}

/**************************************************************************************************
* BOOL			SetRegFile(HWND hDlg, char *filename)
* Description:
*      Select register file(file format is "*.set") on window dialog 
* Inputs:
*      hDlg		   :   handle
*      filename    :   selected file's name.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL SetRegFile(HWND hDlg, char *filename)
{
 	char	file_name[MAX_PATH]= {0};
	char	path_buffer[_MAX_PATH]={0};
	char	drive[_MAX_DRIVE]={0};
	char	dir[_MAX_DIR]={0};
	char	fname[_MAX_FNAME]={0};
	char	ext[_MAX_EXT]={0};
	
	OPENFILENAME	 SFN;
	memset(&SFN, 0, sizeof(OPENFILENAME));
	SFN.lStructSize = sizeof(OPENFILENAME);
	SFN.hwndOwner = ghwndApp;
	SFN.lpstrFilter = "Set File(*.set)\0*.set\0";
	SFN.lpstrFile = file_name;
	SFN.nMaxFile = MAX_PATH;
 			
	if (!GetOpenFileName(&SFN))	return FALSE;
 	_splitpath(file_name, drive, dir, fname, ext);
	if (strlen(fname) == 0) {
		MessageBox(hDlg, "File Open Error", "File open", MB_OK);
		return FALSE;
	}
	if (strcmp(ext, ".set")!=0 || strcmp(ext,".SET")!=0) {
		MessageBox(hDlg, "File Open Error", "File open", MB_OK);
	}
 	sprintf(filename, "%s%s%s%s", drive, dir, fname, ext);
	return TRUE;
}

BOOL SetRegFile2(char *filename)
{
	char		lpstrFile[MAX_PATH]=" ";
	char		szFileTitle[MAX_PATH]=" ";
	
	OPENFILENAME	 OFN;
	memset(&OFN, 0, sizeof(OPENFILENAME));
	OFN.lStructSize = sizeof(OPENFILENAME);
	OFN.hwndOwner=ghwndApp;
	OFN.lpstrFilter="BMP files(*.bmp)\0*.bmp\0��� ����(*.*)\0*.*\0";
	OFN.lpstrFile=lpstrFile;
	OFN.nMaxFile=MAX_PATH;
	OFN.lpstrTitle="Optic Spec ������ �����Ͻʽÿ�";
	OFN.lpstrFileTitle=szFileTitle;
	OFN.nMaxFileTitle=MAX_PATH;

	if (GetOpenFileName(&OFN)!=0) {
		
		int a;
		a=strlen(szFileTitle); // MakeUpper �Լ� ����..
		
		if(szFileTitle[a-3]=='b' && szFileTitle[a-2]=='m' && szFileTitle[a-1]=='p')
		{
			strcpy(filename, lpstrFile);
			return 1;
		}else if(szFileTitle[a-3]=='B' && szFileTitle[a-2]=='M' && szFileTitle[a-1]=='P')
		{
			strcpy(filename, lpstrFile);
			return 1;
		}
		if(szFileTitle[a-3]=='j' && szFileTitle[a-2]=='p' && szFileTitle[a-1]=='g')
		{
			strcpy(filename, lpstrFile);
			return 1;
		}else if(szFileTitle[a-3]=='J' && szFileTitle[a-2]=='P' && szFileTitle[a-1]=='G')
		{
			strcpy(filename, lpstrFile);
			return 1;
		}

		MessageBox(NULL, "File Open Error", "File open", MB_OK);
							
	}
	return 0;
}

/**************************************************************************************************
* BOOL			ParseRegisterFile(char *filename)
* Description:
*		Write to register file(file format is "*.set") with I2C commnand
* Inputs:
*      hDlg		   :   handle
*      filename    :   set file's name.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL	ParseRegisterFile(char *filename)
{
	FILE		*fp;
	WORD		wRegAddr, wRegData;
	char		linebufIn[MAXSTR];
	
	if ((fp = fopen(filename,"r")) == NULL) {
		return FALSE;
	}
	//add  "     "
	memset(linebufIn, 0, MAXSTR);
	while (fgets(linebufIn, MAXSTR, fp))
	{
		if (linebufIn[0] == '0' && (linebufIn[1] == 'x' || linebufIn[1] == 'X')) {
			sscanf(linebufIn,"%x%x",&wRegAddr,&wRegData);
			if(currentDevice ==MT9T001 )
				IIC_Write_Proc(SensorType[gCurrentSensorType].IICMode, wRegAddr, wRegData);
			else
				IIC_Write_Proc(SensorType2[gCurrentSensorType].IICMode, wRegAddr, wRegData);
			myDelay(3);
		}
		memset(linebufIn, 0, MAXSTR);
	}
	fclose(fp);
	return TRUE;
}

/**************************************************************************************************
* BOOL			ParseRegisterFileBoard(char *filename)
* Description:
*		Write to ini file(file format is "*.set") with I2C commnand
* Inputs:
*      filename    :   set file's name.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/

BOOL	ParseRegisterFileBoard(char *filename)
{
	FILE		*fp;
	WORD		wRegAddr, wRegData;
	char		linebufIn[500];//[MAXSTR];
	char		tmp_cmd[50]={0};
	char		tmp_data[50]={0};
	int			tmp_idata=0;
	BOOL		bwrite_start=FALSE;
	int			SleepTime= 20;
	char		filedir[40]={0};
	
	if(currentDevice == MT9T001)
		wsprintf(filedir, "[HVS_VISION%d_MT9T001]", gDrvIndex);
	else 
		wsprintf(filedir, "[HVS_VISION%d_HV7131R]", gDrvIndex);
		

	if ((fp = fopen(filename,"r")) == NULL) {
		return FALSE;
	}
	//add  "     "
	memset(linebufIn, 0, 500); //MAXSTR);
	while (NULL != fgets(linebufIn, 500, fp)) //MAXSTR
	{
		sscanf(linebufIn,"%s",tmp_cmd);
		
		if(0 == strcmp( filedir , tmp_cmd)) //mode
		{
			if(!bwrite_start) bwrite_start = TRUE;
		}
		else if(0 == strcmp("[END]", tmp_cmd) && bwrite_start == TRUE)
		{
			bwrite_start = FALSE;
			break;
		}
		if(TRUE == bwrite_start)
		{	
			if (linebufIn[0] == '0' && (linebufIn[1] == 'x' || linebufIn[1] == 'X')) {
				sscanf(linebufIn,"%x%x",&wRegAddr,&wRegData);
				if(currentDevice ==MT9T001 )
					IIC_Write_Proc(SensorType[gCurrentSensorType].IICMode, wRegAddr, wRegData);
				else
					IIC_Write_Proc(SensorType2[gCurrentSensorType].IICMode, wRegAddr, wRegData);
				myDelay(3);
			}
 		 
 			memset(linebufIn, 0, strlen(linebufIn));
		}//end bWrite
	}
	fclose(fp);
	return TRUE;/**/
	
}
/**************************************************************************************************
* BOOL			RawToBmp(BYTE *pDataBuffer)
* Description:
*		 Convert sensor's Bayer data to BMP format data.
*		 Implemented 3x3 Interpolation data
*
*		 :Assume Sensor's first data is variable
*		-example (BGGR order) 
*			(first)	B G B G B G ... B G B G
*					G R G R G R ... G R G R
*						...
*
*					B G B G B G ... B G B G
*			tmp2 -> G R G R G R ... G R G R
*			tmp1 -> B G B G B G ... B G B G
*			tmp  -> G R G R G R ... G R G R  (end)
* Inputs:
*      pDataBuffer :   Input buffer (raw data)
* Outputs:
*      m_pBmpBuffer :  Output buffer : Global variable.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
extern void RawToBmp(BYTE *pDataBuffer)

{ 
	LPBYTE		pBmpBuffer, pImageData, pImageTemp, pImageTemp1, pImageTemp2;
	BYTE		r, g, b, Y;
	int			i, j;
 	
	pBmpBuffer = m_pBmpBuffer;
	pImageData = pDataBuffer + IMAGESIZE_X*(IMAGESIZE_Y-1);
	
	switch(SensorType[gCurrentSensorType].OutMode) {
		
	case BlackWhite:
		for (i=0; i<IMAGESIZE_Y-2; i+=2) {
			pImageTemp = pImageData;						
			pImageTemp1 = pImageData - IMAGESIZE_X;		
			pImageTemp2 = pImageData - IMAGESIZE_X*2;
			for (j=0; j<IMAGESIZE_X-2; j+=2) {
				r =	pImageTemp1[1]; 					
				b =  (pImageTemp[0] +pImageTemp[2]+pImageTemp2[0]+pImageTemp2[2]) >> 2; 
				g = (pImageTemp[1] +pImageTemp1[0]+pImageTemp1[2]+pImageTemp2[1]) >> 2;
				
				Y = (int)(307*r+601*b+117*b)>>10;
				
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
				
				pImageTemp  += 1;   		
				pImageTemp1 += 1;							
				pImageTemp2 += 1;	
				
				r = (pImageTemp1[0]+pImageTemp1[2]) >> 1;							
				b = (pImageTemp[1]+pImageTemp2[1]) >> 1;
				g = pImageTemp1[1];
				
				Y = (int)(307*r+601*b+117*b)>>10;
				
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
				
				pImageTemp += 1;    
				pImageTemp1 += 1;
				pImageTemp2 += 1;
			}
			for (j=0; j<2; j++) {	//2's dummy
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
				
			}
			pImageData -= IMAGESIZE_X;
			pImageTemp = pImageData;						
			pImageTemp1 = pImageData - IMAGESIZE_X;		
			pImageTemp2 = pImageData - IMAGESIZE_X*2;
			
			for (j=0; j<IMAGESIZE_X-2; j+=2) {
				r = (pImageTemp[1]+pImageTemp2[1]) >> 1;							
				b = (pImageTemp1[0]+pImageTemp1[2]) >> 1;
				g = pImageTemp1[1];
				
				Y = (int)(307*r+601*b+117*b)>>10;
				
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
				
				pImageTemp += 1;							
				pImageTemp1 += 1;							
				pImageTemp2 += 1;
				
				b = pImageTemp1[1];
				g = (pImageTemp[1]+pImageTemp1[0]+pImageTemp1[2]+pImageTemp2[1]) >> 2;
				r = (pImageTemp[0]+pImageTemp[2]+pImageTemp2[0]+pImageTemp2[2]) >> 2;							  				
				
				Y = (int)(307*r+601*b+117*b)>>10;
				
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
				
				pImageTemp += 1; 
				pImageTemp1 += 1;
				pImageTemp2 += 1;
			}
			for (j=0; j<2; j++) {   //2's dummy
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
				*pBmpBuffer++ =Y ; 
			}
			pImageData -= IMAGESIZE_X;
		} //end for Y axis
		for (i=0; i<IMAGESIZE_X*3; i++)	m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-2)+i] = m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-3)+i];
		for (i=0; i<IMAGESIZE_X*3; i++)	m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-1)+i] = m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-3)+i];
		
 	break;
							
	case GRBG:				//GRGR
							//BGBG
							//GRGR
							//BGBG
		for (i=0; i<IMAGESIZE_Y-2; i+=2) {
			pImageTemp = pImageData;						
			pImageTemp1 = pImageData - IMAGESIZE_X;		
			pImageTemp2 = pImageData - IMAGESIZE_X*2;
			for (j=0; j<IMAGESIZE_X-2; j+=2) {
				r =	pImageTemp1[1]; 					
				b =  (pImageTemp[0] +pImageTemp[2]+pImageTemp2[0]+pImageTemp2[2]) >> 2; 
				g = (pImageTemp[1] +pImageTemp1[0]+pImageTemp1[2]+pImageTemp2[1]) >> 2;
		  		*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;							
				pImageTemp  += 1;   		
				pImageTemp1 += 1;							
				pImageTemp2 += 1;	

				r = (pImageTemp1[0]+pImageTemp1[2]) >> 1;							
				b = (pImageTemp[1]+pImageTemp2[1]) >> 1;
				g = pImageTemp1[1];
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp += 1;    
				pImageTemp1 += 1;
				pImageTemp2 += 1;
			}
			for (j=0; j<2; j++) {	//2's dummy
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;	
			}
			pImageData -= IMAGESIZE_X;
			pImageTemp = pImageData;						
			pImageTemp1 = pImageData - IMAGESIZE_X;		
			pImageTemp2 = pImageData - IMAGESIZE_X*2;
		
			for (j=0; j<IMAGESIZE_X-2; j+=2) {
				r = (pImageTemp[1]+pImageTemp2[1]) >> 1;							
				b = (pImageTemp1[0]+pImageTemp1[2]) >> 1;
				g = pImageTemp1[1];
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;	
				pImageTemp += 1;							
				pImageTemp1 += 1;							
				pImageTemp2 += 1;
			
				b = pImageTemp1[1];
				g = (pImageTemp[1]+pImageTemp1[0]+pImageTemp1[2]+pImageTemp2[1]) >> 2;
				r = (pImageTemp[0]+pImageTemp[2]+pImageTemp2[0]+pImageTemp2[2]) >> 2;							  				
  				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;	
				pImageTemp += 1; 
				pImageTemp1 += 1;
				pImageTemp2 += 1;
			}
			for (j=0; j<2; j++) {   //2's dummy
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;	
			}
		    pImageData -= IMAGESIZE_X;
		} //end for Y axis
 		for (i=0; i<IMAGESIZE_X*3; i++)	m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-2)+i] = m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-3)+i];
		for (i=0; i<IMAGESIZE_X*3; i++)	m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-1)+i] = m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-3)+i];
		
		break;
 	case RGGB:					//RGRG
								//GBGB
								//RGRG
								//GBGB
		for (i=0; i<IMAGESIZE_Y-2; i+=2) {
			pImageTemp = pImageData;						
			pImageTemp1 = pImageData - IMAGESIZE_X;		
			pImageTemp2 = pImageData - IMAGESIZE_X*2;
			for (j=0; j<IMAGESIZE_X-2; j+=2) {
				r = (pImageTemp1[0]+pImageTemp1[2]) >> 1;							
				b = (pImageTemp[1]+pImageTemp2[1]) >> 1;
				g = pImageTemp1[1];
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp  += 1;   		
				pImageTemp1 += 1;							
				pImageTemp2 += 1;	

				r =	pImageTemp1[1]; 					
				b =  (pImageTemp[0] +pImageTemp[2]+pImageTemp2[0]+pImageTemp2[2]) >> 2; 
				g = (pImageTemp[1] +pImageTemp1[0]+pImageTemp1[2]+pImageTemp2[1]) >> 2;
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp += 1;    
				pImageTemp1 += 1;
				pImageTemp2 += 1;
			}
			for (j=0; j<2; j++) {	//2's dummy
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
			}
			pImageData -= IMAGESIZE_X;
			pImageTemp = pImageData;						
			pImageTemp1 = pImageData - IMAGESIZE_X;		
			pImageTemp2 = pImageData - IMAGESIZE_X*2;
		
			for (j=0; j<IMAGESIZE_X-2; j+=2) {
				b = pImageTemp1[1];
				g = (pImageTemp[1]+pImageTemp1[0]+pImageTemp1[2]+pImageTemp2[1]) >> 2;
				r = (pImageTemp[0]+pImageTemp[2]+pImageTemp2[0]+pImageTemp2[2]) >> 2;							  				
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp += 1;							
				pImageTemp1 += 1;							
				pImageTemp2 += 1;
			
				r =	(pImageTemp[1]+pImageTemp2[1]) >> 1;							
				b = (pImageTemp1[0]+pImageTemp1[2]) >> 1;
				g = pImageTemp1[1];
			  	*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp += 1; 
				pImageTemp1 += 1;
				pImageTemp2 += 1;
			}
			for (j=0; j<2; j++) {   //2's dummy
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
			}
			pImageData -= IMAGESIZE_X;
		} //end for Y axis
 		for (i=0; i<IMAGESIZE_X*3; i++)	m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-2)+i] = m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-3)+i];
		for (i=0; i<IMAGESIZE_X*3; i++)	m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-1)+i] = m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-3)+i];
		
		break;
 
	case BGGR:					//BGBG
								//GRGR
								//BGBG
								//GRGR
		for (i=0; i<IMAGESIZE_Y-2; i+=2) {
			pImageTemp = pImageData;						
			pImageTemp1 = pImageData - IMAGESIZE_X;		
			pImageTemp2 = pImageData - IMAGESIZE_X*2;
		    for (j=0; j<IMAGESIZE_X-2; j+=2) {
				b = (pImageTemp1[0]+pImageTemp1[2]) >> 1;
				g = pImageTemp1[1];									
				r = (pImageTemp[1]+pImageTemp2[1]) >> 1;
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp  += 1;   		
				pImageTemp1 += 1;							
				pImageTemp2 += 1;
				
				b = pImageTemp1[1];
				g = (pImageTemp[1]+pImageTemp1[0]+pImageTemp1[2]+pImageTemp2[1]) >> 2;
				r = (pImageTemp[0]+pImageTemp[2]+pImageTemp2[0]+pImageTemp2[2]) >> 2;							  				
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp += 1;    
				pImageTemp1 += 1;
				pImageTemp2 += 1;
			}
			for (j=0; j<2; j++) {	//2's dummy
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
			}
			pImageData -=IMAGESIZE_X;
			pImageTemp = pImageData;						
			pImageTemp1 = pImageData - IMAGESIZE_X;		
			pImageTemp2 = pImageData - IMAGESIZE_X*2;

			for	(j=0; j<IMAGESIZE_X-2; j+=2) {
				r =	pImageTemp1[1]; 					
				b =  (pImageTemp[0] +pImageTemp[2]+pImageTemp2[0]+pImageTemp2[2]) >> 2; 
				g = (pImageTemp[1] +pImageTemp1[0]+pImageTemp1[2]+pImageTemp2[1]) >> 2;
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp += 1;							
				pImageTemp1 += 1;							
				pImageTemp2 += 1;	
			
				r = (pImageTemp1[0]+pImageTemp1[2]) >> 1;							
				b = (pImageTemp[1]+pImageTemp2[1]) >> 1;
				g = pImageTemp1[1]; 
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp += 1; 
				pImageTemp1 += 1;
				pImageTemp2 += 1;
			}
			for (j=0; j<2; j++) {   //2's dummy
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
			}
			pImageData -= IMAGESIZE_X;
		} //end for Y
 		for (i=0; i<IMAGESIZE_X*3; i++)	m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-2)+i] = m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-3)+i];
		for (i=0; i<IMAGESIZE_X*3; i++)	m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-1)+i] = m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-3)+i];
		
		break;
 	case GBRG:					//GBGB
								//RGRG
								//GBGB
								//RGRG
		for (i=0; i<IMAGESIZE_Y-2; i+=2) {
			pImageTemp = pImageData;						
			pImageTemp1 = pImageData - IMAGESIZE_X;		
			pImageTemp2 = pImageData - IMAGESIZE_X*2;
		    for (j=0; j<IMAGESIZE_X-2; j+=2) {
				b = pImageTemp1[1];
				g = (pImageTemp[1]+pImageTemp1[0]+pImageTemp1[2]+pImageTemp2[1]) >> 2;
				r = (pImageTemp[0]+pImageTemp[2]+pImageTemp2[0]+pImageTemp2[2]) >> 2;
  				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp  += 1;   		
				pImageTemp1 += 1;							
				pImageTemp2 += 1;	

				b = (pImageTemp1[0]+pImageTemp1[2]) >> 1;
				g = pImageTemp1[1];
				r = (pImageTemp[1]+pImageTemp2[1]) >> 1;
  				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp += 1;
				pImageTemp1 += 1;
				pImageTemp2 += 1;
			}
			for (j=0; j<2; j++) {	//2's dummy
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
			}
			pImageData -= IMAGESIZE_X;
			pImageTemp = pImageData;						
			pImageTemp1 = pImageData - IMAGESIZE_X;		
			pImageTemp2 = pImageData - IMAGESIZE_X*2;
		
			for (j=0; j<IMAGESIZE_X-2; j+=2) {
				r = (pImageTemp1[0]+pImageTemp1[2]) >> 1;							
				b = (pImageTemp[1]+pImageTemp2[1]) >> 1;
				g = pImageTemp1[1]; 		
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp += 1;							
				pImageTemp1 += 1;							
				pImageTemp2 += 1;
			
				r =	pImageTemp1[1]; 					
				b =  (pImageTemp[0] +pImageTemp[2]+pImageTemp2[0]+pImageTemp2[2]) >> 2; 
				g = (pImageTemp[1] +pImageTemp1[0]+pImageTemp1[2]+pImageTemp2[1]) >> 2;
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
				pImageTemp += 1; 
				pImageTemp1 += 1;
				pImageTemp2 += 1;
			}
			for (j=0; j<2; j++) {   //2's dummy
				*pBmpBuffer++ = b;
				*pBmpBuffer++ = g;
				*pBmpBuffer++ = r;
			}
			pImageData -= IMAGESIZE_X;
		} //end for (m_ImageSize.xy)
		for (i=0; i<IMAGESIZE_X*3; i++)	m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-2)+i] = m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-3)+i];
		for (i=0; i<IMAGESIZE_X*3; i++)	m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-1)+i] = m_pBmpBuffer[IMAGESIZE_X*3*(IMAGESIZE_Y-3)+i];
		
 		break;
	}  
	
}
/**************************************************************************************************
* BOOL			SaveImageToBmpFile(void)
* Description:
*		 Image save to bmp file format.
* Inputs:
*       m_pBmpBuffer :  Image buffer : Global variable.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL SaveImageToBmpFile(void)
{
	OPENFILENAME	 SFN;
	char			 lpstrFile[MAX_PATH];
	char			 SaveFileMessage[MAX_PATH]={0};
	
	int				 OffBits;
	HFILE			 bmpFile;
	BITMAPFILEHEADER bmpHeader; // Header for Bitmap file
	BITMAPINFO		 bmpInfo;
	
	OffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
	DWORD dwSizeImage = IMAGESIZE_X*IMAGESIZE_Y*3;
	
	bmpHeader.bfType = ( (WORD)('M'<<8)|'B' );  
	bmpHeader.bfSize = OffBits + dwSizeImage;
	bmpHeader.bfReserved1 = 0;
	bmpHeader.bfReserved2 = 0;
	bmpHeader.bfOffBits = OffBits;
	
	bmpInfo.bmiHeader.biSize            = sizeof(BITMAPINFOHEADER);
    bmpInfo.bmiHeader.biWidth           = IMAGESIZE_X;
    bmpInfo.bmiHeader.biHeight          = IMAGESIZE_Y;
    bmpInfo.bmiHeader.biPlanes          = 1;
    bmpInfo.bmiHeader.biBitCount        = 24;
    bmpInfo.bmiHeader.biCompression     = BI_RGB;
    bmpInfo.bmiHeader.biSizeImage       = 0; 
    bmpInfo.bmiHeader.biXPelsPerMeter   = 0;
    bmpInfo.bmiHeader.biYPelsPerMeter   = 0;
    bmpInfo.bmiHeader.biClrUsed         = 0;
    bmpInfo.bmiHeader.biClrImportant    = 0;
	
	wsprintf(lpstrFile, "Image");
	memset(&SFN, 0, sizeof(OPENFILENAME));
	SFN.lStructSize = sizeof(OPENFILENAME);
	SFN.hwndOwner = ghwndDlg;
	SFN.lpstrFilter = "bmp file(*.bmp)\0*.bmp\0";
	SFN.lpstrFile = lpstrFile;
	SFN.nMaxFile = MAX_PATH;
	
	if (!GetSaveFileName(&SFN))	return FALSE;
	
	strcat(lpstrFile, ".bmp");
	
	if (_access(lpstrFile, 0) == 0) { 
		wsprintf(SaveFileMessage, "%s is already exists.Do you want replace it?", lpstrFile);
		if (MessageBox(ghwndDlg,SaveFileMessage, "Save as", MB_YESNO|MB_ICONWARNING) == IDNO)
			return 0;
		if (_access(lpstrFile, 6) == -1) { 
			MessageBox(ghwndDlg, "Could not save a file.", "File save error", MB_OK|MB_ICONSTOP);
			return 0;
		}
	}
	
	bmpFile = _lcreat(lpstrFile, 0);
	if (bmpFile < 0) {
		return FALSE;
	}
	
	UINT len;
	len = _lwrite(bmpFile, (LPSTR)&bmpHeader, sizeof(BITMAPFILEHEADER));
	len = _lwrite(bmpFile, (LPSTR)&bmpInfo, sizeof(BITMAPINFOHEADER));
	len = _lwrite(bmpFile, (LPSTR)m_pBmpBuffer, bmpHeader.bfSize - sizeof(bmpHeader) - sizeof(bmpInfo)+4);  //+4 is for exact filesize
	_lclose(bmpFile);
	
	return TRUE;	
}

/*
Windows bitmaps - BMP, DIB; 
JPEG files - JPEG, JPG, JPE; 
Portable Network Graphics - PNG; 
Portable image format - PBM, PGM, PPM; 
Sun rasters - SR, RAS; 
TIFF files - TIFF, TIF;
*/
BOOL SaveImageFileByOpenCV()
{
	OPENFILENAME	ofn;
	char			lpstrFile[MAX_PATH]="image";
	char			tmp[MAX_PATH]="";

	memset(&ofn, 0, sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = ghwndDlg;
	ofn.lpstrFilter = "Bitmap File (*.bmp)\0*.bmp\0JPEG File (*.jpg)\0*.jpg\0PNG File (*.png)\0*.png\0PGM File (*.pgm)\0*.pgm\0TIFF File (*.tif)\0*.tif\0";
	ofn.lpstrFile = lpstrFile;
	ofn.Flags= OFN_OVERWRITEPROMPT|OFN_NOCHANGEDIR;//root ���丮�� �ٲ��� ����...
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrDefExt = TEXT("bmp");  // ����... OFN_OVERWRITEPROMPT flag�� ����ҷ���...
	                                //         �ݵ��, ofn.lpstrDefExt�� �������־�� �Ѵ�...

	if(GetSaveFileName(&ofn) == IDOK)
	{
		//////////////////////////////////////////////////////////////////
		// �����ϰ��� �ϴ� ������ ������ �� �ִ�...
		//cvSetImageROI( m_CvvImage.GetImage(),  cvRect(0,155,145,145) );

		if(ofn.nFileExtension==0){
			switch(ofn.nFilterIndex){
			case 1:	// bmp
				wsprintf(ofn.lpstrFile,"%s.bmp", ofn.lpstrFile);
				break;
			case 2:	// jpg
				wsprintf(ofn.lpstrFile,"%s.jpg", ofn.lpstrFile);
				break;
			case 3:	// 
				wsprintf(ofn.lpstrFile,"%s.png", ofn.lpstrFile);
				break;
			case 4:	// 
				wsprintf(ofn.lpstrFile,"%s.pgm", ofn.lpstrFile);
				break;
			case 5:	// 
				wsprintf(ofn.lpstrFile,"%s.tif", ofn.lpstrFile);
				break;
			}
		}	
			
		cvSaveImage( ofn.lpstrFile,  m_CvvImage.GetImage() );

		return TRUE;
	}

	return FALSE;
}

/**************************************************************************************************
* BOOL			SaveImageToRawFile(void)
* Description:
*		 Image save to raw file format.
* Inputs:
*      None			: User setting buffer 
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL SaveImageToRawFile(void)
{
	FILE	*fp;
	char file_name[15] = "image";
	static char file_num[3];
	static int  file_index=0;
	
	OPENFILENAME	 SFN;
	char			 lpstrFile[MAX_PATH];
	char			 SaveFileMessage[MAX_PATH]={0};
	
	wsprintf(file_name, "Image");
	memset(&SFN, 0, sizeof(OPENFILENAME));
	SFN.lStructSize = sizeof(OPENFILENAME);
	SFN.hwndOwner = ghwndDlg;
	SFN.lpstrFilter = "raw file(*.raw)\0*.raw\0";
	SFN.lpstrFile = file_name;
	SFN.nMaxFile = MAX_PATH;
	
	if (!GetSaveFileName(&SFN))
		return FALSE;
	strcat(file_name, ".raw");
	
	if (_access(lpstrFile, 0) == 0) { 
		wsprintf(SaveFileMessage, "%s is already exists.Do you want replace it?", lpstrFile);
		if (MessageBox(ghwndDlg,SaveFileMessage, "Save as", MB_YESNO|MB_ICONWARNING) == IDNO)
			return 0;
		if (_access(lpstrFile, 6) == -1) { 
			MessageBox(ghwndDlg, "Could not save a file.", "File save error", MB_OK|MB_ICONSTOP);
			return 0;
		}
	}
	
	if ( !(fp = fopen(file_name, "wb")) )
		return FALSE;
	// User setting buffer
	fwrite (m_pYCbCrBuffer, sizeof(char), IMAGESIZE_X*IMAGESIZE_Y, fp);
	fclose(fp);
	
	return TRUE;
	
}
/**************************************************************************************************
* void			MakeThread()
* Description:
*		 Create dual thread : Date thread/ Display thread
*		 need to thread function :refer "Date_thread" / "Display_thread"
*		 When mode is 'PLAY', create / when mode is 'STOP', delete.
**************************************************************************************************/
void MakeThread()
{	
	//hThreadData
	hThreadData=CreateThread(NULL,0,Data_Thread,0 ,/*CREATE_SUSPENDED*/0 ,&IDThreadData);
	SetThreadPriority(hThreadData, THREAD_PRIORITY_TIME_CRITICAL);
	//hThreadDisplay
	hThreadDisplay=CreateThread(NULL,0, Display_Thread,0 ,/*CREATE_SUSPENDED*/0 ,&IDThreadDisplay);
	SetThreadPriority(hThreadDisplay, THREAD_PRIORITY_TIME_CRITICAL);
}


/**************************************************************************************************
* DWORD WINAPI	Data_Thread(LPVOID Temp)
* Description:
*		 Get Sensor's data and insert to buffer.
*		 Data's whole size have to set multiple of 512 
*		 example : IMAGESIZE_X*IMAGESIZE_Y = 512 * x
* Return:
*      0    :Infinite loop 
**************************************************************************************************/
 
DWORD WINAPI Data_Thread(LPVOID Temp)
{
	DWORD		exitcode;
	int			getDataTF = 0;
	static int	i=0;
	
	for( ; ; )	{
		if (m_PlayMode == PLAY) {	// PLAY mode	
			
			//8 bit bayer mode
			if (b1stBuffer) {
  				getDataTF = Get_Sensor_RawDataCam(IMAGESIZE_X*IMAGESIZE_Y, m_pYCbCrBuffer1, gDrvIndex);
			}
			else {
  				getDataTF = Get_Sensor_RawDataCam(IMAGESIZE_X*IMAGESIZE_Y, m_pYCbCrBuffer, gDrvIndex);
			}

 			if(getDataTF==1){
				Display_frame(ghwndDlg);
 			}	
 
  			//Sensor���� �������� �����ŭ data�� �������� getDataTF�� 1�� return ��.
 			if (1 == getDataTF) {
 				i=0;
				b1stBuffer = !b1stBuffer;
				gBufferStatus = 1;
			}

			//Time out routine
			//���� �Ⱓ���� Data�� ������ ������ Stop����...
			Sleep(0);
			if (i == 10000) { //time out
				i = 0; //it is remained
				SendMessage(ghwndDlg, WM_COMMAND, IDC_STOP, 0);
				return 0;
			}
			else {
				i++; //idle status
			}
		}
		else if (m_PlayMode == EXIT0 || m_PlayMode == STOP) {
			GetExitCodeThread(hThreadData, &exitcode);
			ExitThread(exitcode);
			return 0;
		}	
	}//END: for( ; ; )
} 

 

/**************************************************************************************************
* DWORD WINAPI	Display_Thread(LPVOID Temp)
* Description:
*		 Convert to bmp buffer and display
*		  
* Return:
*      0    :Infinite loop 
**************************************************************************************************/
DWORD WINAPI Display_Thread(LPVOID Temp)
{
	DWORD		exitcode;
	CvVideoWriter *VideoOut=NULL;

	for( ; ; )
	{
		if (m_PlayMode == PLAY) {
			
			/////////////////////////////////
			if(!gOpenCV){
				Normal_Display();
			}else{
				openCV_Display();
			}
			/////////////////////////////////
			
 			Sleep(1); //it need 
		}	
		else if (m_PlayMode == EXIT0 || m_PlayMode == STOP) {
			 GetExitCodeThread(hThreadDisplay, &exitcode);
			ExitThread(exitcode);
			return 0;
		}	
	}//END: for( ; ; )
}

void Normal_Display()
{
	//8 bit bayer mode
	if (1 == gBufferStatus) {
  		if (b1stBuffer){		//display opposite buffer
 			RawToBmp(m_pYCbCrBuffer);
		}else{
 			RawToBmp(m_pYCbCrBuffer1);
		}

		if(TriggerOn==0){
 			if(!Trig_Read(gDrvIndex)) {
				TriggerOn=1;
				OnSnapshot(ghwndDlg);
  				TriggerOn=0;
			}
		}

 		InvalidateRect(ghwndApp, NULL, FALSE);
		UpdateWindow(ghwndApp);
		gBufferStatus = 0;			
	}
}

void openCV_Display()
{
	if (1 == gBufferStatus) 
	{
		if (b1stBuffer) 
		{ //display opposite buffer
			image->imageData = (char*)m_pYCbCrBuffer;
		}else{
			image->imageData = (char*)m_pYCbCrBuffer1;
		}

		if(currentDevice == MT9T001 )
			cvCvtColor( image, imgIntP, CV_BayerGB2BGR);
		else
			cvCvtColor( image, imgIntP, CV_BayerBG2BGR);

		if(gGRAY){ 
		
			cvCvtColor( imgIntP, imgGray, CV_BGR2GRAY);

			if(gBLUR){
				cvSmooth( imgGray, imgGray, CV_BLUR,5,5);
				cvSmooth( imgGray, imgGray, CV_BLUR,5,5);
			}

			if(gGRAYhisto){
				processing();
			}

			if(gCANNY){
				cvCanny(imgGray, imgCanny, 100,150,3);
				m_CvvImage.CopyOf(imgCanny,1);
			}else{

				if(gFACEDETECTION){
//					CvHaarClassifierCascade* cascade=(CvHaarClassifierCascade*)cvLoad("haarcascade_frontalface_default.xml");
					detectObjects(imgGray, cascade);
//					cvReleaseHaarClassifierCascade(&cascade);
				}

				if(gTMATCHING && bTargetFile){
					TM_targetRectangle(imgGray);
					cvRectangle(imgGray, left_top, cvPoint(left_top.x + imgTM1->width, left_top.y + imgTM1->height), CV_RGB(255,0,0)); 
				}

				if(gAVI){
					cvPutText(imgGray, "HVR2000 Series...", cvPoint(10, 20), &font, cvScalar(0,0,255));
					cvPutText(imgGray, "www.hyvision.co.kr", cvPoint(10, 40), &font, cvScalar(255,0,0));
					cvWriteFrame(VideoOut, imgGray);
				}

				m_CvvImage.CopyOf(imgGray,1); 
			}

		}else{

			if(gBLUR){
				cvSmooth(imgIntP, imgIntP, CV_BLUR,5,5);
				cvSmooth(imgIntP, imgIntP, CV_BLUR,5,5);
			}

			if(gGRAYhisto){
				cvCvtColor( imgIntP, imgGray, CV_BGR2GRAY);
				processing();
			}

			if(gCANNY){
				cvCvtColor( imgIntP, imgGray, CV_BGR2GRAY);
				cvCanny(imgGray, imgCanny, 100,150,3);
				m_CvvImage.CopyOf(imgCanny,1); 
			}else{
				if(gFACEDETECTION){
					detectObjects(imgIntP, cascade);
				}

				if(gTMATCHING && bTargetFile){
					TM_targetRectangle(imgIntP);
					cvRectangle(imgIntP, left_top, cvPoint(left_top.x + imgTM1->width, left_top.y + imgTM1->height), CV_RGB(255,0,0)); 
				}

				if(gAVI){
					cvPutText(imgIntP, "HVR2000 Series...", cvPoint(10, 20), &font, cvScalar(0,0,255));
					cvPutText(imgIntP, "www.hyvision.co.kr", cvPoint(10, 40), &font, cvScalar(255,0,0));
					cvWriteFrame(VideoOut, imgIntP);
				}

				m_CvvImage.CopyOf(imgIntP,1);
			}
		}
				
		HDC hDC = (HDC)GetDC(ghwndApp);
		GetClientRect(ghwndApp, &m_rect);
		m_CvvImage.Show(hDC, m_rect.left, m_rect.top, m_rect.right, m_rect.bottom);
		DeleteDC(hDC);

		if(TriggerOn==0){
 			if(!Trig_Read(gDrvIndex)) {
				TriggerOn=1;
				OnSnapshot(ghwndDlg);
  				TriggerOn=0;
			}
		}
		
		gBufferStatus = 0;
	}
}

void detectObjects(IplImage* image, CvHaarClassifierCascade* cascade)
{
	CvMemStorage* storage=cvCreateMemStorage(0);
	CvSeq* faces;
	int i, scale=1;

	faces=cvHaarDetectObjects(image, cascade, storage, 1.2, 2, CV_HAAR_DO_CANNY_PRUNING);

	for(i=0;i<faces->total;i++){
		CvRect face_rect=*(CvRect*)cvGetSeqElem(faces, i);
		cvRectangle(image, cvPoint(face_rect.x*scale, face_rect.y*scale), 
						   cvPoint((face_rect.x+face_rect.width)*scale,	(face_rect.y+face_rect.height)*scale),
						   CV_RGB(255,0,0), 3);
	}

	cvReleaseMemStorage(&storage);
}

void Start_AVI(bool mode)
{
	static int num=0;
	int value;
	char tmp[128];

	value = GetDlgItemInt(ghwndDlg, IDC_DISPLAY_FRAMERATE, NULL, FALSE);

	if(mode){
		sprintf(tmp, "AVIsave%d-%dfps-%dx%d.avi", num++, value-5, IMAGESIZE_X, IMAGESIZE_Y);
		VideoOut = cvCreateVideoWriter(tmp, -1/*CV_FOURCC('M','P','4','2')*/, value-5, cvGetSize(imgGray), 1);
	}else{
		sprintf(tmp, "AVIsave%d-%dfps-%dx%d.avi", num++, value, IMAGESIZE_X, IMAGESIZE_Y);
		VideoOut = cvCreateVideoWriter(tmp, 0/*CV_FOURCC('M','P','4','2')*/, value, cvGetSize(imgGray), 1);
	}

	cvInitFont(&font, CV_FONT_HERSHEY_TRIPLEX, 0.5, 0.5, 0, 1);
}

void Stop_AVI()
{
	cvReleaseVideoWriter(&VideoOut);
	VideoOut=NULL;
}

void processing()
{
	int i, bin_w;
    float max_value = 0;

	//input���� �����ؼ�

	cvCalcHist( &imgGray, hist, 0, NULL );

//	cvZero( imgGray );
    cvGetMinMaxHistValue( hist, 0, &max_value, 0, 0 );
    cvScale( hist->bins, hist->bins, ((double)hist_image->height)/max_value, 0 );
    
    cvSet( hist_image, cvScalarAll(128), 0 );
    bin_w = cvRound((double)hist_image->width/hist_size);

    for( i = 0; i < hist_size; i++ )
        cvRectangle( hist_image, cvPoint(i*bin_w, hist_image->height),
                     cvPoint((i+1)*bin_w, hist_image->height - cvRound(cvGetReal1D(hist->bins,i))),
                     cvScalarAll(0), -1, 8, 0 );
	//output���� ����

	cvShowImage( "Gray-Histogram", hist_image );
}

void noprocessing(int mode)
{
	if(mode)
		cvNamedWindow( "Gray-Histogram", 1);
	else
		cvDestroyAllWindows();
}

/////////////////////////////////////////////////////////////////////////////////

BOOL FindFile(LPCTSTR name)
{
	WIN32_FIND_DATA fd;

	HANDLE hd;
	hd = FindFirstFile(name, &fd);

	if (hd != INVALID_HANDLE_VALUE)
	{
		do{
			if(!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
			{
				DeleteFile(name);
				return TRUE;
			}
		}while(FindNextFile(hd, &fd)); // ������, ������...
	}

	CloseHandle(hd);
	return FALSE;
}

/**************************************************************************************************
* void			Display_frame( HWND hDlg)
* Description:
*		Frame rate of image display.
**************************************************************************************************/
void Display_frame(HWND hDlg)
{
	static		BOOL fps_first = TRUE;
	static		LARGE_INTEGER start_time, end_time, freq;
	static		__int16	display_count;
	double		gap;
	
	if( fps_first ) {
		display_count =0;
		QueryPerformanceCounter(&start_time);
		fps_first = FALSE;
	}
	else {
		QueryPerformanceCounter(&end_time);
		QueryPerformanceFrequency(&freq);
		gap = ((double)(end_time.QuadPart - start_time.QuadPart)) / ((double)freq.QuadPart);
 		if( gap >= 1 ) { 
 			fps_first = TRUE;
			SetDlgItemFloat(hDlg, IDC_DISPLAY_FRAMERATE, (float)(display_count/gap) );
		}
	}
	display_count++;
}

/**************************************************************************************************
* void			DisplayImage(HDC hDC);
* Description:
*		Image display to main frame from PC's DC.
* Inputs:
*      hDC		   :   Memory DC
**************************************************************************************************/
BITMAPINFO	bmpInfo;
void DisplayImage(HDC hDC)
{
	bmpInfo.bmiHeader.biSize            = sizeof(BITMAPINFOHEADER) ;
    bmpInfo.bmiHeader.biWidth           = (IMAGESIZE_X);
    bmpInfo.bmiHeader.biHeight          = (IMAGESIZE_Y);
    bmpInfo.bmiHeader.biPlanes          = 1;
    bmpInfo.bmiHeader.biBitCount        = 24;
    bmpInfo.bmiHeader.biCompression     = BI_RGB ;
    bmpInfo.bmiHeader.biSizeImage       = 0;
    bmpInfo.bmiHeader.biXPelsPerMeter   = 0;
    bmpInfo.bmiHeader.biYPelsPerMeter   = 0;
    bmpInfo.bmiHeader.biClrUsed         = 0;
    bmpInfo.bmiHeader.biClrImportant    = 0;

	::SetDIBitsToDevice(hDC,
						0, 0,
						(IMAGESIZE_X), (IMAGESIZE_Y),
						0, 0, 0, (IMAGESIZE_Y),
						m_pBmpBuffer,
						&bmpInfo, DIB_RGB_COLORS);
}
/**************************************************************************************************
* void			DisplayImage2(HDC hDC, int ImageXpos, int ImageYpos)
* Description:
*		The image display with resolution size of the monitor. 
*		If image size is bigger than monitor's resolution and reduce integer is true.
*      
* Inputs:
*      hDC			:   Memory DC
*	  img_xsize		:	Resize width.
*	  img_ysize		:	Resize height.
**************************************************************************************************/
void	DisplayImage2(HDC hDC, int ImageXpos, int ImageYpos)
{
	bmpInfo.bmiHeader.biSize            = sizeof(BITMAPINFOHEADER) ;
    bmpInfo.bmiHeader.biWidth           = (IMAGESIZE_X);
    bmpInfo.bmiHeader.biHeight          = (IMAGESIZE_Y);
    bmpInfo.bmiHeader.biPlanes          = 1;
    bmpInfo.bmiHeader.biBitCount        = 24;
    bmpInfo.bmiHeader.biCompression     = BI_RGB ;
    bmpInfo.bmiHeader.biSizeImage       = 0;
    bmpInfo.bmiHeader.biXPelsPerMeter   = 0;
    bmpInfo.bmiHeader.biYPelsPerMeter   = 0;
    bmpInfo.bmiHeader.biClrUsed         = 0;
    bmpInfo.bmiHeader.biClrImportant    = 0;
	
	HBITMAP Oldbitmap;
	HDC Memdc;
	
	if(!m_bMakeMemory){
//		m_hbit = CreateCompatibleBitmap(hDC, 2048, 1536);
		m_hbit = CreateCompatibleBitmap(hDC, 3000, 2500);
		m_bMakeMemory = TRUE;
	}
	Memdc = CreateCompatibleDC(hDC);
	Oldbitmap = (HBITMAP)SelectObject(Memdc, m_hbit);
	
	::SetDIBitsToDevice(Memdc,
		0, 0,
		(IMAGESIZE_X), (IMAGESIZE_Y),
		0, 0, 0, (IMAGESIZE_Y),
		m_pBmpBuffer,
		&bmpInfo, DIB_RGB_COLORS);
	
	SelectObject(Memdc, Oldbitmap);
	DeleteObject(Memdc);
	DisplayImageToScreen(ghwndApp, ImageXpos, ImageYpos);
}
/**************************************************************************************************
* void			DisplayImageToScreen(HWND hWnd, const  __int16 img_xsize, const __int16 img_ysize)
* Description:
*		This function is called to Display2(); 
*		    
* Inputs:
*      hWnd			:   Current handle.
*	   img_xsize	:	Resize width.
*	   img_ysize	:	Resize height.
**************************************************************************************************/
void DisplayImageToScreen(HWND hWnd, const  __int16 img_xsize, const __int16 img_ysize)
{
	HDC hdc, Memdc;
	HBITMAP Oldbitmap;
	int		ioldmod;
	
	hdc = GetDC(hWnd);
	Memdc = CreateCompatibleDC(hdc);
	Oldbitmap = (HBITMAP)SelectObject(Memdc, m_hbit);
	
 	ioldmod=SetStretchBltMode(hdc, COLORONCOLOR); // COLORONCOLOR / HALFTONE-good image
//	ioldmod=SetStretchBltMode(hdc, HALFTONE); // COLORONCOLOR / HALFTONE-good image
//	SetBrushOrgEx(hdc,IMAGESIZE_X,IMAGESIZE_Y,NULL);
		
	StretchBlt(hdc, 0,0, img_xsize, img_ysize, Memdc, 0, 0, IMAGESIZE_X, IMAGESIZE_Y, SRCCOPY);
	SetStretchBltMode(hdc, ioldmod);
	SelectObject(Memdc, Oldbitmap);
	DeleteDC(Memdc);
	ReleaseDC(hWnd, hdc);
	
}
/**************************************************************************************************
* void			Draw(HDC pDC,UINT id, int dx, int dy,int left, int top, int sw, int sh)
* Description:
*		Main Dialog's Bitmap paint.
*		    
* Inputs:
*      pDC			:   DC
*	   id			:	Resource ID
*	   dx			:	Bitmap's new posion x
*	   dy			:   Bitmap's new posion x
*      left			:	Bitmap's org posion x
*	   top			:	Bitmap's org posion x
*	   sw			:	width
*      sh			:	height
**************************************************************************************************/
void Draw(HDC pDC,UINT id, int dx, int dy,int left, int top, int sw, int sh)
{
	
	BITMAP		bm;
	HBITMAP		oldBitmap,bitmap;
	
	bitmap = LoadBitmap(ghInstApp,MAKEINTRESOURCE(id));
	GetObject(bitmap,sizeof(BITMAP),&bm);
	
	POINT size;
	size.x=bm.bmWidth;
	size.y=bm.bmHeight;
	DPtoLP(pDC,&size,sizeof(POINT));
	
	POINT org;
	org.x=left;
	org.y=top;
	DPtoLP(pDC,&org,sizeof(POINT));
	
	HDC dcMem;
	dcMem = CreateCompatibleDC(pDC);
	oldBitmap =	(HBITMAP)SelectObject(dcMem,bitmap);
	SetMapMode(dcMem,GetMapMode(pDC));
	BitBlt(pDC,dx,dy,sw,sh,dcMem,org.x,org.y,SRCCOPY);
	SelectObject(dcMem,bitmap);
	DeleteObject(oldBitmap);
	DeleteObject(bitmap);
	DeleteDC(dcMem);
}
/**************************************************************************************************
* void			OnGetIndex(HWND hDlg)
* Description:
*		Select vision cam's index		    
* Inputs:
*      hDlg			:   handle.
**************************************************************************************************/
void OnGetIndex(HWND hDlg)
{
	
	WORD	wRegAddr;
	TCHAR	szRegAddr[25];
	
	GetDlgItemText(hDlg, IDC_INDEX, szRegAddr, 10);
	_stscanf(szRegAddr, "%d", &wRegAddr);
	
	gDrvIndex = wRegAddr;
	
}
/**************************************************************************************************
* void			SetDlgItemFloat(HWND hDlg, int nIDDlgItem, float fValue);
* Description:
*		Dialog's float 		    
* Inputs:
*      hDlg			:   handle.
*	   nIDDlgItem	:   Dialog's ID
*	   fValue		:   float value
**************************************************************************************************/

void SetDlgItemFloat(HWND hDlg, int nIDDlgItem, float fValue)
{
	char szBuffer[55];
	
	sprintf(szBuffer, "%1.2f", fValue);
	SetDlgItemText(hDlg, nIDDlgItem, szBuffer);
}
/**************************************************************************************************
* void			OnInterpolation(HWND hDlg));
* Description:
*		Interpolation on / off
* Inputs:
*      hDlg			:   handle.
**************************************************************************************************/
void OnInterpolation(HWND hDlg)
{
	if (BST_CHECKED == SendDlgItemMessage(hDlg, IDC_INTERPOLATION, BM_GETCHECK, 0, 0)) {  //if check
		if(currentDevice== MT9T001)
			SensorType[gCurrentSensorType].OutMode = GRBG;
 		else if(currentDevice == HV7131R){
			SensorType[gCurrentSensorType].OutMode = RGGB;
		}
	}
	else {
		SensorType[gCurrentSensorType].OutMode= BlackWhite;
	}
	
}

/**************************************************************************************************
* void			OnDisplayMode(HWND hDlg)
* Description:
*		Display Preview fit function on/off
* Inputs:
*      hDlg			:   handle.
**************************************************************************************************/
void			OnDisplayMode(HWND hDlg)
{
	LPSTR	lpAppName = "HVS_VISIONCAM";
	char	filedir[MAX_PATH]={0};
	
	if (IMAGESIZE_X>=ResolutionX && IMAGESIZE_Y>=ResolutionY) {
		
		if (BST_CHECKED == SendDlgItemMessage(hDlg, IDC_PREVIEW_MODE, BM_GETCHECK, 0, 0)) {  //if check
			bReduce=FALSE;
			Fitmode=1;
			wsprintf(filedir, "VISION%d_Fit", gDrvIndex);
			INIWriteStringVision(lpAppName,filedir,"1");
			
			MoveWindow(ghwndApp, 0, 0, ResolutionX+4, ResolutionY+4, TRUE);
			
		}
		else {
		 
			bReduce=TRUE;
			Fitmode=0;
			if(IMAGESIZE_X+((FrameY*2)+2)<=ResolutionX && (IMAGESIZE_Y+Caption+(FrameY*3)+2)<=ResolutionY)
				MoveWindow(ghwndApp, 0, 0,IMAGESIZE_X+(FrameY*2)+2, IMAGESIZE_Y+Caption+(FrameX*2)+2 , TRUE);
			else if((IMAGESIZE_X+(FrameY*2)+2)>=ResolutionX
				&& (IMAGESIZE_Y+Caption+(FrameX*2)+2)<=ResolutionY){
				MoveWindow(ghwndApp, 0, 0,ResolutionX, (IMAGESIZE_Y+Caption+(FrameX*2)+2), TRUE);				
			}
			else if((IMAGESIZE_X+(FrameY*2)+2)< ResolutionX
				&& (IMAGESIZE_Y+Caption+(FrameX*2)+2) >=ResolutionY){
				MoveWindow(ghwndApp, 0, 0,(IMAGESIZE_X+(FrameY*2)+2), ResolutionY, TRUE);
			}
			else 
				MoveWindow(ghwndApp, 0, 0,(IMAGESIZE_X+(FrameY*2)+2), (IMAGESIZE_Y+Caption+(FrameX*2)+2), TRUE);
				wsprintf(filedir, "VISION%d_Fit", gDrvIndex);
				INIWriteStringVision(lpAppName,filedir,"0");
			
		}
	}
	else {
		MoveWindow(ghwndApp, 0, 0,(IMAGESIZE_X+(FrameY*2)+2), (IMAGESIZE_Y+Caption+(FrameX*2)+2), TRUE);
	}
}
 
 