#ifndef _HYCAM_H_
#define _HYCAM_H_

extern	HWND		ghwndApp;
extern	HINSTANCE	ghInstApp;
extern RECT			ImageRt;
extern	BOOL	    bReduce;					//resize on/off
extern	int			Fitmode;
extern int			ResolutionX, ResolutionY;	//resolution of monitor

/*-----------------------------------------------------------------------------
   Function Prototypes
 ------------------------------------------------------------------------------*/
LONG WINAPI		AppWndProc(HWND hwnd, UINT uiMessage, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK	MainDlgProc(HWND hDlg, UINT Message, UINT wParam, LONG lParam);

#endif
