#ifndef _HYIMAGE_H_
#define _HYIMAGE_H_

#define WM_USER_DRAW		100

#define R_Coeff				1.371
#define G1_Coeff			0.698
#define G2_Coeff			0.336
#define B_Coeff				1.732


//DATA FORMAT
#define  YUV				0
#define  RAW				1
 
 //Bayer OUTPUT MODE
#define	BGGR				1	//BGBG
								//GRGR
								//BGBG
								//GRGR

#define RGGB				2	//RGRG
								//GBGB
								//RGRG
								//GBGB 

#define GBRG				3	//GBGB
								//RGRG
								//GBGB
								//RGRG

#define GRBG				4	//GRGR
								//BGBG
								//GRGR
								//BGBG
#define BlackWhite			5

//I2C MODE
#define BIT8				1	// 8 bit mode
#define BIT16				2	// 16bit mode 

// IMAGE SIZE
extern int  IMAGESIZE_X;		
extern int  IMAGESIZE_Y;

#define	MAXSTR				256						//max. length of Intel Hex file string
#define MAX_SETFILE_LEN		40960
#define	ONE_SET_LEN			5

// Global variable
extern HWND			ghwndDlg;						//Main dialog's handle
extern HANDLE		hThreadData,hThreadDisplay;		//thread handle
extern int			gCurrentSensorType;				//current selected sensor type
extern int			gBufferStatus;					//buffer status flag
extern int			b1stBuffer;						//buffer flag 
extern int			gDrvIndex;						//Cam's index
extern int			currentDevice;

// Structure of PLAY/STOP mode.
typedef enum _PlayMode {
	PLAY = 0,
	STOP,
	ONESHOT,
	PAUSE,
	EXIT0
} PlayMode, *pPlayMode;
extern PlayMode		m_PlayMode;

// Structure of sensor's information.
typedef struct _SENSOR_TYPE {
	int nIndex;	 
	LPSTR szSensorString;	//list string- user view.
	int SensorID;			// Sensor ID: defined at "HW_Init.h"
	int SlaveAddr;			// Device ID
	int nDisplayX;			// Image size x
	int nDisplayY;			// Image size y
	int iDataFormat;		//DataFormat : 0 - YUV, 1 - 8bit bayer, 2 - 10bit bayer
	int OutMode;			//OutMode  : if YUV : YCbYCr- 1, YCrYCb - 2, CbYCrY - 3, CrYCbY - 4
							//		     if Bayer: BGGR - 1, RGGB   - 2, GBRG   - 3, GRBG   - 4
	int IICMode;			//IIC Read/Write initial mode : if 8bit-1, 16bit-2 
	
} SENSOR_TYPE,SENSOR_TYPE2;
extern SENSOR_TYPE SensorType[];
extern SENSOR_TYPE2 SensorType2[];

#define NUM_SENSOR_TYPE (sizeof(SensorType) / sizeof(SENSOR_TYPE))
#define NUM_SENSOR_TYPE2 (sizeof(SensorType2) / sizeof(SENSOR_TYPE2))

 
/**************************************************************************************************
* void 	OnPlay(HWND hDlg)
* Description:
*       When PLAY button click, Sensor's initial set(register...)and Image display
* Inputs:
*      hDlg    : Dialog's handle
**************************************************************************************************/
void			OnPlay(HWND hDlg);

/**************************************************************************************************
* void	OnStop(HWND hDlg)
* Description:
*       When STOP button click, stop to image display
* Inputs:
*      hDlg    : Dialog's handle
**************************************************************************************************/
void			OnStop(HWND hDlg);

/**************************************************************************************************
* void	OnSnapshot(HWND hDlg)
* Description:
*       When SNAPSHOT button click, image save to bmp file.
* Inputs:
*      hDlg    : Dialog's handle
**************************************************************************************************/
void			OnSnapshot(HWND hDlg);

/**************************************************************************************************
* void	ListOut(HWND hDlg, LPCSTR format,...)
* Description:
*      Print out of dialog's list box
* Inputs:
*      hDlg    : Dialog's handle
*	   format  : such as 'printf' function.
**************************************************************************************************/
void			ListOut(HWND hDlg, LPCSTR format,...);

/**************************************************************************************************
* void	OnClearLog(HWND hDlg)
* Description:
*      Dialog's list box clear.
* Inputs:
*      hDlg    : Dialog's handle
**************************************************************************************************/
void			OnClearLog(HWND hDlg);

/**************************************************************************************************
* void	myDelay(DWORD millisec)
* Description:
*      Delay time insert.
* Inputs:
*      millisec   : wanted time with millisecond
**************************************************************************************************/
void			myDelay(DWORD millisec);

/**************************************************************************************************
* void	OnIICWidth(HWND hDlg)
* Description:
*      I2C mode change
* Inputs:
*      hDlg    : handle
**************************************************************************************************/
void			OnIICWidth(HWND hDlg);

/**************************************************************************************************
* void			OnRegWrite(HWND hDlg)
* Description:
*      When Write button click on dialog ,I2C write
* Inputs:
*      hDlg    : handle
**************************************************************************************************/
void			OnRegWrite(HWND hDlg);

/**************************************************************************************************
* void			OnRegRead(HWND hDlg)
* Description:
*      When Read button click on dialog ,I2C read
* Inputs:
*      hDlg    : handle
**************************************************************************************************/
void			OnRegRead(HWND hDlg);

/**************************************************************************************************
* BOOL			IIC_Write_Proc(int mode, WORD wRegAddr, WORD wRegData)
* Description:
*      write byte data from I2C device
* Inputs:
*      mode		   :  I2C mode : 8it / 16bit
*      wRegAddr    :   Address
*	   wRegData    :   Data to be write
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL			IIC_Write_Proc(int mode, WORD wRegAddr, WORD wRegData);

/**************************************************************************************************
* WORD			IIC_Read_Proc(int mode, WORD wRegAddr)
* Description:
*      Read byte data from I2C device
* Inputs:
*      mode		   :  I2C mode : 8it / 16bit
*      wRegAddr    :   Address
* Return:
*      WORD		   :  Data read
**************************************************************************************************/
WORD			IIC_Read_Proc(int mode, WORD wRegAddr);

/**************************************************************************************************
* BOOL			SetRegFile(HWND hDlg, char *filename)
* Description:
*      Select register file(file format is "*.set") on window dialog 
* Inputs:
*      hDlg		   :   handle
*      filename    :   selected file's name.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL			SetRegFile(HWND hDlg, char *filename);
BOOL			SetRegFile2(char *filename);

/**************************************************************************************************
* BOOL			ParseRegisterFile(char *filename)
* Description:
*		Write to register file(file format is "*.set") with I2C commnand
* Inputs:
*      filename    :   set file's name.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL			ParseRegisterFile(char *filename);

/**************************************************************************************************
* BOOL			ParseRegisterFileBoard(char *filename)
* Description:
*		Write to ini file(file format is "*.set") with I2C commnand
* Inputs:
*      filename    :   set file's name.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL		ParseRegisterFileBoard(char *filename);

/**************************************************************************************************
* BOOL			RawToBmp(BYTE *pDataBuffer)
* Description:
*		 Convert sensor's Bayer data to BMP format data.
*		 Implemented 3x3 Interpolation data
* Inputs:
*      pDataBuffer :   Input buffer (raw data)
* Outputs:
*      m_pBmpBuffer :  Output buffer : Global variable.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
void			RawToBmp(BYTE *pDataBuffer);

/**************************************************************************************************
* BOOL			SaveImageToBmpFile(void)
* Description:
*		 Image save to bmp file format.
* Inputs:
*       m_pBmpBuffer :  Image buffer : Global variable.
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL			SaveImageToBmpFile(void);

/**************************************************************************************************
* BOOL			SaveImageToRawFile(void)
* Description:
*		 Image save to raw file format.
* Inputs:
*      None			:check  �� ��!!
* Return:
*      TRUE        :   Success
*      FALSE       :   Fail
**************************************************************************************************/
BOOL			SaveImageToRawFile(void);


/**************************************************************************************************
* void			MakeThread()
* Description:
*		 Create dual thread : Date thread/ Display thread
*		 need to thread function :refer "Date_thread" / "Display_thread"
*		 When mode is 'PLAY', create / when mode is 'STOP', delete.
**************************************************************************************************/
void			MakeThread();


/**************************************************************************************************
* DWORD WINAPI	Data_Thread(LPVOID Temp)
* Description:
*		 Get Sensor's data and insert to buffer 
*		 Data's whole size have to set multiple of 512 
*		 example : IMAGESIZE_X*IMAGESIZE_Y = 512 * x
* Return:
*      0    :Infinite loop 
**************************************************************************************************/
DWORD WINAPI	Data_Thread(LPVOID Temp);

/**************************************************************************************************
* DWORD WINAPI	Display_Thread(LPVOID Temp)
* Description:
*		 Convert to bmp buffer and display 
*		  
* Return:
*      0    :Infinite loop 
**************************************************************************************************/
DWORD WINAPI	Display_Thread(LPVOID Temp);



/**************************************************************************************************
* void			Display_frame( HWND hDlg)
* Description:
*		Frame rate of image display.
**************************************************************************************************/
void			Display_frame(HWND hDlg);

/**************************************************************************************************
* void			DisplayImage(HDC hDC);
* Description:
*		Image display to main frame from PC's DC.
* Inputs:
*      hDC		   :   Memory DC
**************************************************************************************************/
void			DisplayImage(HDC hDC);

/**************************************************************************************************
* void			DisplayImage2(HDC hDC, int ImageXpos, int ImageYpos)
* Description:
*		The image display with resolution size of the monitor. 
*		If image size is bigger than monitor's resolution and reduce integer is true.
*      
* Inputs:
*      hDC			:   Memory DC
*	  img_xsize		:	Resize width.
*	  img_ysize		:	Resize height.
**************************************************************************************************/
void			DisplayImage2(HDC hDC, int ImageXpos, int ImageYpos);

/**************************************************************************************************
* void			DisplayImageToScreen(HWND hWnd, const  __int16 img_xsize, const __int16 img_ysize)
* Description:
*		This function is called to Display2(); 
*		    
* Inputs:
*      hWnd			:   Current handle.
*	   img_xsize	:	Resize width.
*	   img_ysize	:	Resize height.
**************************************************************************************************/
void			DisplayImageToScreen(HWND hWnd, const  __int16 img_xsize, const __int16 img_ysize);

/**************************************************************************************************
* void			Draw(HDC pDC,UINT id, int dx, int dy,int left, int top, int sw, int sh)
* Description:
*		Main Dialog's Bitmap paint.
*		    
* Inputs:
*      pDC			:   DC
*	   id			:	Resource ID
*	   dx			:	Bitmap's new posion x
*	   dy			:   Bitmap's new posion x
*      left			:	Bitmap's org posion x
*	   top			:	Bitmap's org posion x
*	   sw			:	width
*      sh			:	height
**************************************************************************************************/
void			Draw(HDC pDC,UINT id, int dx, int dy,int left, int top, int sw, int sh);

/**************************************************************************************************
* void			OnGetIndex(HWND hDlg)
* Description:
*		Select vision cam's index		    
* Inputs:
*      hDlg			:   handle.
**************************************************************************************************/
void			OnGetIndex(HWND hDlg);

/**************************************************************************************************
* void			SetDlgItemFloat(HWND hDlg, int nIDDlgItem, float fValue);
* Description:
*		Dialog's float 		    
* Inputs:
*      hDlg			:   handle.
*	   nIDDlgItem	:   Dialog's ID
*	   fValue		:   float value
**************************************************************************************************/
void			SetDlgItemFloat(HWND hDlg, int nIDDlgItem, float fValue);

/**************************************************************************************************
* void			OnInterpolation(HWND hDlg));
* Description:
*		Interpolation on / off
* Inputs:
*      hDlg			:   handle.
**************************************************************************************************/
void			OnInterpolation(HWND hDlg);

/**************************************************************************************************
* void			OnDisplayMode(HWND hDlg)
* Description:
*		Display Preview fit function on/off
* Inputs:
*      hDlg			:   handle.
**************************************************************************************************/
void			OnDisplayMode(HWND hDlg);

/**************************************************************************************************
* void			Normal_Display()
* void			openCV_Display()
* Description:
*		Normal Display
*		openCV Display
* Inputs:
*      
*************************************************************************************************/
void			Normal_Display();

/**************************************************************************************************/
/*  User addition function     ...                                                                */
/**************************************************************************************************/
 
extern char	targetfileName[MAX_PATH];
extern BOOL	bTargetFile;

void	openCV_Display();
void	deleteDetection();
BOOL	TM_targetFile();

void	Start_AVI(bool mode);
void	Stop_AVI();

BOOL	FindFile(LPCTSTR name);
BOOL	SaveImageFileByOpenCV();

void	processing();
void	noprocessing(int mode);

#endif /* _HYIMAGE_H_ */
