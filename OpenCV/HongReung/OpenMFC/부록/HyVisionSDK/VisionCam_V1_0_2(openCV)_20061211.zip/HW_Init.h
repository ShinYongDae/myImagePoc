#ifndef _HW_Init_H_
#define _HW_Init_H_

 
#define		MT9T001			0
#define		HV7131R			1
 
extern char rootdir[MAX_PATH];	//current program initial directory.

/**************************************************************************************************
* void	SensorRegInit(int SensorID, int Xsize)
* Description:
*      I2C setting of selected sensor
* Inputs:
*      SensorID     :	SensorID (it defined above part)
*	   Xsize		:	Selected size 
**************************************************************************************************/
void	SensorRegInit(int SensorID, int Xsize);

/**************************************************************************************************
* void	SensorRecognition(int Id_check)
* Description:
*      Sensor recognition with Sensor origianl ID
* Inputs:
*      Id_check     :	Vision's number.
**************************************************************************************************/
int		SensorRecognition(int Id_check);
 

/**************************************************************************************************
* BOOL	INIReadStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR lpDefault, LPTSTR lpReturn, DWORD nSize)
* Description:
*      Read to ini file 
* Inputs:
*      lpAppName     :	Section's name 
*	   lpKey		 :  key
*      lpDefault	 :  default value
*	   lpReturn		 :  have to read string.
*	   nSize		 :  size of buffer	
**************************************************************************************************/
BOOL	INIReadStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR lpDefault, LPTSTR lpReturn, DWORD nSize);

/**************************************************************************************************
* BOOL	INIWriteStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR str)
* Description:
*      Write to ini file 
* Inputs:
*      lpAppName     :	Section's name 
*	   lpKey		 :  key
*	   str			 :  have to write string.	
**************************************************************************************************/
BOOL	INIWriteStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR str);

#endif /* _HW_Init_H_ */