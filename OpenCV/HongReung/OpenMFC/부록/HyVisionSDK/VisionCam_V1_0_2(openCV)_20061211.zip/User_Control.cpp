/******************************************************************************************************
 * HyVISION USB2.0 VisionCAM
 * FILE: User_Control.CPP
		   - User define function for image signal processing
 
 * MAJOR FUNCTION :
 * Copyright (c) 2006	HyVISION SYSTEM Inc.  All right reserved.
 * AUTHOR	: KIMSY
 * REV. HISTORY :
 ******************************************************************************************************/
#include	<windows.h>
#include	<stdio.h>
#include	<string.h>
#include	<TCHAR.h>
#include	<io.h>
#include	<Commctrl.h>
#include	"resource.h"
#include	"hyimage.h"
#include	"HyCam.h"
#include	"User_Control.h"
#include	"USB20Interface.h"
#include	"HW_Init.h"
int			Shutter_delay;

HWND		gMironAeDlg;
HWND		gMagnaAeDlg;
HWND		gSplashDlg;
HWND		gOpenCVDlg;

BOOL		gOpenCV;
BOOL		gGRAY;
BOOL		gGRAYhisto;
BOOL		gBLUR;
BOOL		gCANNY;
BOOL		gFACEDETECTION;
BOOL		gTMATCHING;
BOOL		gAVI;

/**************************************************************************************************
* BOOL CALLBACK	ControlDlgProc(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
* Description:
*		 ISP Control Dialog for register of AE 
**************************************************************************************************/
BOOL CALLBACK	ControlDlgProc(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
{
	gMironAeDlg = hDlg;

	TCHAR	szRegAddr[25];
	char	filedir[MAX_PATH]={0};
	char	tmp_buf[9][10]={0};
	

	static HWND hShutter, hRgain, hGgain, hBgain;
	static HWND hDRgain, hDGgain, hDBgain;
	static int	iShutter_pos, iRGain_pos, iGGain_pos, iBGain_pos;
	static int	iDRGain_pos, iDGGain_pos, iDBGain_pos;

	DWORD		wTemp;
	LPSTR		lpAppName;
 	
	switch (Message)
	{
	case	WM_INITDIALOG:
 		
		hShutter = GetDlgItem(hDlg,IDC_INT_LOW_S);
		hRgain = GetDlgItem(hDlg,IDC_RGAIN_S);
		hGgain = GetDlgItem(hDlg,IDC_GGAIN_S);
		hBgain = GetDlgItem(hDlg,IDC_BGAIN_S);

		hDRgain = GetDlgItem(hDlg,IDC_DRGAIN_S);
		hDGgain = GetDlgItem(hDlg,IDC_DGGAIN_S);
		hDBgain = GetDlgItem(hDlg,IDC_DBGAIN_S);

		//////////////////////////////////////////////////////////////////////
		// Shutter control
		if(m_PlayMode == PLAY) iShutter_pos = IIC_Read16(ADD_SHUTTER, gDrvIndex);
		else iShutter_pos = 0; 
		
		// slider max!
		// 32767 -> 0x7fff
		SendMessage(hShutter,TBM_SETRANGE,TRUE,MAKELPARAM(1,32767)); 
		SendMessage(hShutter,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iShutter_pos));
		SetDlgItemInt(hDlg,IDC_INT_LOW_E,(LPARAM)(LONG)(iShutter_pos), TRUE);

		//////////////////////////////////////////////////////////////////////
		// R gain control
		if(m_PlayMode == PLAY) {
			iRGain_pos = IIC_Read16(ADD_RGAIN, gDrvIndex);
			iDRGain_pos = iRGain_pos >> 8;
			iRGain_pos = iRGain_pos & 0x00ff;
		}else{
			iRGain_pos = 0;
			iDRGain_pos = 0;
		}
		
		// register max!
		// AG=63
		SendMessage(hRgain,TBM_SETRANGE,TRUE,MAKELPARAM(0,63)); 
		SendMessage(hRgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iRGain_pos));
		SetDlgItemInt(hDlg,IDC_RGAIN_E,(LPARAM)(LONG)(iRGain_pos), TRUE);
		// DG=120
		SendMessage(hDRgain,TBM_SETRANGE,TRUE,MAKELPARAM(0,120)); 
		SendMessage(hDRgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iDRGain_pos));
		SetDlgItemInt(hDlg,IDC_DRGAIN_E,(LPARAM)(LONG)(iDRGain_pos), TRUE);

		//////////////////////////////////////////////////////////////////////
		// G gain control
		if(m_PlayMode == PLAY) {
			iGGain_pos = IIC_Read16(ADD_GGAIN, gDrvIndex);
			iDGGain_pos = iGGain_pos >> 8;
			iGGain_pos = iGGain_pos & 0x00ff;
		}else{
			iGGain_pos = 0;
			iDGGain_pos = 0;
		}
		
		// register max!
		// AG=63
		
		SendMessage(hGgain,TBM_SETRANGE,TRUE,MAKELPARAM(0,63)); 
		SendMessage(hGgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iGGain_pos));
		SetDlgItemInt(hDlg,IDC_GGAIN_E,(LPARAM)(LONG)(iGGain_pos), TRUE);
		// DG=120
		SendMessage(hDGgain,TBM_SETRANGE,TRUE,MAKELPARAM(0,120)); 
		SendMessage(hDGgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iDGGain_pos));
		SetDlgItemInt(hDlg,IDC_DGGAIN_E,(LPARAM)(LONG)(iDGGain_pos), TRUE);

		//////////////////////////////////////////////////////////////////////
		// B gain control
		if(m_PlayMode == PLAY) {
			iBGain_pos = IIC_Read16(ADD_BGAIN, gDrvIndex);
			iDBGain_pos = iBGain_pos >> 8;
			iBGain_pos = iBGain_pos & 0x00ff;
		}else{
			iBGain_pos = 0;
			iDBGain_pos = 0;
		}
		
		// register max!
		// AG=63
		SendMessage(hBgain,TBM_SETRANGE,TRUE,MAKELPARAM(0,63)); 
		SendMessage(hBgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iBGain_pos));
		SetDlgItemInt(hDlg,IDC_BGAIN_E,(LPARAM)(LONG)(iBGain_pos), TRUE);
		// DG=120
		SendMessage(hDBgain,TBM_SETRANGE,TRUE,MAKELPARAM(0,120)); 
		SendMessage(hDBgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iDBGain_pos));
		SetDlgItemInt(hDlg,IDC_DBGAIN_E,(LPARAM)(LONG)(iDBGain_pos), TRUE);
 	 

		//
		Shutter_delay=0;
		break;
	case	WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case	IDCANCEL:
			if(m_PlayMode == PLAY) {
			wsprintf(filedir, "HVS_ISP%d_MT9T001", gDrvIndex);
			lpAppName = filedir;
			GetDlgItemText(hDlg, IDC_INT_LOW_E,  tmp_buf[0], 20);
			GetDlgItemText(hDlg, IDC_RGAIN_E,  tmp_buf[1], 20);
			GetDlgItemText(hDlg, IDC_DRGAIN_E,  tmp_buf[2], 20);
			GetDlgItemText(hDlg, IDC_GGAIN_E,  tmp_buf[3], 20);
			GetDlgItemText(hDlg, IDC_DGGAIN_E,  tmp_buf[4], 20);
			GetDlgItemText(hDlg, IDC_BGAIN_E,  tmp_buf[5], 20);
			GetDlgItemText(hDlg, IDC_DBGAIN_E,  tmp_buf[6], 20);
 			
			INIWriteStringVision(lpAppName,"Shutter",tmp_buf[0]);
			INIWriteStringVision(lpAppName,"A_RGAIN",tmp_buf[1]);
			INIWriteStringVision(lpAppName,"D_RGAIN",tmp_buf[2]);
			INIWriteStringVision(lpAppName,"A_GGAIN",tmp_buf[3]);
			INIWriteStringVision(lpAppName,"D_GGAIN",tmp_buf[4]);
 			INIWriteStringVision(lpAppName,"A_BGAIN",tmp_buf[5]);
			INIWriteStringVision(lpAppName,"D_BGAIN",tmp_buf[6]);
			
			}
			gMironAeDlg=NULL;
			DestroyWindow(hDlg);
			break;
 		case IDC_INPUT:
			GetDlgItemText(hDlg, IDC_INT_LOW_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iShutter_pos);
			if(iShutter_pos < 1 ) SetDlgItemInt(hDlg, IDC_INT_LOW_E, iShutter_pos = 1, FALSE);
			if(iShutter_pos > 65536 ) SetDlgItemInt(hDlg, IDC_INT_LOW_E, iShutter_pos =65536, FALSE);
			
			SendMessage(hShutter, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iShutter_pos));
			if(m_PlayMode == PLAY) IIC_Write16(ADD_SHUTTER,(WORD)iShutter_pos, gDrvIndex);
			break;

		case IDC_RGAIN_INPUT:
			GetDlgItemText(hDlg, IDC_RGAIN_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iRGain_pos);

			if(iRGain_pos < 0 ) SetDlgItemInt(hDlg, IDC_RGAIN_E, iRGain_pos = 0, FALSE);
			if(iRGain_pos > 63 ) SetDlgItemInt(hDlg, IDC_RGAIN_E, iRGain_pos = 63, FALSE);

			SendMessage(hRgain, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iRGain_pos));
			if(m_PlayMode == PLAY) {
				wTemp = IIC_Read16(ADD_RGAIN, gDrvIndex);

				wTemp = (wTemp & 0xff00) + (iRGain_pos);

				IIC_Write16(ADD_RGAIN,(WORD)wTemp, gDrvIndex);
			}
			break;

		case IDC_DRGAIN_INPUT:
			GetDlgItemText(hDlg, IDC_DRGAIN_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iDRGain_pos);

			if(iDRGain_pos < 0 )  SetDlgItemInt(hDlg, IDC_DRGAIN_E, iDRGain_pos = 0, FALSE);
			if(iDRGain_pos > 120 )SetDlgItemInt(hDlg, IDC_DRGAIN_E, iDRGain_pos = 120, FALSE);

			SendMessage(hDRgain, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iDRGain_pos));
			if(m_PlayMode == PLAY) {
				wTemp = IIC_Read16(ADD_RGAIN, gDrvIndex);

				wTemp = wTemp & 0x00ff;
				wTemp = (iDRGain_pos << 8) + wTemp;

				IIC_Write16(ADD_RGAIN,(WORD)wTemp, gDrvIndex);
			}
			break;

		case IDC_GGAIN_INPUT:
			GetDlgItemText(hDlg, IDC_GGAIN_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iGGain_pos);

			if(iGGain_pos < 0 ) SetDlgItemInt(hDlg, IDC_GGAIN_E, iGGain_pos = 0, FALSE);
			if(iGGain_pos > 63) SetDlgItemInt(hDlg, IDC_GGAIN_E, iGGain_pos = 63, FALSE);

			SendMessage(hGgain, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iGGain_pos));
			if(m_PlayMode == PLAY) {
				wTemp = IIC_Read16(ADD_GGAIN, gDrvIndex);
				wTemp = (wTemp & 0xff00) + (iGGain_pos);
				IIC_Write16(ADD_GGAIN,(WORD)wTemp, gDrvIndex);
			}
			break;
		case IDC_DGGAIN_INPUT:
			GetDlgItemText(hDlg, IDC_DGGAIN_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iDGGain_pos);

			if(iDGGain_pos < 0 )  SetDlgItemInt(hDlg, IDC_DGGAIN_E, iDGGain_pos = 0, FALSE);
			if(iDGGain_pos > 120 )SetDlgItemInt(hDlg, IDC_DGGAIN_E, iDGGain_pos = 120, FALSE);

			SendMessage(hDGgain, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iDGGain_pos));
			if(m_PlayMode == PLAY) {
				wTemp = IIC_Read16(ADD_GGAIN, gDrvIndex);

				wTemp = wTemp & 0x00ff;
				wTemp = (iDGGain_pos << 8) + wTemp;

				IIC_Write16(ADD_GGAIN,(WORD)wTemp, gDrvIndex);
			}
			break;
		case IDC_BGAIN_INPUT:
			GetDlgItemText(hDlg, IDC_BGAIN_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iBGain_pos);

			if(iBGain_pos < 0 ) SetDlgItemInt(hDlg, IDC_BGAIN_E, iBGain_pos = 0, FALSE);
			if(iBGain_pos > 63 ) SetDlgItemInt(hDlg, IDC_BGAIN_E, iBGain_pos = 63, FALSE);

			SendMessage(hBgain, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iBGain_pos));
			if(m_PlayMode == PLAY) {
				wTemp = IIC_Read16(ADD_BGAIN, gDrvIndex);

				wTemp = (wTemp & 0xff00) + (iBGain_pos);

				IIC_Write16(ADD_BGAIN,(WORD)wTemp, gDrvIndex);
			}
			break;

		case IDC_DBGAIN_INPUT:
			GetDlgItemText(hDlg, IDC_DBGAIN_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iDBGain_pos);

			if(iDBGain_pos < 0 )  SetDlgItemInt(hDlg, IDC_DBGAIN_E, iDBGain_pos = 0, FALSE);
			if(iDBGain_pos > 120 )SetDlgItemInt(hDlg, IDC_DBGAIN_E, iDBGain_pos = 120, FALSE);

			SendMessage(hDBgain, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iDBGain_pos));
			if(m_PlayMode == PLAY) {
				wTemp = IIC_Read16(ADD_BGAIN, gDrvIndex);

				wTemp = wTemp & 0x00ff;
				wTemp = (iDBGain_pos << 8) + wTemp;

				IIC_Write16(ADD_BGAIN,(WORD)wTemp, gDrvIndex);
			}
			break;

		case IDC_DEFAULT_SET:
			//////////////////////////////////////////////////////////////////////
			//
			IIC_Write16(ADD_SHUTTER, 0x047e, gDrvIndex);
			iShutter_pos=1150;
			SendMessage(hShutter,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iShutter_pos));
			SetDlgItemInt(hDlg,IDC_INT_LOW_E,(LPARAM)(LONG)(iShutter_pos), TRUE);

			//////////////////////////////////////////////////////////////////////
			//
			IIC_Write16(ADD_RGAIN, 0x051e, gDrvIndex);
			iRGain_pos = 30;
			iDRGain_pos = 10;
			SendMessage(hRgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iRGain_pos));
			SetDlgItemInt(hDlg,IDC_RGAIN_E,(LPARAM)(LONG)(iRGain_pos), TRUE);
			SendMessage(hDRgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iDRGain_pos));
			SetDlgItemInt(hDlg,IDC_DRGAIN_E,(LPARAM)(LONG)(iDRGain_pos), TRUE);
			
			//////////////////////////////////////////////////////////////////////
			//
			IIC_Write16(ADD_GGAIN, 0x051e, gDrvIndex);
			iGGain_pos = 30;
			iDGGain_pos = 10;
			SendMessage(hGgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iGGain_pos));
			SetDlgItemInt(hDlg,IDC_GGAIN_E,(LPARAM)(LONG)(iGGain_pos), TRUE);
			SendMessage(hDGgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iDGGain_pos));
			SetDlgItemInt(hDlg,IDC_DGGAIN_E,(LPARAM)(LONG)(iDGGain_pos), TRUE);
			
			//////////////////////////////////////////////////////////////////////
			//
			IIC_Write16(ADD_BGAIN, 0x051e, gDrvIndex);
			iBGain_pos = 30;
			iDBGain_pos = 10;
			SendMessage(hBgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iBGain_pos));
			SetDlgItemInt(hDlg,IDC_BGAIN_E,(LPARAM)(LONG)(iBGain_pos), TRUE);
			SendMessage(hDBgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iDBGain_pos));
			SetDlgItemInt(hDlg,IDC_DBGAIN_E,(LPARAM)(LONG)(iDBGain_pos), TRUE);
			
			break;
		}

	case	WM_HSCROLL:
 		if( (HWND)lParam == hShutter ){
 		 	iShutter_pos = SendMessage( hShutter, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_INT_LOW_E, iShutter_pos, TRUE);
			if(m_PlayMode == PLAY) {
				Shutter_delay++;
 			 	// �ʼ� Delay -> ������ Sensor�� �״´�.
				if((Shutter_delay%5)==0){
			 	IIC_Write16(ADD_SHUTTER,(WORD)iShutter_pos, gDrvIndex);
				Shutter_delay=0;
				}
			}
		}

		///////////////////////////
		// R Gain control
		// AG
		if( (HWND)lParam == hRgain ){
		 	iRGain_pos = SendMessage( hRgain, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_RGAIN_E, iRGain_pos, TRUE);
			if(m_PlayMode == PLAY) {
				wTemp = IIC_Read16(ADD_RGAIN, gDrvIndex);

				wTemp = wTemp & 0xff00;
				wTemp = wTemp + iRGain_pos;

				Sleep(100);  // �ʼ� Delay -> ������ Sensor�� �״´�.
				IIC_Write16(ADD_RGAIN,(WORD)wTemp, gDrvIndex);
			}
		}
		// DG
		if( (HWND)lParam == hDRgain ){
		 	iDRGain_pos = SendMessage( hDRgain, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_DRGAIN_E, iDRGain_pos, TRUE);
			if(m_PlayMode == PLAY) {
				wTemp = IIC_Read16(ADD_RGAIN, gDrvIndex);

				wTemp = wTemp & 0x00ff;
				wTemp = ( iDRGain_pos << 8 ) + wTemp;

				Sleep(100);  // �ʼ� Delay -> ������ Sensor�� �״´�.
				IIC_Write16(ADD_RGAIN,(WORD)wTemp, gDrvIndex);
			}
		}

		///////////////////////////
		// G Gain control
		// AG
		if( (HWND)lParam == hGgain ){
		 	iGGain_pos = SendMessage( hGgain, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_GGAIN_E, iGGain_pos, TRUE);
			if(m_PlayMode == PLAY) {
				//--------------------------------
				wTemp = IIC_Read16(ADD_GGAIN, gDrvIndex);

				wTemp = wTemp & 0xff00;
				wTemp = wTemp + iGGain_pos;

				Sleep(50);  // �ʼ� Delay -> ������ Sensor�� �״´�.
				IIC_Write16(ADD_GGAIN,(WORD)wTemp, gDrvIndex);
			}
		}
		// DG
		if( (HWND)lParam == hDGgain ){
		 	iDGGain_pos = SendMessage( hDGgain, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_DGGAIN_E, iDGGain_pos, TRUE);
			if(m_PlayMode == PLAY) {
				//--------------------------------
				wTemp = IIC_Read16(ADD_GGAIN, gDrvIndex);

				wTemp = wTemp & 0x00ff;
				wTemp = ( iDGGain_pos << 8 ) + wTemp;

				Sleep(50);  // �ʼ� Delay -> ������ Sensor�� �״´�.
				IIC_Write16(ADD_GGAIN,(WORD)wTemp, gDrvIndex);
			}
		}

		///////////////////////////
		// B Gain control
		// AG
		if( (HWND)lParam == hBgain ){
		 	iBGain_pos = SendMessage( hBgain, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_BGAIN_E, iBGain_pos, TRUE);
			if(m_PlayMode == PLAY) {
				wTemp = IIC_Read16(ADD_BGAIN, gDrvIndex);

				wTemp = wTemp & 0xff00;
				wTemp = wTemp + iBGain_pos;

				Sleep(100);  // �ʼ� Delay -> ������ Sensor�� �״´�.
 				IIC_Write16(ADD_BGAIN,(WORD)wTemp, gDrvIndex);
			}
		}
		// DG
		if( (HWND)lParam == hDBgain ){
		 	iDBGain_pos = SendMessage( hDBgain, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_DBGAIN_E, iDBGain_pos, TRUE);
			if(m_PlayMode == PLAY) {
				wTemp = IIC_Read16(ADD_BGAIN, gDrvIndex);

				wTemp = wTemp & 0x00ff;
				wTemp = ( iDBGain_pos << 8 ) + wTemp;

				Sleep(100);  // �ʼ� Delay -> ������ Sensor�� �״´�.
 				IIC_Write16(ADD_BGAIN,(WORD)wTemp, gDrvIndex);
			}
		}
 
		break;
	}
	return 0;

}

/**************************************************************************************************
* BOOL CALLBACK	ControlDlgProc2(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
* Description:
*		 ISP Control Dialog for register of AE  : HV7131R
**************************************************************************************************/
BOOL CALLBACK	ControlDlgProc2(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
{
	gMagnaAeDlg= hDlg;

	TCHAR	szRegAddr[25];

	static HWND hInt_time_high,hInt_time_middle,hInt_time_low;
	static HWND	hRgain, hGgain, hBgain;

	static int	iInt_time_high_pos,iInt_time_middle_pos,iInt_time_low_pos;
	static int	iRGain_pos, iGGain_pos, iBGain_pos;
	DWORD		wTemp;
	LPSTR		lpAppName;
  	char		filedir[MAX_PATH]={0};
	char		tmp_buf[6][10]={0};
	switch(Message) {
	case WM_INITDIALOG:

		hInt_time_high = GetDlgItem(hDlg,IDC_INT_TIME_HIGH);
		hInt_time_middle = GetDlgItem(hDlg,IDC_INT_TIME_MIDDLE);
		hInt_time_low = GetDlgItem(hDlg,IDC_INT_TIME_LOW);
		
		hRgain = GetDlgItem(hDlg,IDC_RGAIN_S2);
		hGgain = GetDlgItem(hDlg,IDC_GGAIN_S2);
		hBgain = GetDlgItem(hDlg,IDC_BGAIN_S2);
	
		
		if(m_PlayMode == PLAY) {
			iInt_time_high_pos		= IIC_Read(INT_TIME_HIGH,gDrvIndex);
			iInt_time_middle_pos	= IIC_Read(INT_TIME_MIDDLE,gDrvIndex);
			iInt_time_low_pos		= IIC_Read(INT_TIME_LOW,gDrvIndex);
		}
		else {
			iInt_time_high_pos		= 0; 
			iInt_time_middle_pos	= 0;
			iInt_time_low_pos		= 0;
		}

		SendMessage(hInt_time_high,TBM_SETRANGE,TRUE,MAKELPARAM(0,255)); 
		SendMessage(hInt_time_high,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iInt_time_high_pos));
		SetDlgItemInt(hDlg,IDC_INT_ITME_HIGH_E,(LPARAM)(LONG)(iInt_time_high_pos), TRUE);
		
		SendMessage(hInt_time_middle,TBM_SETRANGE,TRUE,MAKELPARAM(0,255)); 
		SendMessage(hInt_time_middle,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iInt_time_middle_pos));
		SetDlgItemInt(hDlg,IDC_INT_ITME_MIDDLE_E,(LPARAM)(LONG)(iInt_time_middle_pos), TRUE);
		
		SendMessage(hInt_time_low,TBM_SETRANGE,TRUE,MAKELPARAM(0,255)); 
		SendMessage(hInt_time_low,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iInt_time_low_pos));
		SetDlgItemInt(hDlg,IDC_INT_ITME_LOW_E,(LPARAM)(LONG)(iInt_time_low_pos), TRUE);
		
		// R gain control
		if(m_PlayMode == PLAY) {
			iRGain_pos = IIC_Read(R_COLORGAIN , gDrvIndex);
			iGGain_pos = IIC_Read(G_COLORGAIN , gDrvIndex);
			iBGain_pos = IIC_Read(B_COLORGAIN , gDrvIndex);
		}else{
			iRGain_pos = 0;
			iGGain_pos = 0;
			iBGain_pos = 0;
		}
 		SendMessage(hRgain,TBM_SETRANGE,TRUE,MAKELPARAM(0,63)); 
		SendMessage(hRgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iRGain_pos));
		SetDlgItemInt(hDlg,IDC_RGAIN_E,(LPARAM)(LONG)(iRGain_pos), TRUE);
 
 		
		SendMessage(hGgain,TBM_SETRANGE,TRUE,MAKELPARAM(0,63)); 
		SendMessage(hGgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iGGain_pos));
		SetDlgItemInt(hDlg,IDC_GGAIN_E,(LPARAM)(LONG)(iGGain_pos), TRUE);

		SendMessage(hBgain,TBM_SETRANGE,TRUE,MAKELPARAM(0,63)); 
		SendMessage(hBgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(iBGain_pos));
		SetDlgItemInt(hDlg,IDC_BGAIN_E,(LPARAM)(LONG)(iBGain_pos), TRUE);
 
	
		break;
	case	WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case	IDCANCEL:
			if(m_PlayMode == PLAY) {
			wsprintf(filedir, "HVS_ISP%d_HV7131R", gDrvIndex);
			lpAppName = filedir;
			GetDlgItemText(hDlg, IDC_INT_ITME_HIGH_E,  tmp_buf[0], 20);
			GetDlgItemText(hDlg, IDC_INT_ITME_MIDDLE_E,  tmp_buf[1], 20);
			GetDlgItemText(hDlg, IDC_INT_ITME_LOW_E,  tmp_buf[2], 20);
			GetDlgItemText(hDlg, IDC_RGAIN_E,  tmp_buf[3], 20);
 			GetDlgItemText(hDlg, IDC_GGAIN_E,  tmp_buf[4], 20);
 			GetDlgItemText(hDlg, IDC_BGAIN_E,  tmp_buf[5], 20);
 			
			INIWriteStringVision(lpAppName,"INT_TIME_HIGH",tmp_buf[0]);
			INIWriteStringVision(lpAppName,"INT_TIME_MIDDLE",tmp_buf[1]);
			INIWriteStringVision(lpAppName,"INT_TIME_LOW",tmp_buf[2]);
			INIWriteStringVision(lpAppName,"R_GAIN",tmp_buf[3]);
			INIWriteStringVision(lpAppName,"G_GAIN",tmp_buf[4]);
			INIWriteStringVision(lpAppName,"B_GAIN",tmp_buf[5]);
			}
			gMagnaAeDlg=NULL;
			DestroyWindow(hDlg);
			break;
 		case IDC_INPUT_HIGH:
			GetDlgItemText(hDlg, IDC_INT_ITME_HIGH_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iInt_time_high_pos);
			if(iInt_time_high_pos < 0 ) SetDlgItemInt(hDlg, IDC_INT_ITME_HIGH_E, iInt_time_high_pos = 0, FALSE);
			if(iInt_time_high_pos > 255 ) SetDlgItemInt(hDlg, IDC_INT_ITME_HIGH_E, iInt_time_high_pos = 255, FALSE);
			
			SendMessage(hInt_time_high, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iInt_time_high_pos));
			if(m_PlayMode == PLAY) {
				IIC_Write(INT_TIME_HIGH,(WORD)iInt_time_high_pos,gDrvIndex);
				IIC_Write(INT_TIME_MIDDLE,(WORD)iInt_time_middle_pos,gDrvIndex);
				IIC_Write(INT_TIME_LOW,(WORD)iInt_time_low_pos,gDrvIndex);
				
			}
			break;
		case IDC_INPUT_MIDDLE:
			GetDlgItemText(hDlg, IDC_INT_ITME_MIDDLE_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iInt_time_middle_pos);
			if(iInt_time_middle_pos < 0 ) SetDlgItemInt(hDlg, IDC_INT_ITME_MIDDLE_E, iInt_time_middle_pos = 0, FALSE);
			if(iInt_time_middle_pos > 255 ) SetDlgItemInt(hDlg, IDC_INT_ITME_MIDDLE_E, iInt_time_middle_pos = 255, FALSE);
			
			SendMessage(hInt_time_middle, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iInt_time_middle_pos));
			if(m_PlayMode == PLAY) {
				IIC_Write(INT_TIME_HIGH,(WORD)iInt_time_high_pos,gDrvIndex);
				IIC_Write(INT_TIME_MIDDLE,(WORD)iInt_time_middle_pos,gDrvIndex);
				IIC_Write(INT_TIME_LOW,(WORD)iInt_time_low_pos,gDrvIndex);
			}				
			break;
			
		case IDC_INPUT_LOW:
			GetDlgItemText(hDlg, IDC_INT_ITME_LOW_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iInt_time_low_pos);

			if(iInt_time_low_pos < 0 ) SetDlgItemInt(hDlg, IDC_INT_ITME_LOW_E, iInt_time_low_pos = 0, FALSE);
			if(iInt_time_low_pos > 255 ) SetDlgItemInt(hDlg, IDC_INT_ITME_LOW_E, iInt_time_low_pos = 255, FALSE);
			
			SendMessage(hInt_time_low, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iInt_time_low_pos));
			if(m_PlayMode == PLAY){
				IIC_Write(INT_TIME_HIGH,(WORD)iInt_time_high_pos,gDrvIndex);
				IIC_Write(INT_TIME_MIDDLE,(WORD)iInt_time_middle_pos,gDrvIndex);
				IIC_Write(INT_TIME_LOW,(WORD)iInt_time_low_pos,gDrvIndex);
			}				
			break;
			
			
		case IDC_RGAIN_INPUT:
			GetDlgItemText(hDlg, IDC_RGAIN_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iRGain_pos);

			if(iRGain_pos < 0 ) SetDlgItemInt(hDlg, IDC_RGAIN_E, iRGain_pos = 0, FALSE);
			if(iRGain_pos > 63 ) SetDlgItemInt(hDlg, IDC_RGAIN_E, iRGain_pos = 63, FALSE);

			SendMessage(hRgain, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iRGain_pos));
			if(m_PlayMode == PLAY) {
  				IIC_Write(R_COLORGAIN,(WORD)iRGain_pos,gDrvIndex);
			}
			break;

		case IDC_GGAIN_INPUT:
			GetDlgItemText(hDlg, IDC_GGAIN_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iGGain_pos);

			if(iGGain_pos < 0 ) SetDlgItemInt(hDlg, IDC_GGAIN_E, iGGain_pos = 0, FALSE);
			if(iGGain_pos > 63 ) SetDlgItemInt(hDlg, IDC_GGAIN_E, iGGain_pos = 63, FALSE);

			SendMessage(hGgain, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iGGain_pos));
			if(m_PlayMode == PLAY) {
 				IIC_Write(G_COLORGAIN,(WORD)iGGain_pos,gDrvIndex);
			}
			break;
	
		case IDC_BGAIN_INPUT:
			GetDlgItemText(hDlg, IDC_BGAIN_E, szRegAddr, 10);
			_stscanf(szRegAddr, "%d", &iBGain_pos);

			if(iBGain_pos < 0 ) SetDlgItemInt(hDlg, IDC_BGAIN_E, iBGain_pos = 0, FALSE);
			if(iBGain_pos > 63  ) SetDlgItemInt(hDlg, IDC_BGAIN_E, iBGain_pos = 63, FALSE);

			SendMessage(hBgain, TBM_SETPOS, TRUE,(LPARAM)(LONG)(iBGain_pos));
			if(m_PlayMode == PLAY) {
 				wTemp =  (iBGain_pos);
 				IIC_Write(B_COLORGAIN,(WORD)wTemp ,gDrvIndex);
			}
			break;
 
		case IDC_DEFAULT_SET:

			SendMessage(hInt_time_high,TBM_SETPOS,TRUE,(LPARAM)(LONG)(DATA_INT_TIME_HIGH));
			SetDlgItemInt(hDlg,IDC_INT_ITME_HIGH_E,(LPARAM)(LONG)(DATA_INT_TIME_HIGH), TRUE);
			iInt_time_high_pos = DATA_INT_TIME_HIGH;

			SendMessage(hInt_time_middle,TBM_SETPOS,TRUE,(LPARAM)(LONG)(DATA_INT_TIME_MIDDLE));
			SetDlgItemInt(hDlg,IDC_INT_ITME_MIDDLE_E,(LPARAM)(LONG)(DATA_INT_TIME_MIDDLE), TRUE);
			iInt_time_middle_pos = DATA_INT_TIME_MIDDLE;

			SendMessage(hInt_time_low,TBM_SETPOS,TRUE,(LPARAM)(LONG)(DATA_INT_TIME_LOW));
			SetDlgItemInt(hDlg,IDC_INT_ITME_LOW_E,(LPARAM)(LONG)(DATA_INT_TIME_LOW), TRUE);
			iInt_time_low_pos = DATA_INT_TIME_LOW;
 
			// Integration time
 			IIC_Write(INT_TIME_HIGH,(WORD)iInt_time_high_pos,gDrvIndex);
			IIC_Write(INT_TIME_MIDDLE,(WORD)iInt_time_middle_pos,gDrvIndex);
			IIC_Write(INT_TIME_LOW,(WORD)iInt_time_low_pos,gDrvIndex);
			
			// R gain
			SendMessage(hRgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(DATA_R_COLORGAIN));
			SetDlgItemInt(hDlg,IDC_RGAIN_E,(LPARAM)(LONG)(DATA_R_COLORGAIN), TRUE);
			iRGain_pos = DATA_R_COLORGAIN;
			IIC_Write(R_COLORGAIN,(WORD)iRGain_pos,gDrvIndex);
 
			// G gain
			SendMessage(hGgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(DATA_G_COLORGAIN));
			SetDlgItemInt(hDlg,IDC_GGAIN_E,(LPARAM)(LONG)(DATA_G_COLORGAIN), TRUE);
			iGGain_pos = DATA_G_COLORGAIN;
			IIC_Write(G_COLORGAIN,(WORD)iGGain_pos,gDrvIndex);
  
			// B gain
			SendMessage(hBgain,TBM_SETPOS,TRUE,(LPARAM)(LONG)(DATA_B_COLORGAIN));
			SetDlgItemInt(hDlg,IDC_BGAIN_E,(LPARAM)(LONG)(DATA_B_COLORGAIN), TRUE);
			iBGain_pos = DATA_B_COLORGAIN;
			IIC_Write(B_COLORGAIN,(WORD)iBGain_pos,gDrvIndex);
 
			break;
		}
	case	WM_HSCROLL:

		// integration time
		if( (HWND)lParam == hInt_time_high ){
		 	iInt_time_high_pos = SendMessage( hInt_time_high, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_INT_ITME_HIGH_E, iInt_time_high_pos, TRUE);
			if(m_PlayMode == PLAY) {
				Sleep(100);  // �ʼ� Delay -> ������ ���尡 �״´�.
				IIC_Write(INT_TIME_HIGH,(WORD)iInt_time_high_pos,gDrvIndex);
				IIC_Write(INT_TIME_MIDDLE,(WORD)iInt_time_middle_pos,gDrvIndex);
				IIC_Write(INT_TIME_LOW,(WORD)iInt_time_low_pos,gDrvIndex);
				
			}
		}
		if( (HWND)lParam == hInt_time_middle ){
			iInt_time_middle_pos = SendMessage( hInt_time_middle, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_INT_ITME_MIDDLE_E, iInt_time_middle_pos, TRUE);
			if(m_PlayMode == PLAY) {
				Sleep(100);  // �ʼ� Delay -> ������ ���尡 �״´�.
				IIC_Write(INT_TIME_HIGH,(WORD)iInt_time_high_pos,gDrvIndex);
				IIC_Write(INT_TIME_MIDDLE,(WORD)iInt_time_middle_pos,gDrvIndex);
				IIC_Write(INT_TIME_LOW,(WORD)iInt_time_low_pos,gDrvIndex);

			}
		}
		if( (HWND)lParam == hInt_time_low){
			iInt_time_low_pos = SendMessage( hInt_time_low, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_INT_ITME_LOW_E, iInt_time_low_pos, TRUE);
			if(m_PlayMode == PLAY) {
				Sleep(100);  // �ʼ� Delay -> ������ ���尡 �״´�.
				IIC_Write(INT_TIME_HIGH,(WORD)iInt_time_high_pos,gDrvIndex);
				IIC_Write(INT_TIME_MIDDLE,(WORD)iInt_time_middle_pos,gDrvIndex);
				IIC_Write(INT_TIME_LOW,(WORD)iInt_time_low_pos,gDrvIndex);
				
			}
		}

		

		///////////////////////////
		// R Gain control
 		if( (HWND)lParam == hRgain ){
		 	iRGain_pos = SendMessage( hRgain, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_RGAIN_E, iRGain_pos, TRUE);
			if(m_PlayMode == PLAY) {
 				Sleep(100);  // �ʼ� Delay -> ������ ���尡 �״´�.
				IIC_Write(R_COLORGAIN,(WORD)iRGain_pos,gDrvIndex);
			}
		}
 
		///////////////////////////
		// G Gain control
 		if( (HWND)lParam == hGgain ){
		 	iGGain_pos = SendMessage( hGgain, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_GGAIN_E, iGGain_pos, TRUE);
			if(m_PlayMode == PLAY) {
 				Sleep(50);  // �ʼ� Delay -> ������ ���尡 �״´�.
				IIC_Write(G_COLORGAIN,(WORD)iGGain_pos,gDrvIndex);
			}
		}
 		///////////////////////////
		// B Gain control
 		if( (HWND)lParam == hBgain ){
		 	iBGain_pos = SendMessage( hBgain, TBM_GETPOS, 0, 0);
			SetDlgItemInt(hDlg, IDC_BGAIN_E, iBGain_pos, TRUE);
			if(m_PlayMode == PLAY) {
			 
 				Sleep(100);  // �ʼ� Delay -> ������ ���尡 �״´�.
				IIC_Write(B_COLORGAIN,(WORD)iBGain_pos,gDrvIndex);
			}
		}

 		break;
	}
	
	return 0;
}

/**************************************************************************************************
* BOOL CALLBACK	OpenCVDlgProc(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
* Description:
*		 openCV Control Dialog 
**************************************************************************************************/
BOOL CALLBACK	OpenCVDlgProc(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
{
	char	buf[10];

	gOpenCVDlg = hDlg;

	switch (Message)
	{
	case	WM_INITDIALOG:

		if(gOpenCV)			SendMessage( GetDlgItem(hDlg, IDC_CV_ONOFF), BM_SETCHECK, BST_CHECKED, 0);
		if(gGRAY)			SendMessage( GetDlgItem(hDlg, IDC_CVGRAY_ONOFF), BM_SETCHECK, BST_CHECKED, 0);
		if(gBLUR)			SendMessage( GetDlgItem(hDlg, IDC_CVBLUR_ONOFF), BM_SETCHECK, BST_CHECKED, 0);
		if(gCANNY)			SendMessage( GetDlgItem(hDlg, IDC_CVCANNY_ONOFF), BM_SETCHECK, BST_CHECKED, 0);
		if(gFACEDETECTION)	SendMessage( GetDlgItem(hDlg, IDC_FACEDETECTION_ONOFF), BM_SETCHECK, BST_CHECKED, 0);
		if(gTMATCHING)		SendMessage( GetDlgItem(hDlg, IDC_CVTM_ONOFF), BM_SETCHECK, BST_CHECKED, 0);
		if(gGRAYhisto)		SendMessage( GetDlgItem(hDlg, IDC_CVGRAYHISTO_ONOFF), BM_SETCHECK, BST_CHECKED, 0);

		if(gTMATCHING){
			EnableWindow(GetDlgItem(hDlg, IDC_CVGRAY_ONOFF), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_CVBLUR_ONOFF), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_CVCANNY_ONOFF), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_FACEDETECTION_ONOFF), FALSE);
		}

		SetDlgItemText(hDlg, IDC_TM_IMG_NAME, targetfileName);
		
		break;
	case	WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
		case IDCANCEL:
			noprocessing(0);

			wsprintf(buf, "%d", gOpenCV);
			INIWriteStringVision("HVS_OPENCV","OPENCV_ONOFF",buf);
			wsprintf(buf, "%d", gGRAY);
			INIWriteStringVision("HVS_OPENCV","OPENCV_GRAY",buf);
			wsprintf(buf, "%d", gGRAYhisto);
			INIWriteStringVision("HVS_OPENCV","OPENCV_GRAY_HISTO",buf);
			wsprintf(buf, "%d", gBLUR);
			INIWriteStringVision("HVS_OPENCV","OPENCV_BLUR",buf);
			wsprintf(buf, "%d", gCANNY);
			INIWriteStringVision("HVS_OPENCV","OPENCV_CANNY",buf);
			wsprintf(buf, "%d", gFACEDETECTION);
			INIWriteStringVision("HVS_OPENCV","OPENCV_FACEDETECTION",buf);
			wsprintf(buf, "%d", gTMATCHING);
			INIWriteStringVision("HVS_OPENCV","OPENCV_T_MATCHING",buf);
			gAVI=FALSE;

			gOpenCVDlg=NULL;
			DestroyWindow(hDlg);
			break;

 		case IDC_CV_ONOFF:
			gOpenCV=!gOpenCV;
 			break;
		case IDC_CVGRAY_ONOFF:
			gGRAY=!gGRAY;
			break;
		case IDC_CVGRAYHISTO_ONOFF:
			gGRAYhisto=!gGRAYhisto;

			if(gGRAYhisto)	noprocessing(1);
			else			noprocessing(0);
			break;
		case IDC_CVBLUR_ONOFF:
			gBLUR=!gBLUR;
			break;
		case IDC_CVCANNY_ONOFF:
			gCANNY=!gCANNY;
			break;
		case IDC_FACEDETECTION_ONOFF:
			gFACEDETECTION=!gFACEDETECTION;
			break;
		case IDC_CVTM_ONOFF:

			gTMATCHING=!gTMATCHING;

			if(!bTargetFile && gTMATCHING) {
				SendMessage( GetDlgItem(hDlg, IDC_CVTM_ONOFF), BM_SETCHECK, BST_UNCHECKED, 0);
				MessageBox(NULL, "Select target file!!!", NULL, MB_OK);

				gTMATCHING=!gTMATCHING;
				break;
			}

			if(gTMATCHING){
			
				if(gGRAY) {
					gGRAY=FALSE;
					SendMessage( GetDlgItem(hDlg, IDC_CVGRAY_ONOFF), BM_SETCHECK, BST_UNCHECKED, 0);
				}
				if(gGRAYhisto){
					gGRAYhisto=FALSE;
					SendMessage( GetDlgItem(hDlg, IDC_CVGRAYHISTO_ONOFF), BM_SETCHECK, BST_UNCHECKED, 0);
				}
				if(gBLUR) {
					gBLUR=FALSE;
					SendMessage( GetDlgItem(hDlg, IDC_CVBLUR_ONOFF), BM_SETCHECK, BST_UNCHECKED, 0);
				}
				if(gCANNY) {
					gCANNY=FALSE;
					SendMessage( GetDlgItem(hDlg, IDC_CVCANNY_ONOFF), BM_SETCHECK, BST_UNCHECKED, 0);
				}
				if(gFACEDETECTION) {
					gFACEDETECTION=FALSE;
					SendMessage( GetDlgItem(hDlg, IDC_FACEDETECTION_ONOFF), BM_SETCHECK, BST_UNCHECKED, 0);
				}
				EnableWindow(GetDlgItem(hDlg, IDC_CVGRAY_ONOFF), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_CVBLUR_ONOFF), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_CVCANNY_ONOFF), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_FACEDETECTION_ONOFF), FALSE);
			}else{
				EnableWindow(GetDlgItem(hDlg, IDC_CVGRAY_ONOFF), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_CVBLUR_ONOFF), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_CVCANNY_ONOFF), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_FACEDETECTION_ONOFF), TRUE);
			}

			break;

		case IDC_TM_OPENIMAGE:
			if(TM_targetFile()) bTargetFile=TRUE;
			else				bTargetFile=FALSE;

			SetDlgItemText(hDlg, IDC_TM_IMG_NAME, targetfileName);
			break;
		case IDC_CVAVI_ONOFF:
			
			if(!gAVI){

				if (BST_CHECKED == SendDlgItemMessage(hDlg, IDC_CODEC_SELECTION, BM_GETCHECK, 0, 0)) {
					Start_AVI(1);
				}else{
					Start_AVI(0);
				}
			}else{
				Stop_AVI();
			}

			gAVI=!gAVI;

			break;
		}
	}

	return 0;
}

/**************************************************************************************************
* BOOL CALLBACK	SplashControl(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
* Description:
*		 Splash logo Control Dialog  
**************************************************************************************************/

BOOL CALLBACK	SplashControl(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
{
	HDC hdc;
  	PAINTSTRUCT		ps;
	RECT			SplashRect;
	int				pos_x,pos_y;
		
	gSplashDlg =hDlg;

	switch (Message)
	{
   case WM_INITDIALOG:
 	   GetWindowRect(hDlg,&SplashRect);
		pos_x =(int)SplashRect.right-SplashRect.left;
		pos_y =(int)SplashRect.bottom-SplashRect.top;
	    SetWindowPos(hDlg,NULL, ResolutionX/2-pos_x/2,ResolutionY/2-pos_y/2,SplashRect.right-SplashRect.left,SplashRect.bottom-SplashRect.top,0);
	   break; 
 
    case	WM_PAINT:
		   hdc = BeginPaint(hDlg, &ps);
 		   EndPaint (hDlg, &ps);
		   
		   return 0;	
   case	WM_CLOSE:
		   gSplashDlg=NULL;
		   DestroyWindow(hDlg);
 		   return 0;

	   	} //switch (LOWORD(wParam))
	return 0;
}
/**************************************************************************************************
* void	Read_User_Control_Set(void)
* Description:
*     Read setting value about ISP control
**************************************************************************************************/

void	Read_User_Control_Set(void)
{
	LPSTR	lpAppName;
	char	filedir[MAX_PATH]={0};
	char	buf_mode[10][10]={0};
  	WORD	wRegAddr, wRegData;
 
	if(currentDevice == MT9T001){
		wsprintf(filedir, "HVS_ISP%d_MT9T001", gDrvIndex);
 		lpAppName = filedir;
 
 		INIReadStringVision(lpAppName,"Shutter","1200",buf_mode[0],10);
 		INIReadStringVision(lpAppName,"A_RGAIN","8",buf_mode[1],10);
 		INIReadStringVision(lpAppName,"D_RGAIN","0",buf_mode[2],10);
 		INIReadStringVision(lpAppName,"A_GGAIN","7",buf_mode[3],10);
 		INIReadStringVision(lpAppName,"D_GGAIN","0",buf_mode[4],10);
 		INIReadStringVision(lpAppName,"A_BGAIN","8",buf_mode[5],10);
 		INIReadStringVision(lpAppName,"D_BGAIN","0",buf_mode[6],10);

		sscanf(buf_mode[0], "%d", &wRegAddr);	
 		IIC_Write16(ADD_SHUTTER,wRegAddr,gDrvIndex);
		myDelay(1);
		sscanf(buf_mode[1], "%d", &wRegAddr);
 		sscanf(buf_mode[2], "%d", &wRegData);
 		IIC_Write16(ADD_RGAIN,((wRegData<<8)+wRegAddr),gDrvIndex);
		myDelay(1);
		sscanf(buf_mode[3], "%d", &wRegAddr);	
		sscanf(buf_mode[4], "%d", &wRegData);	
		IIC_Write16(ADD_GGAIN,((wRegData <<8)+(wRegAddr)),gDrvIndex);
		myDelay(1);
		sscanf(buf_mode[5], "%d", &wRegAddr);	
		sscanf(buf_mode[6], "%d", &wRegData);
 		IIC_Write16(ADD_BGAIN,((wRegData <<8)+(wRegAddr)),gDrvIndex);
 
	}
	else {

		wsprintf(filedir, "HVS_ISP%d_HV7131R", gDrvIndex);
		lpAppName = filedir;
		
 		INIReadStringVision(lpAppName,"INT_TIME_HIGH","1",buf_mode[0],10);
		INIReadStringVision(lpAppName,"INT_TIME_MIDDLE","5",buf_mode[1],10);
		INIReadStringVision(lpAppName,"INT_TIME_LOW","20",buf_mode[2],10);
		INIReadStringVision(lpAppName,"R_GAIN","0",buf_mode[3],10);
		INIReadStringVision(lpAppName,"G_GAIN","0",buf_mode[4],10);
		INIReadStringVision(lpAppName,"B_GAIN","0",buf_mode[5],10);

		sscanf(buf_mode[0], "%x", &wRegAddr);	
		IIC_Write(INT_TIME_HIGH,wRegAddr,gDrvIndex);
		sscanf(buf_mode[1], "%x", &wRegAddr);	
		IIC_Write(INT_TIME_MIDDLE,wRegAddr,gDrvIndex);
		sscanf(buf_mode[2], "%x", &wRegAddr);	
		IIC_Write(INT_TIME_LOW,wRegAddr,gDrvIndex);

		sscanf(buf_mode[3], "%x", &wRegAddr);	
		IIC_Write(DATA_R_COLORGAIN,wRegAddr,gDrvIndex);
 		sscanf(buf_mode[4], "%x", &wRegAddr);	
		IIC_Write(DATA_G_COLORGAIN,wRegAddr,gDrvIndex);
 		sscanf(buf_mode[5], "%x", &wRegAddr);	
		IIC_Write(DATA_B_COLORGAIN,wRegAddr,gDrvIndex);
	}
}
 