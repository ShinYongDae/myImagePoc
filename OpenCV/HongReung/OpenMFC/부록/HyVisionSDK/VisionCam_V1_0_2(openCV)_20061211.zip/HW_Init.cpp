/******************************************************************************************************
 * HyVISION USB2.0 VisionCAM
 * FILE: HW_Init.CPP
		   - USB2.0 Board H/W Initialize
		   - Sensor Register value Initialize 
		   - Device auto detection 
 * MAJOR FUNCTION :
	  - SensorRegInit( );
	  - SensorRecognition();
	  -	DeviveChange();
	  
 * Copyright (c) 2006	HyVISION SYSTEM Inc.  All right reserved.
 * AUTHOR	: OHSK , KIMSY
 * REV. HISTORY :
 ******************************************************************************************************/
#include	<windows.h>
#include	<stdio.h>
#include	<string.h>
#include	<TCHAR.h>
#include	<io.h>
#include	"resource.h"
#include	"hyimage.h"
#include	"HW_Init.h"
#include	"HyCam.h"
#include	"USB20Interface.h"


char		   rootdir[MAX_PATH]={0};

/**************************************************************************************************
* void	SensorRegInit(int SensorID, int Xsize)
* Description:
*      I2C setting of selected sensor
* Inputs:
*      SensorID     :	SensorID (it defined above part)
*	   Xsize		:	Selected size 
**************************************************************************************************/
void SensorRegInit(int SensorID, int Xsize)
{
	char filedir[MAX_PATH]={0};
	if(HV7131R == SensorID){

		ListOut(ghwndDlg,"HV7131R");
		Set_Sensor_Addr (0x11, gDrvIndex); //Hynix 0x11
		myDelay(10);
		VCLK_POLALITY_HighLow(0,gDrvIndex);
		
 		IIC_Write(0x01, 0x08, gDrvIndex);   //X-flip.
		
		if(Xsize == 640){
			IIC_Write(0x10, 0x00, gDrvIndex);	//Row start address Upper.
			IIC_Write(0x11, 0x03, gDrvIndex);	//Row start address Lower.
			IIC_Write(0x12, 0x00, gDrvIndex);	//Column start address Upper.
			IIC_Write(0x13, 0x03, gDrvIndex);	//Column start address Lower.

			// VGA - 640 x 480
			IIC_Write(0x14, 0x01, gDrvIndex);	//Window Height Upper.
			IIC_Write(0x15, 0xE0, gDrvIndex);	//Window Height Lower.
			IIC_Write(0x16, 0x02, gDrvIndex);	//Window Width	Upper
			IIC_Write(0x17, 0x80, gDrvIndex);	//Window Width	Lower.
		}
		if(Xsize == 320){
			IIC_Write(0x10, 0x00, gDrvIndex);	//Row start address Upper.
			IIC_Write(0x11, 0x7b, gDrvIndex);	//Row start address Lower.
			IIC_Write(0x12, 0x00, gDrvIndex);	//Column start address Upper.
			IIC_Write(0x13, 0xa3, gDrvIndex);	//Column start address Lower.

			// QVGA - 320 x 240
			IIC_Write(0x14, 0x00, gDrvIndex);	//Window Height Upper.
			IIC_Write(0x15, 0xf0, gDrvIndex);	//Window Height Lower.
			IIC_Write(0x16, 0x01, gDrvIndex);	//Window Width	Upper
			IIC_Write(0x17, 0x40, gDrvIndex);	//Window Width	Lower.
		}

		IIC_Write(0x22, 0x00, gDrvIndex);
		IIC_Write(0x23, 0x20, gDrvIndex);
		
		IIC_Write(0x25, 0x01, gDrvIndex);
		IIC_Write(0x26, 0x5b, gDrvIndex);
		IIC_Write(0x27, 0x9a, gDrvIndex);
		IIC_Write(0x30, 0x20, gDrvIndex);	//Pre-amp Gain.
 		IIC_Write(0x31, 0x24, gDrvIndex);	//Red Color Gain.	-soyeon.
		IIC_Write(0x32, 0x12, gDrvIndex);	//Green Color Gain.	-soyeon.
		IIC_Write(0x33, 0x12, gDrvIndex);	//Blue Color Gain.	-soyeon.
	}

	if(MT9T001 == SensorID)  
	{
		ListOut(ghwndDlg,"MT9T001");
	 
		CLK24M_OUT (gDrvIndex);
 		Set_Sensor_Addr(0x5d, gDrvIndex);
		myDelay(10);
		VCLK_POLALITY_HighLow(0,gDrvIndex);

		IIC_Write16(0x0d,0x0001, gDrvIndex);
		IIC_Write16(0x0d,0x0000, gDrvIndex);

		if(Xsize == 2048){
			IIC_Write16(0x01,0x0014, gDrvIndex); //center offset -> Y��ǥ
			IIC_Write16(0x02,0x0020, gDrvIndex); //center offset -> X��ǥ

			IIC_Write16(0x03,0x05ff, gDrvIndex);
			IIC_Write16(0x04,0x07ff, gDrvIndex);

			IIC_Write16(0x05,0x0015, gDrvIndex);
			IIC_Write16(0x06,0x0030, gDrvIndex);
			IIC_Write16(0x09,0x060f, gDrvIndex);
		}
		else if(Xsize == 1600) // UXGA windowing
		{
 			//SY
			IIC_Write16(0x01,0x00C0, gDrvIndex); //center offset -> Y��ǥ
			IIC_Write16(0x02,0x0100, gDrvIndex); //center offset -> X��ǥ
			
			IIC_Write16(0x03,0x04af, gDrvIndex); //1199
			IIC_Write16(0x04,0x063f, gDrvIndex); //1599

			IIC_Write16(0x05,0x0015, gDrvIndex);//
			IIC_Write16(0x06,0x0030, gDrvIndex);
			IIC_Write16(0x09,0x04bf, gDrvIndex);
		}
		else if(Xsize == 1280) // SXGA windowing
		{
 			IIC_Write16(0x01,0x0118, gDrvIndex);//center offset -> Y��ǥ
			IIC_Write16(0x02,0x01a0, gDrvIndex); //center offset -> X��ǥ
			
			IIC_Write16(0x03,0x03ff, gDrvIndex); //1279
			IIC_Write16(0x04,0x04ff, gDrvIndex); //1023

			IIC_Write16(0x05,0x0015, gDrvIndex); //
			IIC_Write16(0x06,0x0030, gDrvIndex);
			IIC_Write16(0x09,0x040f, gDrvIndex);
 		}
		else if(Xsize == 1024) // XGA windowing
		{
 			IIC_Write16(0x01,0x0198, gDrvIndex); //center offset -> Y��ǥ
			IIC_Write16(0x02,0x0220, gDrvIndex); //center offset -> X��ǥ
			
			IIC_Write16(0x03,0x02ff, gDrvIndex); //767
			IIC_Write16(0x04,0x03ff, gDrvIndex); //1023

			IIC_Write16(0x05,0x0015, gDrvIndex);//
			IIC_Write16(0x06,0x0030, gDrvIndex);
			IIC_Write16(0x09,0x030f, gDrvIndex);
		}
		else if(Xsize == 800) // SVGA windowing
		{
			IIC_Write16(0x01,0x01a4, gDrvIndex); //center offset -> Y��ǥ
			IIC_Write16(0x02,0x0114, gDrvIndex); //center offset -> X��ǥ

			IIC_Write16(0x03,0x0257, gDrvIndex); //599
			IIC_Write16(0x04,0x031f, gDrvIndex); //799

			IIC_Write16(0x05,0x0015, gDrvIndex); //
			IIC_Write16(0x06,0x0030, gDrvIndex);
			IIC_Write16(0x09,0x0267, gDrvIndex);
		}
		else if(Xsize == 640) // VGA windowing
		{
			IIC_Write16(0x01,0x0228, gDrvIndex); //center offset -> Y��ǥ
			IIC_Write16(0x02,0x02e0, gDrvIndex); //center offset -> X��ǥ

			IIC_Write16(0x03,0x01df, gDrvIndex); //479
			IIC_Write16(0x04,0x027f, gDrvIndex); //639

			IIC_Write16(0x05,0x0015, gDrvIndex); //
			IIC_Write16(0x06,0x0030, gDrvIndex);
			IIC_Write16(0x09,0x01ef, gDrvIndex);

			/*  // Skip and Bin Modes - VGA
			IIC_Write16(0x02,0x0021, gDrvIndex);
			
			IIC_Write16(0x03,0x059f, gDrvIndex); 
			IIC_Write16(0x04,0x077f, gDrvIndex); 

			IIC_Write16(0x05,0x0015, gDrvIndex);
			IIC_Write16(0x06,0x001f, gDrvIndex);

			IIC_Write16(0x22,0x0002, gDrvIndex);
			IIC_Write16(0x23,0x0002, gDrvIndex);
			*/
		}
	} 

	wsprintf(filedir, "%s\\HVS_VISION.ini", rootdir);
	if(!ParseRegisterFileBoard(filedir))
		ListOut(ghwndDlg,"reg file fail");
}

/**************************************************************************************************
* void	SensorRecognition(int Id_check)
* Description:
*      Sensor recognition with Sensor origianl ID
* Inputs:
*      Id_check     :	Vision's number.
**************************************************************************************************/
int  SensorRecognition (int Id_check)
{
	WORD	wRegData = 0;
	LPSTR	lpAppName = "HVS_VISIONCAM";
	char	filedir[MAX_PATH]={0};
	char	buf_mode[4][5]={0};
  
	myDelay(20);
	CLK24M_OUT(gDrvIndex);
  	Set_Sensor_Addr(0x5d, Id_check);
	myDelay(20);
 
	if(IIC_Write16(0xf0, 0x0000, Id_check)){
		wRegData = (WORD)IIC_Read16(0x00, Id_check);
 		if(wRegData== 0x1621){
			wsprintf(filedir, "VISION%d_Model", Id_check);
			INIWriteStringVision(lpAppName,filedir,"MT9T001");
			wsprintf(filedir, "VISION%d_Select",Id_check);
			INIReadStringVision(lpAppName,filedir,"0",buf_mode[Id_check],5);
			gCurrentSensorType=	atoi(buf_mode[Id_check]);

			wsprintf(filedir, "VISION%d_Fit",Id_check);
			INIReadStringVision(lpAppName,filedir,"0",buf_mode[Id_check],5);
			Fitmode=	atoi(buf_mode[Id_check]);
 		 
			ListOut(ghwndDlg,"%d",Fitmode);

			
 			return MT9T001;
		}
 		else {
 			Set_Sensor_Addr(0x11, Id_check);
			myDelay(20);
			wRegData = (WORD)IIC_Read(0x00, Id_check);
 			if(wRegData== 0x02){
				wsprintf(filedir, "VISION%d_Model", Id_check);
				INIWriteStringVision(lpAppName,filedir,"HV7131R");
  				gCurrentSensorType=	0;
				
				return HV7131R;
			}
 			else {
				return -1;
			}
		}
	}
	else {
 		Set_Sensor_Addr(0x11, Id_check);
		myDelay(20);
		wRegData = (WORD)IIC_Read(0x00, Id_check);
		
		if(wRegData == 0x02){
			wsprintf(filedir, "VISION%d_Model", Id_check);
			INIWriteStringVision(lpAppName,filedir,"HV7131R");
 			gCurrentSensorType=	0;
 			
 			return HV7131R;
		}
 		else {
 			return -1;
		}
	}
}

//Read string
/**************************************************************************************************
* BOOL	INIReadStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR lpDefault, LPTSTR lpReturn, DWORD nSize)
* Description:
*      Read to ini file 
* Inputs:
*      lpAppName     :	Section's name 
*	   lpKey		 :  key
*      lpDefault	 :  default value
*	   lpReturn		 :  have to read string.
*	   nSize		 :  size of buffer	
**************************************************************************************************/
BOOL INIReadStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR lpDefault, LPTSTR lpReturn, DWORD nSize)
{
	char filedir[MAX_PATH]={0};
  	wsprintf(filedir, "%s\\HVS_VISION.ini", rootdir);
 	BOOL bresult = GetPrivateProfileString(lpAppName, lpKey, lpDefault, lpReturn, nSize, filedir);
	return bresult;
}

//Write string
/**************************************************************************************************
* BOOL	INIWriteStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR str)
* Description:
*      Write to ini file 
* Inputs:
*      lpAppName     :	Section's name 
*	   lpKey		 :  key
*	   str			 :  have to write string.	
**************************************************************************************************/
BOOL INIWriteStringVision(LPCTSTR lpAppName, LPCTSTR lpKey, LPCSTR str)
{
	char filedir[MAX_PATH]={0};
  	wsprintf(filedir, "%s\\HVS_VISION.ini", rootdir);
 	BOOL bresult = WritePrivateProfileString(lpAppName, lpKey, str, filedir);
	return bresult;
 }