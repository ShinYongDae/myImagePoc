#ifndef _USER_CONTROL_H_
#define _USER_CONTROL_H_


//Register of MT9T001 address define 
#define		ADD_SHUTTER			0x09
#define		ADD_RGAIN			0x2D
#define		ADD_BGAIN			0x2C
#define		ADD_GGAIN			0x35

#define		QXGA_SHUTTER		0x047f
#define		UXGA_SHUTTER		0x04Bf
#define		SXGA_SHUTTER		0x040f
#define		XGA_SHUTTER			0x030f
#define		SVGA_SHUTTER		0x0267
#define		VGA_SHUTTER			0x01EF

#define		A_RGAIN				0x0008
#define		D_RGAIN				0x0000

#define		A_GGAIN1			0x0006
#define		D_GGAIN1			0x0000

#define		A_GGAIN2			0x0006
#define		D_GGAIN2			0x0000

#define		A_BGAIN				0x0008
#define		D_BGAIN				0x0000

//Register of HV7131R address define 
#define		PRE_AMPGAIN			0x30
#define		R_COLORGAIN			0x31
#define		G_COLORGAIN			0x32
#define		B_COLORGAIN			0x33

#define		DATA_INT_TIME_HIGH		0x06
#define		DATA_INT_TIME_MIDDLE	0x05
#define		DATA_INT_TIME_LOW		0x9a
#define		DATA_R_COLORGAIN		0x24
#define		DATA_G_COLORGAIN		0x12
#define		DATA_B_COLORGAIN		0x12

#define		INT_TIME_HIGH		0x25
#define		INT_TIME_MIDDLE		0x26
#define		INT_TIME_LOW		0x27


extern HWND		gMironAeDlg;					//ISP control dialog's handle
extern HWND		gMagnaAeDlg;
extern HWND		gSplashDlg;
extern HWND		gOpenCVDlg;

extern BOOL		gOpenCV;
extern BOOL		gGRAY;
extern BOOL		gGRAYhisto;
extern BOOL		gBLUR;
extern BOOL		gCANNY;
extern BOOL		gFACEDETECTION;
extern BOOL		gTMATCHING;
extern BOOL		gAVI;

/**************************************************************************************************/
/*  User addition function     ...                                                                */
/**************************************************************************************************/
/**************************************************************************************************
* BOOL CALLBACK	ControlDlgProc(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
* Description:
*		 ISP Control Dialog for register of AE	: MT9T001
**************************************************************************************************/
BOOL CALLBACK	ControlDlgProc(HWND hDlg, UINT Message, UINT wParam, LONG lParam);

/**************************************************************************************************
* BOOL CALLBACK	ControlDlgProc2(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
* Description:
*		 ISP Control Dialog for register of AE  : HV7131R
**************************************************************************************************/
BOOL CALLBACK	ControlDlgProc2(HWND hDlg, UINT Message, UINT wParam, LONG lParam);

/**************************************************************************************************
* BOOL CALLBACK	OpenCVDlgProc(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
* Description:
*		 openCV Control Dialog 
**************************************************************************************************/
BOOL CALLBACK	OpenCVDlgProc(HWND hDlg, UINT Message, UINT wParam, LONG lParam);

/**************************************************************************************************
* BOOL CALLBACK	SplashControl(HWND hDlg, UINT Message, UINT wParam, LONG lParam)
* Description:
*		 Splash logo Control Dialog  
**************************************************************************************************/
BOOL CALLBACK	SplashControl(HWND hDlg, UINT Message, UINT wParam, LONG lParam);

/**************************************************************************************************
* void	Read_User_Control_Set(void)
* Description:
*     Read setting value about ISP control
**************************************************************************************************/
void	Read_User_Control_Set(void);


#endif /* _USER_CONTROL_H_ */