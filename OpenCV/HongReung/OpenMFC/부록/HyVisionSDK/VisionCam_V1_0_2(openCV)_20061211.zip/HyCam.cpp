/********************************************************************************************
 * HyVISION USB2.0 VisionCAM
 * FILE: HyCam.CPP
		   - App. Program's WinMain Procedure
		   - AppWndProc()'s Timer and Display event.
 * MAJOR FUNCTION :
	  - AppInit( );
	  - WinMain( );
	  - AppWndProc( );
	  
 * Copyright (c) 2006	HyVISION SYSTEM Inc.  All right reserved.
 * AUTHOR	: OHSK, KIMSY
 * REV. HISTORY :
 *********************************************************************************************/
#include	<windows.h>
#include	<Commctrl.h>
#include	"stdio.h"
#include	"HyCam.h"
#include	"resource.h"
#include	"hyimage.h"
#include	"HW_Init.h"
#include	"USB20Interface.h"
#include	"User_Control.h"


/*-----------------------------------------------------------------------------
   Global Variables
-----------------------------------------------------------------------------*/
HWND		ghwndApp;
HINSTANCE	ghInstApp;
HFONT		ghfont;
TEXTMETRIC	gtm;
LPCTSTR		lpszClass = TEXT("[www.hyvision.co.kr]HVS Vision Camera RDK V1.0");
RECT		ImageRt;
//
BOOL	    bReduce;
int			Fitmode;
int			ResolutionX, ResolutionY;
int			ScrollSizeX,ScrollSizeY;

typedef		LONG(PASCAL * LPWNDPROC)(HWND, UINT, WPARAM, LPARAM); //pointer to a window procedure

BOOL AppInit(HINSTANCE hInst, HINSTANCE hPrev, int sw, LPSTR szCmdLine)
{
    WNDCLASS cls;
    HDC hdc;
	
    const DWORD dwExStyle = 0;

    ghInstApp = hInst;

	if(!hPrev)
	{
	    cls.hCursor = LoadCursor(NULL, IDC_ARROW);
 		cls.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_HVS));
	    cls.lpszMenuName = NULL; 
	    cls.lpszClassName = lpszClass;
	    cls.hbrBackground =(HBRUSH)GetStockObject(BLACK_BRUSH);
	    cls.hInstance = hInst;
	    cls.style =	CS_BYTEALIGNCLIENT | CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS;
	    cls.lpfnWndProc =(LPWNDPROC) AppWndProc;
	    cls.cbWndExtra = 0;
	    cls.cbClsExtra = 0;
	
	    if(!RegisterClass(&cls))
			return FALSE;
	}

    ghfont =(HFONT) GetStockObject(ANSI_VAR_FONT);
    hdc = GetDC(NULL);
    SelectObject(hdc, ghfont);
    GetTextMetrics(hdc, &gtm);
    ReleaseDC(NULL, hdc);

	ResolutionX = GetSystemMetrics(SM_CXSCREEN);
	ResolutionY = GetSystemMetrics(SM_CYSCREEN);
	

    ghwndApp = CreateWindowEx(dwExStyle, lpszClass,
			       lpszClass,
				   WS_OVERLAPPED | WS_SYSMENU | WS_MINIMIZEBOX,
			       0,0,
				   IMAGESIZE_X,IMAGESIZE_Y+25,
			       (HWND) NULL,
			       (HMENU) NULL,
			       hInst,
			       (LPSTR) NULL); 

	HWND hMainDlg;
	hMainDlg = CreateDialog(hInst, MAKEINTRESOURCE(IDD_MAIN_DLG),
			      ghwndApp,(DLGPROC)MainDlgProc);
    ShowWindow(ghwndApp, sw);
	
    return TRUE;
}

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR szCmdLine, int sw)
{
	MSG		msg;
    
	if (!AppInit(hInst, hPrev, sw, szCmdLine))
		return FALSE;

    for(;;)
	{
	    while(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
		    if(msg.message == WM_QUIT)
				return msg.wParam;

		    TranslateMessage(&msg);
		    DispatchMessage(&msg);
		}
	    WaitMessage();
	}
	return msg.wParam;
}

LONG WINAPI AppWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT		ps;
    HDC				hdc;
	short			nMsgID;	
  
	ghwndApp = hwnd;
 
	switch(msg)
	{
	    case	WM_CREATE:
				SetRect(&ImageRt, 0, 0, IMAGESIZE_X, IMAGESIZE_Y);
				bReduce=FALSE;
				Fitmode=0;
				if(!IsWindow(gSplashDlg))
								CreateDialog(ghInstApp, MAKEINTRESOURCE(IDD_SPLASH),ghwndApp,(DLGPROC)SplashControl);
 				
  				return 0;	

	    case	WM_INITMENU:
				break;

		case	WM_CLOSE:
				nMsgID = MessageBox(hwnd, "Do you want exit?", "EXIT",
	    					MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2);
				if (nMsgID == IDYES) {
					deleteDetection();

					m_PlayMode=EXIT0;
					
					if(IsWindow(gMironAeDlg) )		ShowWindow(gMironAeDlg, SW_HIDE);
					if(IsWindow(gMagnaAeDlg) )		ShowWindow(gMagnaAeDlg, SW_HIDE);
 					PostQuitMessage(0);
				}
				return 0;

		case	WM_DESTROY:		
				PostQuitMessage(0);
				break;

		case	WM_PAINT:
 				hdc = BeginPaint(hwnd, &ps);
			//	if(bReduce|| ((IMAGESIZE_X<ResolutionX)&&(IMAGESIZE_Y<ResolutionY)))
				if((Fitmode==0) || ((IMAGESIZE_X<ResolutionX)&&(IMAGESIZE_Y<ResolutionY)))	
				{
					DisplayImage(hdc);
				}else{
					DisplayImage2(hdc,ResolutionX,ResolutionY);
				}			

  				EndPaint (hwnd, &ps);
				return 0;
 		case	WM_TIMER:
  	
 				return 0;
	} // switch
    return DefWindowProc(hwnd, msg, wParam, lParam);
}
